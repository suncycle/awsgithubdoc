<?php

header("Content-Type: text/html; charset=UTF-8");
//框架路径
define('APP_ROOT', dirname(__FILE__) . '/');
require_once(APP_ROOT . 'conf/site.conf.php');
require_once(APP_ROOT . 'app/AdminCore.php');
new AdminCore();
?>