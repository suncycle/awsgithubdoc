<?php

/*
 * Copyright 2012 Zhtx Systems, Inc.
 */


if (!defined('IN_ZHTX'))
{
    exit('Access Denied');
}
require_once(APP_ROOT . 'conf/site.conf.php');

class RewriteCore
{

    /**
     * core 伪静态CORE 启动
     */
    public function __construct($rule, $rewrite_type = 0)
    {
        $queryString = _g("main_page");
        if ($queryString == "")
            return;
        $last_char = substr($queryString, -1);
        if ($last_char == "/")
            $is_dir = true;
        else
            $is_dir = false;

        if (!$is_dir)
        {
            foreach ($rule['rule'][$rewrite_type] as $value)
            {
                if (preg_match($value["rule"], $queryString, $matches))
                {
//					print_r($matches);
                    $url = $value["url"];
                    foreach ($matches as $k => $v)
                    {
                        $url = str_replace("\$" . $k, $v, $url);
                    }
                    parse_str($url, $result);
                    foreach ($result as $g_k => $g_v)
                    {
                        $_GET[$g_k] = $g_v;
                    }
                    return;
                }
            }

            //Narrow/shoes-c45/nike-b23/new-products-t48/red-p48/xxxl-p23/list-(其他参数)p23.html
            if (preg_match("/Narrow\/(.*)list-(.*)r([0-9]*)\.html/", $queryString, $matches))
            {
                $cond = $matches[1];
                if (preg_match("/c([0-9]*)\//", $cond, $matchestmp))
                    $_GET["category_id"] = $matchestmp[1];
               // 注释的代码以前是单选，，目前已改为多选
			   // if (preg_match("/b([0-9]*)\//", $cond, $matchestmp))
                  //  $_GET["brand_id"] = $matchestmp[1];
              //  if (preg_match("/t([0-9]*)\//", $cond, $matchestmp))
                  //  $_GET["tag_id"] = $matchestmp[1];
				if (preg_match_all("/b([0-9]*)\//", $cond, $matchestmp))
                {
                    foreach ($matchestmp[1] as $key => $value)
                    {
                        $_GET["brand_id"][] = $value;
                    }
                }
				if (preg_match_all("/t([0-9]*)\//", $cond, $matchestmp))
                {
                    foreach ($matchestmp[1] as $key => $value)
                    {
                        $_GET["tag_id"][] = $value;
                    }
                }
                if (preg_match_all("/p([0-9]*)\//", $cond, $matchestmp))
                {
                    foreach ($matchestmp[1] as $key => $value)
                    {
                        $_GET["property_id"][] = $value;
                    }
                }
                $_GET["m"] = "home";
                $_GET["c"] = "product";
                $_GET["a"] = "list";
                $_GET["oquery"] = $matches[2];
                $_GET["page"] = $matches[3];
                return;
            }

            if (isset($rule['rule'][$rewrite_type]))
            {
                foreach ($rule['rule'][$rewrite_type] as $value)
                {
                    if (preg_match($value["rule"], $queryString, $matches))
                    {
                        $url = $value["url"];

                        foreach ($matches as $k => $v)
                        {
                            $url = str_replace("\$" . $k, $v, $url);
                        }
                        parse_str($url, $result);
                        foreach ($result as $g_k => $g_v)
                        {
                            $_GET[$g_k] = $g_v;
                        }
                        return;
                    }
                }
            }
        }
        //--- 匹配自定义URL
        if (preg_match("/(.*)\/p([0-9]*)\.html/", $queryString, $matches))
        {
            $_GET["page"] = $matches[2];
            $diy_url = $matches[1] . "/";
        }
        else if (preg_match("/(.*)\/(.*)_p([0-9]*)\.html/", $queryString, $matches))
        {
            $_GET["page"] = $matches[3];
            $_GET["query"] = $matches[2];
            $diy_url = $matches[1] . "/";
        }
        else
        {
            $diy_url = $queryString;
        }
        $last_char = substr($diy_url, -1);
        if ($last_char == "/")
        {
            $diy_url = substr($diy_url, 0, strlen($diy_url) - 1);
        }
        $condition = "url_md5 = '" . md5(strtolower($diy_url)) . "' or url_md5 = '" . md5(strtolower($diy_url . '/')) . "' order by id desc";
        $urlalisa = Zhtx::loadModule(Module::LOGIC, ucfirst("UrlAlisa") . 'Logic');
        $item = $urlalisa->getOne($condition);
        if ($item)
        {
            if($item['type']==1)
            {
                $url_info = parse_url($item["route"]);
                $arr_query = array();
                parse_str($url_info["query"], $arr_query);
                foreach ($arr_query as $key => $value)
                {
                    $_GET[$key] = $value;
                }
            }
            else if($item['type']==2)
            {
                $protocol = substr($item["route"], 0, 4);
                $first_char = substr($item["route"], 0, 1);
                if($protocol == 'http' || $first_char == '/')
                    $location = $item["route"];
                else
                    $location = SITE_PROTOCOL . SITE_URL . '/' . $item["route"];
                Header("HTTP/1.1 301 Moved Permanently");
                Header("Location: " . $location);
				die();
            }
        }
        else
        {
			$_GET['page_code'] = 404;
        }
//		print_r($_GET);
    }

}

?>