<?php

/*
 * Copyright 2012 35Zh Systems, Inc.
 */
ob_start();
session_start();
if (!defined('IN_ZHTX'))
{
  exit('Access Denied');
}
if (defined('PHP_TIME_OUT'))
{
  ini_set("max_execution_time", PHP_TIME_OUT); 
}
// 定义php错误提示级别
if(isset($_GET['debug']) || XDEBUG || isset($_SESSION['sql_debug']))
{
  ini_set('display_errors','On');
  error_reporting(E_ALL & ~E_NOTICE);
}
else
{
  
  ini_set('error_reporting', E_ERROR);
  ini_set('display_errors','Off');
}
require_once(APP_ROOT . 'libary/Core.php');
require_once(APP_ROOT . 'conf/ip.conf.php');
class AdminCore extends Core
{
    /**
    * core路由启动
    */
    public function __construct()
    {
        /**
         *定义后台模板文件目录 
         */
        self::$site = "manage";
        self::config();
        self::setCtlAct();
        self::setRoot();
        Inputer::init();
        self::init();        
        self::run();
    }
    /**
     * 初始化 
     */
    protected static function init()
    {
        global $ip_limit;
        if(count($ip_limit) > 0 && !in_array(Common::ip(), $ip_limit))
        {
          echo 'You do not have permission!', die;
        }       
        $admin_name     = _c('admin_name');
		$admin_password = _c('admin_password');
		if((!$admin_name || !$admin_password) && _g('a') != 'login' && _g('c') != 'auth')
		{
			if(_g('m') == 'admin' && _g('c') == 'admin' && _g('a') == 'default')
             {
			 	$url = ADMIN_ROOT."?m=admin&c=admin&a=login"; 
             }
		  	else if(!_g('m')  && !_g('c')  && !_g('a') )
            {
              $url = ADMIN_ROOT."?m=admin&c=admin&a=login"; 
            }
            else
            {
              if(strtolower($_SERVER['REQUEST_URI'])=="/".ADMIN_ROOT || strpos(strtolower($_SERVER['REQUEST_URI']), 'publicnotright') !== FALSE)
              {
                  $url = ADMIN_ROOT."?m=admin&c=admin&a=login";
              }   
              else
              {
                  $url = ADMIN_ROOT."?m=admin&c=admin&a=login&redirect=".urlencode($_SERVER['REQUEST_URI']); 
              }
            }
			@header("location:".$url);
		 	die();
		}
		$where = "user_name='".$admin_name."' and password='".$admin_password."'";
		$logic = AppController::load('Admin');
		$admin = $logic->getOne($where);
        if($admin)
        {//处理已经登录的用户
			$_SESSION["id"]        = $admin["id"];           
			$_SESSION["admin_id"]  = $admin["id"];
			$_SESSION["real_name"] = $admin["real_name"];
			$_SESSION["admin"] = $admin;
            if(!_g('m') || !_g('c'))
            {
                @header("location:".ADMIN_ROOT."?m=admin&c=admin&a=default");
            }
            if($admin["role_id"] != 1 )
            {
                Common::validAdminRight($admin["role_id"]);//权限控制
            }
            $base_currency = AppController::getBaseCurrency();
            global $site_info;
		    $site_info['currency'] = $base_currency;
            if(_g('c') != 'config' && _g('a') != 'newset')
            {             
              Core ::$tpl->set('base_currency', $base_currency);
            }
            Core ::$tpl->set('css_js_domain', CSS_JS_DOMAIN);
            Core ::$tpl->set('report_url', REPORT_URL);
            Core ::$tpl->set('admin_url', ADMIN_ROOT);
        }
        else
        {
            if(!(_g('m') === 'admin' && _g('c') === 'admin' && _g('a') === 'login') && !(_g('m') === 'admin' && _g('c') === 'auth' && _g('a') === 'default'))
            {
              
			  if(_g('m') == 'admin' && _g('c') == 'admin' && _g('a') == 'default')
              {
			  	$url = ADMIN_ROOT."?m=admin&c=admin&a=login"; 
              }
			  else if(!_g('m')  && !_g('c')  && !_g('a') )
              {
			  	$url = ADMIN_ROOT."?m=admin&c=admin&a=login"; 
              }
			  else
              {
				if(strtolower($_SERVER['REQUEST_URI'])=="/".ADMIN_ROOT)
					$url = ADMIN_ROOT."?m=admin&c=admin&a=login";
				else
					$url = ADMIN_ROOT."?m=admin&c=admin&a=login&redirect=".urlencode($_SERVER['REQUEST_URI']); 
              }			 
			   echo "<script language=\"javascript\">\n";
			   echo "if(parent)\n";
			   echo "parent.location.href='". $url."'\n";
			   echo "else\n";
			   echo "location.href='". $url."'\n";
			   echo "</script>";
			   die();
            }
        }        
    }
    
}

?>