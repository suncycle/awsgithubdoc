<?php
/*
 * Copyright 2012 Zhtx Systems, Inc.
 */
class GoodsPackageSaleGoodsRelLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "GoodsPackageSaleGoodsRelTable";
    }
    
 

}

?>
