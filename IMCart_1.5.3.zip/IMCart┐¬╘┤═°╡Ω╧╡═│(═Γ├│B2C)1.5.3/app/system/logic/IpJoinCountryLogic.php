<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IpJoinCountryLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class IpJoinCountryLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'IpJoinCountryView';
  }
  public function getCountryId($ip)
  {
    $cond = $ip . ' between i.startip  and i.endip';
    $country = $this->getOne($cond);
    return isset($country['country_id']) ? $country['country_id'] : 0;
  }
  
  public function initUserCountry()
  {
	  $country_id = _c("clientCountryID") ? _c("clientCountryID"):0;
	  $country_id = (int) $country_id ;
	  if(!$country_id)
	  {
          $countryLogic  = $this->load('country');
          $languageLogic = $this->load('language');
		  $intIP = Common::_ip2long(Common::ip());
		  $country_id = $this->getCountryId($intIP);
	  	  $myCountry  = $countryLogic->getOneById($country_id);
		 if($myCountry)
		  {
			  setcookie('clientCountryID', $myCountry['id'], time()+86400*7);
			  setcookie('clientCountryCode2', $myCountry['country_code_2'], time()+86400*7);
			  setcookie('clientCountryCode3', $myCountry['country_code_3'], time()+86400*7);
			  setcookie('clientCountryName', $myCountry['base_name'], time()+86400*7);
			  
			  $_SESSION['clientCountryID'] = $myCountry['id'];
			  $_SESSION['clientCountryCode2'] = $myCountry['country_code_2'];
			  $_SESSION['clientCountryCode3'] = $myCountry['country_code_3'];
			  $_SESSION['clientCountryName'] = $myCountry['base_name'];
			  
		  }
		   else
		  {
			  $cur_language_id  = $languageLogic->language_id;
			  $default_language = $languageLogic->getOneById($cur_language_id);
			  $default_country  = $countryLogic->getOneById($default_language["country_id"]);
			  if($default_country)
			  {
				  setcookie('clientCountryID', $default_country['id'], time()+86400*7);
				  setcookie('clientCountryCode2', $default_country['country_code_2'], time()+86400*7);
				  setcookie('clientCountryCode3', $default_country['country_code_3'], time()+86400*7);
				  setcookie('clientCountryName', $default_country['base_name'], time()+86400*7);
				  
				    $_SESSION['clientCountryID'] = $default_country['id'];
					$_SESSION['clientCountryCode2'] = $default_country['country_code_2'];
					$_SESSION['clientCountryCode3'] = $default_country['country_code_3'];
					$_SESSION['clientCountryName'] = $default_country['base_name'];
			  }
			  else
			  {
				  setcookie('clientCountryID', 229, time()+86400*7);
				  setcookie('clientCountryCode2', "US", time()+86400*7);
				  setcookie('clientCountryCode3', "USA", time()+86400*7);
				  setcookie('clientCountryName', "United States", time()+86400*7);
				  
				  	$_SESSION['clientCountryID'] = 229 ;
					$_SESSION['clientCountryCode2'] = 'US';
					$_SESSION['clientCountryCode3'] = "USA";
					$_SESSION['clientCountryName'] = "United States";
			  }
		  }
	  }
	  else
	  {
	 	$_SESSION['clientCountryID'] = $country_id;
		$_SESSION['clientCountryCode2'] = _c('clientCountryCode2');
		$_SESSION['clientCountryCode3'] = _c('clientCountryCode3');
		$_SESSION['clientCountryName'] = _c('clientCountryName');
	  }
  }
  
  public function isCnIp($ip)
  {
    $cond  = $ip . ' between i.startip and i.endip and i.scountry="CN"';
    $count = $this->getCount($cond);
    return $count > 0 ? TRUE : FALSE;
  }
}

?>