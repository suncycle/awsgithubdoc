<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InsuranceLanguageLogic
 *
 * @author rongxiang.xie <QQ:1251679791,359285617 www.35zh.com>
 */
class InsuranceLanguageLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'InsuranceLanguageTable';
  }
}

?>
