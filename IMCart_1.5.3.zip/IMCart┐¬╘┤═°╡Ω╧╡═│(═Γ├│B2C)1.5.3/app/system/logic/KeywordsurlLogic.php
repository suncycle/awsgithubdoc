<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminRoleLogic
 *
 * @author huangjp@35zh.cn
 */
class KeywordsurlLogic extends BaseLogic
{
    public function __construct() 
    {
        parent::__construct();
        $this->table = 'KeywordsurlTable';
    }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }
}

?>
