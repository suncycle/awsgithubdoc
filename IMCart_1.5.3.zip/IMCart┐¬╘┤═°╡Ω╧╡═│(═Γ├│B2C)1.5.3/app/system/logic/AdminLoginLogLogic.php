<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminLoginlogLogic
 *
 * @author xrx
 */
class AdminLoginLogLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'AdminLoginLogTable';
    }
    public function save($data, $primary = 0)
    {
        $map = Zhtx::createDataMap();
        if(isset($data['base_name']))
            $map->addEntry('base_name', $data['base_name'], DB::CHAR);
        if(isset($data['status']))
            $map->addEntry('status', $data['status'], DB::INT);
        if(isset($data['create_time']))
            $map->addEntry('create_time', $data['create_time'], DB::INT);
        if(isset($data['ip']))
            $map->addEntry('ip', $data['ip'], DB::INT);
         if(isset($data['user_agent']))
            $map->addEntry('user_agent', $data['user_agent'], DB::CHAR);
        if(isset($data['os_type']))
            $map->addEntry('os_type', $data['os_type'], DB::CHAR);
        if(isset($data['browser_soft']))
            $map->addEntry('browser_soft', $data['browser_soft'], DB::CHAR); 
        if($primary)
        {
            $return = $this->updateById($map, $primary);                    
        }
        else
        {
            $return = $this->insert($map);
        }
        return $return;
    }
}

?>
