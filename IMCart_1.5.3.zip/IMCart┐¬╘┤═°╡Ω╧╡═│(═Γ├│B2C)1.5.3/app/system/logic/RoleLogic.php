<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminRoleLogic
 *
 * @author XRX
 */
class RoleLogic extends BaseLogic
{
    public function __construct() 
    {
        parent::__construct();
        $this->table = 'RoleTable';
    }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        if(isset($data['rolename']))
            $map->addEntry('rolename', $data['rolename'], DB::VARCHAR);
        if(isset($data['description']))
            $map->addEntry('description', $data['description'], DB::VARCHAR);
        if(isset($data['listorder']))
            $map->addEntry('listorder', $data['listorder'], DB::INT);
        if(isset($data['disabled']))
            $map->addEntry('disabled', $data['disabled'], DB::INT);       
        if($primary)
        {
            $return = $this->updateById($map, $primary);
        }
        else
        {
            $return = $this->insert($map);
        }
        return $return;
    }
}

?>
