<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BannerJoinBannerItemLogic
 *
 * @author cx
 * 
 */
class BannerJoinBannerItemLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'BannerJoinBannerItemView';
    }
    /**
     * 
     * @param type $params 
     */
    public function getBanner($params)
    {
       $banner_id   = isset($params['banner_id']) ? $params['banner_id'] : 0;
       $codeno      = isset($params['codeno']) ? $params['codeno'] : '';
       $language_id = isset($params['language_id']) ? $params['language_id'] : 0;
       $cond = '1=1';
       if($banner_id)
       {
         $cond .= 'b.id='.$banner_id; 
       }
       if($codeno)
       {
         $cond .= ' and b.codeno="' . $codeno . '"';
       }
       $cond .= ' and i.language_id=' . $language_id . ' order by i.listorder asc';
       return $this->findAll($cond);
    }
}
        
?>
