<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsTypePropertyJoinPropertyJoinPropertyLogic
 *
 * @author hjp <huangjp@35zh.com>
 */
class GoodsTypePropertyJoinPropertyJoinPropertyLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'GoodsTypePropertyJoinPropertyJoinPropertyView';
    }
}

?>