<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CreditCondLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class CreditCondLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'CreditCondTable';
   }
   public function save($data)
  {
      $cond = $this->getOne('type=' . $data['type']);
      if($cond)unset($data['create_time']);
      $map = Zhtx::createDataMap();
      $map->createEntry($data);      
      if($cond)
      {          
          $res = $this->update($map, 'id='.$cond['id']); 
          return $res ? $cond['id'] : 0;
      }
      else
      {
          return  $this->insert($map);
      }
  }
}

?>
