<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProductLanguageLogic
 *
 * @author xrx
 */
class GoodsLanguageLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'GoodsLanguageTable';
    }
    
    public function save($data, $id=0)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);        
        if($id)
        {
            return $this->update($map, 'id='.$id);
        }
        else
        {
            return $this->insert($map);
        }
        
    }
    public function getListByGoodsId($goods_id)
    {
        $where  = 'goods_id =' . $goods_id;
        $res    = $this->getList($where);
        $result = array();
        foreach ($res['list'] as $list)
        {
            $result[$list['language_id']] = $list;
        }
        return $result;
    }
    public function updateByCond($data)
    {
        $cond = 'goods_id ='. $data['goods_id'] . ' and language_id='.$data['language_id'];
        $map = Zhtx::createDataMap();
        $map->createEntry($data);        
        return $this->replaceByCond($map, $cond);
    }
    /**
     * 清除缓存
     * @global type $data_cache_dir
     * @param type $goods_id 
     */
    public function updateCache($goods_id)
    {
      global $data_cache_dir;
      $cond = 'goods_id=' . $goods_id;
      $type = "goods_info";
      foreach ($this->findAll($cond) as $value)
      {
        $key = $goods_id . "_". $value['language_id'] . '_detail';
        _delcahce($key, '', $type);       
      }
    }
    
}

?>
