<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsJoinBrandTypeLogic
 *
 * @author xrx
 */
class GoodsJoinBrandTypeLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'GoodsBrandTypeView';
    }
}

?>
