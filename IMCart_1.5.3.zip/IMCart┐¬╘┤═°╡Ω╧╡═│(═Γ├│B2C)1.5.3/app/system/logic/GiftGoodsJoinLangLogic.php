<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GiftGoodsJoinLangLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class GiftGoodsJoinLangLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'GiftGoodsJoinLangView';
  }
  public function getListByOfferId($offer_id, $rule_id, $language_id)
  {
     $cond = 'o.offer_id ='. $offer_id . ' and o.rule_id ='. $rule_id . ' and l.language_id =' . $language_id;
     return $this->findAll($cond);
  }
}

?>
