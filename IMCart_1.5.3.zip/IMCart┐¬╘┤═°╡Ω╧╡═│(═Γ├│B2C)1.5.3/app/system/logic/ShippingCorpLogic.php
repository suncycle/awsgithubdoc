<?php

/**
 * Description of ShippingCorpLogic
 *
 * @author HHH
 */
class ShippingCorpLogic extends BaseLogic
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'ShippingCorpTable';
    }

}

?>
