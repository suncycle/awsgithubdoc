<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodTagLanguageLogic
 *
 * @author xrx
 */
class GoodsTagJoinLanguageLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
		$this->cache_type = 'tag';
        $this->table = 'GoodsTagJoinLanguageView';
    }
   
   public function getListByLanguageId($language_id, $get_cache=true)
   {
     global $data_cache_dir;
     $key = $language_id . '_tag_list';
     $chk = _chkcahce($key, $this->cache_type);
     if(!$get_cache || !$chk)
     {
       $cond = 'l.language_id='. $language_id . ' order by t.listorder asc';
       $chk = $this->findAll($cond,true);
       _setcahce($key, $chk, $this->cache_type);
     }
     return $chk;
   }
   
   public function getItem($id, $language_id=0,$get_cache=true)
    {
        global $data_cache_dir;
        $key     = $id .'_'. $language_id . '_tag';
        $chk  = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$chk)
        {
            $cond =  't.id = '.$id.' and l.language_id='. $language_id . '';
            $chk  = $this->getOne($cond);
            _setcahce($key, $chk, $this->cache_type);
        }
        return $chk;	
    }
}

?>
