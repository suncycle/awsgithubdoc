<?php
/**
 * Description of CategoryRelGoodsJoinLangLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class CategoryRelGoodsJoinLangLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'CategoryRelGoodsJoinLangView';
    $this->cache_type = 'goods_list';
  }
   /**
     * 通过分类集合获取商品集合
     * @param type $category_ids
     * @param type $offet
     * @param type $limit
     * @return type 
     */
    public function getGoodsList($cond, $offet = 0, $limit = 20, $get_cache = TRUE)
    {
       global $data_cache_dir;
        $cols   = array(
            'c.goods_id as id',
            'c.goods_category_id',
            'g.base_name as defaulte_base_name',
            'g.codeno',
            'g.image',        
            'g.price',
            'g.cost_price',           
            'g.market_price',
            'g.weight',
            'g.brand_id',
            'g.goods_type_id',           
            'g.listorder',
            'g.status' ,
            'g.page_url',
            'g.template_page',
            'g.up_time',
            'g.modify_time',
            'g.create_time',
            'l.base_name',
            'l.detail',
            'l.title',
            'l.keywords',
            'l.descript',
            
            );
        $cond   = $cond . ' limit ' . $offet . ',' . $limit;
        $key    = md5($cond);
        $chk    = _chkcahce($key, $this->cache_type);
        $result = array();
        if(!$get_cache || !$chk)
        {
            $result = $this->getCols($cond, $cols);        
            
            _setcahce($key, $result, $this->cache_type); 
        }
        else
        {
            $result = $chk;
        }
        
        return $result;
    }
    public function getGoods($cond, $page_size, $curr_page, $get_cache=true)
    {
      global $data_cache_dir;
      $cols   = array(
            'c.goods_id as id',
            'c.goods_category_id as category_id',
            'g.base_name as default_base_name',
            'g.codeno as codeno',
            'g.image as image',        
            'g.price as price',
            'g.cost_price as cost_price',           
            'g.market_price as market_price',
            'g.weight as weight',
            'g.brand_id as brand_id',
            'g.goods_type_id as type_id',           
            'g.listorder as listorder',
            'g.status as status',
            'g.page_url as page_url',
            'g.template_page as template_page',
            'g.up_time as up_time',
            'g.modify_time as modify_time',
            'g.create_time as create_time',
			'g.visit_counts as visit_counts',
			'g.buy_counts as buy_counts',
			'g.wishlist_counts as wishlist_counts',
			'g.comment_counts as comment_counts',
			'g.comment_value as comment_value',
            'g.is_free_shipping as is_free_shipping',
			'g.start_time as start_time',
			'g.end_time as end_time',
			'g.discount as discount',
            'g.special_status as special_status',        
            'l.base_name as base_name',
            );
      if($curr_page > 10)
      {
        return $this->getCurrentDatas($cond, $page_size, $curr_page, $cols);
      }
      $key = md5($cond.'_' .$page_size.'_'.$curr_page);
      $chk    = _chkcahce($key, $this->cache_type);
      $result = array();
      if(!$get_cache || !$chk)
      {
          $result = $this->getCurrentDatas($cond, $page_size, $curr_page, $cols);        
          _setcahce($key, $result, $this->cache_type); 
      }
      else
      {
          $result = $chk;
      }

      return $result;
    }
}

?>
