<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PaymentJoinLanguageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class PaymentJoinLanguageLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'PaymentJoinLanguageView';
   }
   
   public function getPaymentById($payment_id, $language_id)
   {
     $cond = 'p.id =' . $payment_id . ' and l.language_id ='. $language_id;
     return $this->getOne($cond);
   }
}

?>
