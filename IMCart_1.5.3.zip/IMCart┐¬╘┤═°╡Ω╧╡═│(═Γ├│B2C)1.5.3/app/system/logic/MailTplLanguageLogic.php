<?php

/**
 * Description of ShippingLogic
 *
 * @author HHH
 */
class MailTplLanguageLogic extends BaseLogic
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'MailtplLanguageTable';
    }

}

?>
