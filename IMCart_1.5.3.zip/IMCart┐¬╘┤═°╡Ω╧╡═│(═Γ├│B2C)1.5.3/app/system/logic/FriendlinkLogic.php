<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FriendlinkLogic
 *
 * @author cx
 * 
 */
class FriendlinkLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'FriendlinkTable';
        $this->cache_type = 'friendlink';
    } 
    public function getFriends($params)
    {
       $language_id = isset($params['language_id']) ? $params['language_id'] : 0;
       $limit       = isset($params['limit']) ? $params['limit'] : 15;
       $cond = '';
       if($language_id)
       {
         $cond .= 'language_id='.$language_id . ' order by listorder asc limit '. $limit;
       }
       return $this->findAll($cond);
    }
    public function getFriendsByLanguageId($language_id, $type, $limit, $get_cache=TRUE)
    {      
      $key   = $language_id . '_' . $type . '_' . $limit . '_friendlink';
      $cache = _chkcahce($key, $this->cache_type);
      if(!$cache || !$get_cache)
      {
        $where = "(language_id=".$language_id . " or language_id=0) AND type=" . $type . " AND status=1 ORDER BY listorder DESC LIMIT " . $limit;
        $cache = $this->findAll($where);
        _setcahce($key, $cache, $this->cache_type);
      }
      return $cache;
    }
}
        
?>
