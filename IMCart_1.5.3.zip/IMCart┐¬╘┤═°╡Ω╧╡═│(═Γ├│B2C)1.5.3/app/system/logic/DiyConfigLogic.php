<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Payment
 *
 * @author huangjp@35zh.com
 */
class DiyConfigLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'DiyConfigTable'; 
        $this->cache_type = 'config';
    }
    /**
     * 缓存处理
     * @global type $data_cache_dir
     * @param type $language_id
     * @param type $get_cache
     * @return type 
     */
    public function getAll($language_id, $get_cache = TRUE)
    {
      global $data_cache_dir;
      $key = $language_id.'_diy_config';
      $chk = _chkcahce($key, $this->cache_type);          
      if(!$get_cache || !$chk)
      {               
          $chk = $this->findAll('language_id=' . $language_id);
          _setcahce($key, $chk, $this->cache_type);
      }           
      return $chk; 
    }
    public function delCache($language_id)
    {
      global $data_cache_dir;
      $key = $language_id.'_diy_config';
      _delcahce($key, '', $this->cache_type);
    }
}
?>
