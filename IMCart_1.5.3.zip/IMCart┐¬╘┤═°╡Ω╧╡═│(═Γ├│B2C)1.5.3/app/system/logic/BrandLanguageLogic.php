<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BrandLanguageLogic
 *
 * @author Administrator
 */
class BrandLanguageLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'BrandLanguageTable';
        $this->cache_type = 'brand';
    }
     public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }
    public function updateByCond($data)
    {
        $cond = 'brand_id=' . $data['brand_id'] . ' and language_id=' . $data['language_id'];
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        return $this->replaceByCond($map, $cond);
    }
    public function delCache($language_id)
    {
      global $data_cache_dir;
      $key = $language_id . '_brand_list';
      _delcahce($key, '', $this->cache_type);
    }
}

?>
