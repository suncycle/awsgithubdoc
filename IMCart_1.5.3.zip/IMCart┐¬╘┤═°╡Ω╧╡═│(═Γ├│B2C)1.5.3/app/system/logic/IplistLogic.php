<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IplistLogic
 *
 * @author czy
 */
class IplistLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'IplistTable';
    }
    /**
     * 判断用户是否属于黑名单用户
     * @param type $ip
     * @param type $language_id
     * @return type 
     */
    public function visitRight($ip, $language_id)
    {
      $cond  = 'status=0 and (' . $ip . ' between start_ip and end_ip) and (language_id=0 or language_id='. $language_id . ')';
      $count = $this->getCount($cond);
      return $count > 0 ? FALSE : TRUE;
    }
}

?>
