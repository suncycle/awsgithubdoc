<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ArticleCategoryLanguageLogic
 *
 * @author czy
 */
class ArticleCategoryJoinLanguageLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'ArticleCategoryJoinLanguageView';
		$this->cache_type = 'article';
    }
	
	 public function getItem($id, $language_id=0,$get_cache=true)
	{
		global $data_cache_dir;
		$key     = $language_id . '_articlecat_detail';
        $result  = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$result)
        {
        	$cond = 'a.id =' . $id . ' AND l.language_id =' . $language_id;
          	$result = $this->getOne($cond);
			return $result;
		}
		else
		{
			return $result;	
		}
	}
}
?>