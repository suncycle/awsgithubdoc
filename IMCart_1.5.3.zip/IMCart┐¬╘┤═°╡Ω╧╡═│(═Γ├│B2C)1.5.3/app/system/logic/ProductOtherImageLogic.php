<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProductOtherImageLogic
 *
 * @author Administrator
 */
class ProductOtherImageLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'ProductOtherImageTable';
        $this->cache_type = "goods_info";
    }
    public function save($data, $id=0)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($id)
        {
            $result = $this->update($map, 'id='.$id);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }
    public function getListByGoodsId($goods_id)
    {
        $where  = 'goods_id ='. $goods_id . ' order by id asc';
        return $this->findAll($where);
    }
    public function getListByProductId($goods_id, $product_id)
    {
        $where  = '(product_id ='.$product_id . ') and goods_id=' . $goods_id;
        $result = $this->findAll($where);        
        return $result;
    }

}

?>
