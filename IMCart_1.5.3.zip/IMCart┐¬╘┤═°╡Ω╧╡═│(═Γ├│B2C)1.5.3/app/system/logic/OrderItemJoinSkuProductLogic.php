<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderItemJoinSkuProductLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OrderItemJoinSkuProductLogic extends BaseLogic
{
   public function __construct()
   {
     $this->table = 'OrderItemJoinSkuProductView';    
   }
}

?>
