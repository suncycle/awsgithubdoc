<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CurrencyLogic
 *
 * @author xrx
 */
class CurrencyLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'CurrencyTable';
        $this->cache_type = 'currency';
    }
    public function getAll($get_cache=TRUE)
    {
      $key = 'currency_list';
      $cache = _chkcahce($key, $this->cache_type);
      if(!$cache || !$get_cache)
      {
        $cache  = $this->findAll('status=1 ORDER BY listorder DESC');
        _setcahce($key, $cache, $this->cache_type);
      }
      return $cache;
    }
    
}

?>
