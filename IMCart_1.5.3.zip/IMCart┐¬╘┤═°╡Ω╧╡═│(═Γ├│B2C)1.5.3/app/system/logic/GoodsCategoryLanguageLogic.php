<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsCategoryLanguageLogic
 *
 * @author xrx
 */
class GoodsCategoryLanguageLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'GoodsCategoryLanguageTable';
    }
     public function save($data, $id = 0)
    {
        $tag_map = Zhtx::createDataMap();
        $tag_map->createEntry($data);
        if($id)
        {
           $res = $this->updateById($tag_map, $id); 
        }
        else
        {
            $res = $this->insert($tag_map);
        }
        return $res;
    }
    public function updateByCond($data)
    {
        $cond = 'goods_category_id=' . $data['goods_category_id'] . ' and language_id=' . $data['language_id'];
        $map  = Zhtx::createDataMap();
        $map->createEntry($data);
        return $this->replaceByCond($map, $cond);
    }
}

?>
