<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderItemJoinSkuLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OrderItemJoinSkuLogic extends BaseLogic
{
    public function __construct()
    {
      parent::__construct();
      $this->table = 'OrderItemJoinSkuView';
    }
     public function getOneByItemId($item_id)
     {
       $cond = 'i.id=' . $item_id;
       return $this->getOne($cond);
     }
      public function getListByOrderId($order_id)
     {
       $cond = 'i.order_id=' . $order_id;
       return $this->findAll($cond);
     }
}

?>
