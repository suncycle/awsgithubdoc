<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OutStockLogic
 * 
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OutStockLogic extends BaseLogic
{
    public function __construct()
    {
      parent::__construct();
      $this->table = 'OutStockTable';
    }
     public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
}

?>
