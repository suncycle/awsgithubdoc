<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ArticleLogic
 *
 * @author czy
 */
class ArticleLogic extends BaseLogic {

    public function __construct() {
        parent::__construct();
        $this->table = 'ArticleTable';
    }

    

}

?>
