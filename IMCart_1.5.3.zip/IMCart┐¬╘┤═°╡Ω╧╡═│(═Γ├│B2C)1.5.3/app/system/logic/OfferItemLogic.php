<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OfferItemLogic
 *
 * @author xrx <www.35zh.com>
 */
class OfferItemLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'OfferItemTable';
    }
    public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
    public function getListByOfferId($offer_id)
    {
      $cond = 'offer_id='. $offer_id;
      return $this->findAll($cond);
    }
}

?>
