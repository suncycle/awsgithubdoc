<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminRoleLogic
 *
 * @author XRX
 */
class AdminRolePrivLogic extends BaseLogic
{
    public function __construct() 
    {
        parent::__construct();
        $this->table      = 'AdminRolePrivTable';
        $this->cache_type = 'menus';
    }
    
    public function getMenuIdsByRoleId($role_id)
    {
        $cond   = 'role_id='.$role_id;
        $result = $this->getList($cond);
        $adminMenuIds = array();
        foreach($result['list'] as $item)
        {
            $adminMenuIds[] = $item['admin_menu_id'];
        }
        return $adminMenuIds;
    }
    /**
     * 保存权限菜单并进行缓存
     * @global type $data_cache_dir
     * @param type $role_id
     * @param type $menu_ids 
     */
    public function saveAll($role_id, $menu_ids)
    {
        foreach($menu_ids as $value)
        {
            $priv_map = Zhtx::createDataMap();
            $priv_map->addEntry('role_id', $role_id, DB::INT);
            $priv_map->addEntry('admin_menu_id', $value, DB::INT);
            $this->insert($priv_map);
        }
         
    }
    public function updateCache($role_id, $menu_ids)
    {
        global $data_cache_dir;       
         $key       = md5($role_id."_admin_right_menus"); //缓存key
         $menuLogic = $this->load('adminMenu');
         $cond      = 'id in ('. implode(',', $menu_ids) . ')';
         $menulist  = $menuLogic->getList($cond);
         $rights     = array();
         foreach($menulist['list'] as $list)
         {
             $right_url = 'm=' . $list['m'] . '&c=' . $list['c'] . '&a=' . $list['a'];
             $rights[$list['id']] = $right_url;
         }
          _setcahce($key, $rights, $this->cache_type);
//                    _debug($rights);
    }
}

?>
