<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OfferLanguageLogic
 *
 * @author xrx <www.35zh.com>
 */
class OfferLanguageLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'OfferLanguageTable';
    }
    public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
    public function getListByOfferId($offer_id)
    {
      $cond   = 'offer_id='.$offer_id;
      $result = $this->findAll($cond);
      $return = array();
      foreach ($result as $value)
      {
        $return[$value['language_id']] = $value;
      }
      return $return;
    }
    public function updateByCond($data)
    {
       $cond = 'offer_id=' . $data['offer_id'] . ' and language_id=' . $data['language_id'];
       $map = Zhtx::createDataMap();
       $map->createEntry($data);
       return $this->replaceByCond($map, $cond);
    }
}

?>
