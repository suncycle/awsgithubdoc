<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsCategoryLogic
 *
 * @author xrx
 */
class GoodsTypePropertyLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'GoodsTypePropertyTable';
    }
    public function save($data, $primary = 0)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $this->updateById($map, $primary);
        }
        else
        {
            $this->insert($map);
        }
    }
    public function updateByCond($data)
    {
        $cond = 'property_id='. $data['property_id'] . ' AND goods_type_id=' . $data['goods_type_id'];
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        return $this->replaceByCond($map, $cond);
    }
    public function getPropertyByTypeId($typeId)
    {
        $cols = array('property_id');
        $cond = 'goods_type_id=' . $typeId;
        $property_ids     = $this->getCols($cond, $cols);                
        $property_ids_str = array();
        foreach ($property_ids as  $value)
        {
            if($value['property_id']) $property_ids_str[]= $value['property_id'];
        }
        $propertylist  = array();
        if(!empty($property_ids_str))
        {
          $cond2 = '(id in (' . implode(',', $property_ids_str) . ') or parent_id in (' . implode(',', $property_ids_str) . ')) and status=1';
          $cond2 .= " order by listorder desc";
          $propertyLogic = $this->load('property');
          $property      = $propertyLogic->findAll($cond2);
          foreach($property as $value)
          {
              if($value['type'] == 1)
              {
                $value['parent_id'] == 0 ?  $propertylist['master'][$value['id']]['parent'] = $value : $propertylist['master'][$value['parent_id']]['child'][$value['id']] = $value;
              }
              else if($value['type'] == 2)
              {
                $value['parent_id'] == 0 ?  $propertylist['sale'][$value['id']]['parent'] = $value : $propertylist['sale'][$value['parent_id']]['child'][$value['id']] = $value; 
              }
              else
              {
                  $value['parent_id'] == 0 ?  $propertylist['common'][$value['id']]['parent'] = $value : $propertylist['common'][$value['parent_id']]['child'][$value['id']] = $value;
                  if($value['parent_id'] == 0 )
                {
                    $propertylist['common'][$value['id']]['parent_listorder'] = $propertylist['common'][$value['id']]['parent']['listorder'];
                }
              }
            }
        }   
        Common::sort_rows($propertylist['common'], 'parent_listorder', SORT_DESC);
        return $propertylist;
    }
}

?>
