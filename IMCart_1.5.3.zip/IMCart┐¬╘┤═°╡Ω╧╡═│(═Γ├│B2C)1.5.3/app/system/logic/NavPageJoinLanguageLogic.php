<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NavPageJoinLanguageLogic
 *
 * @author xrx
 */
class NavPageJoinLanguageLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
		$this->cache_type = 'navpage';
        $this->table = 'NavPageJoinLanguageView';
    }
   
   public function getItem($id, $language_id=0,$get_cache=true)
	{
		global $data_cache_dir;
       	$key     = $id. '_' .$language_id . '_navpage_detail';
        $result  = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$result)
        {
        	$cond = 'n.status=1 and n.id =' . $id . ' AND l.language_id =' . $language_id;
          	$result = $this->getOne($cond);
			_setcahce($key, $result, $this->cache_type);		
		}
	    return $result;
	}
}

?>