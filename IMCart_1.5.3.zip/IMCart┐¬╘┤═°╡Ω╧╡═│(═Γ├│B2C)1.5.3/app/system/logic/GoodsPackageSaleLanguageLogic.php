<?php
/*
 * Copyright 2012 Zhtx Systems, Inc.
 */
class GoodsPackageSaleLanguageLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "GoodsPackageSaleLanguageTable";
    }
    
 

}

?>
