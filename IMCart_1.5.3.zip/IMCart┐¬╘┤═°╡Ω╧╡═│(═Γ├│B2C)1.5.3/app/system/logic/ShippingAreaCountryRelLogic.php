<?php

/**
 * Description of ShippingAreaCountryRelLogic
 *
 * @author HHH
 */
class ShippingAreaCountryRelLogic extends BaseLogic
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'ShippingAreaCountryRelTable';
    }
    public function getListByCountryId($country_id)
    {
      $cond = 'country_id =' . $country_id;
      $result = array();
      foreach ($this->findAll($cond) as $value)
      {
         $result[] = $value['area_id'];
      }
      return $result;
    }

}

?>
