<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsPriceReportLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class GoodsPriceReportLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'GoodsPriceReportTable';
   }
   public function save($params)
   {
     $map = Zhtx::createDataMap();
     $map->createEntry($params);     
     $map->addEntry('create_year', date('Y', SYS_TIME), DB::INT);
     $map->addEntry('create_month', date('Ym', SYS_TIME), DB::INT);
     $map->addEntry('create_day', date('Ymd', SYS_TIME), DB::INT);
     return $this->replace($map);
   }
}

?>
