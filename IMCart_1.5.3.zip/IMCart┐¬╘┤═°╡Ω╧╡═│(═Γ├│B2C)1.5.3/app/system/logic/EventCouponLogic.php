<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of EventCouponLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class EventCouponLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'EventCouponTable';
   }
   public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }
}

?>
