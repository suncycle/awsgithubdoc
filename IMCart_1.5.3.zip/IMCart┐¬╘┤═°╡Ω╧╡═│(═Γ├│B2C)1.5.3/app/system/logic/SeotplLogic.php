<?php

/**
 * Description of SeotplLogic
 *
 * @author HHH
 */
class SeotplLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'SeotplTable';
    }
}

?>
