<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CountryLogic
 *
 * @author xrx
 */
class CountryLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table      = 'CountryTable';
        $this->cache_type = 'address';
    }
    public function getAll($get_cache = TRUE)
    {
        global $data_cache_dir;
        $key = 'country_list';
        $chk = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$chk)
        {
            $chk = $this->findAll('', TRUE);
            _setcahce($key, $chk, $this->cache_type);
        }
        return $chk;
    }
    public function getCountries($orderby='desc',$get_cache = TRUE)
    {
        global $data_cache_dir;
        $key = 'country_list_'.$orderby;
        $chk = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$chk)
        {
            $chk = $this->findAll('status=1 order by listorder ' . $orderby);
            _setcahce($key, $chk, $this->cache_type);
        }
        return $chk;
    }
    public function delCache()
    {
      _delcahce('country_list_desc', '', $this->cache_type);
      _delcahce('country_list_asc', '', $this->cache_type);
    }
}

?>
