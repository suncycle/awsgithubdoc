<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of EventCondLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class EventCondLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'EventCondTable';
   }
   public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }
}

?>
