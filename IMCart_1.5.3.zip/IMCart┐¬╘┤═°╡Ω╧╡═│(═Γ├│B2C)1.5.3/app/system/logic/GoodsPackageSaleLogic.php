<?php
/*
 * Copyright 2012 Zhtx Systems, Inc.
 */
class GoodsPackageSaleLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "GoodsPackageSaleTable";
    }
    
 

}

?>
