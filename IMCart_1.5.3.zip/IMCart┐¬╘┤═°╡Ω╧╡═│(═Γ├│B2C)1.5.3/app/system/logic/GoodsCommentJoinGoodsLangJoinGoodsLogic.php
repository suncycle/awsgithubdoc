<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsCommentJoinGoodsLangJoinGoodsLogic
 *
 * @author Administrator
 */
class GoodsCommentJoinGoodsLangJoinGoodsLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'GoodsCommentJoinGoodsLangJoinGoodsView';
     $this->cache_type = 'goods_comment_category';
   }
}

?>
