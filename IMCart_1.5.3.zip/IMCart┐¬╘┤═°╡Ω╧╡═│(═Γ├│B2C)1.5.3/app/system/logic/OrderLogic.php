<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderLogic
 *
 * @author xrx
 */
class OrderLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'OrderTable';
    }
    public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
    public function getOneByNo($order_itemno)
    {
        $cond = 'itemno ="' . $order_itemno . '"';
        return $this->getOne($cond);
    }
    /**
     * 可能还需要一些条件 比如时间
     * @param type $user_id 
     */
    public function getListByUserId($user_id, $offset=0, $limit=20)
    {
        $cond = 'user_id ='. $user_id . ' order by create_time desc limit ' . $offset . ',' . $limit;
        return $this->findAll($cond);
    }
    
}

?>
