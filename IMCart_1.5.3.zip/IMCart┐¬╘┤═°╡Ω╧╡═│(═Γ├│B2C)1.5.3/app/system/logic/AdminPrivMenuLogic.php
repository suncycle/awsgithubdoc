<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AdminPrivMenuLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class AdminPrivMenuLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'AdminPrivMenuView';
    }
    public function getMenusByRoleId($role_id)
    {
        $res = array();
        if($role_id == 1)
        {
          $res = $this->load('adminMenu')->findAll('display=1 order by listorder desc');
        }
        else
        {
          $cond = 'r.role_id ='. $role_id . ' and m.display=1 order by m.listorder desc';
          $res  = $this->findAll($cond);
        }       
        $lang = Common::menuLang(Core::$language);        
        $adminMenu = array();
        foreach ($res as $value)
        {
            $value['menu_name'] = isset($lang[$value['lang_key']]) ? $lang[$value['lang_key']] : '';

            if($value['parent_id'] == 0)
            {
                $adminMenu['top'][$value['id']] = $value;                 
            }
            else if($value['level'] == 2)
            {
                $adminMenu[$value['parent_id']]['leve2'][] = $value;                 
            }
            else
            {                  
                $adminMenu[$value['parent_id']]['children'][] = $value;
            }
        }              
        return $adminMenu;
    }
}

?>
