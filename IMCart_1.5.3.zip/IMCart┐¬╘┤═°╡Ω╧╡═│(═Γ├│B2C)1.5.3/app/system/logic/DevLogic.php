<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Description of DevLogic
 *
 * @author rongxiang.xie <QQ:1251679791,359285617 www.35zh.com>
 */
class DevLogic extends BaseLogic
{
  public function __construct($table_name='', $table_prefix = TRUE)
  {
    $this->setTable($table_name, $table_prefix);
    parent::__construct();                
  }
  public function setTable($table_name, $table_prefix = TRUE)
  {
    if($table_prefix)
    {      
      $this->table = TABLE_PREFIX . '_' . $table_name; 
    }
    else
    {
      $this->table = $table_name;
    }
  }
}

?>
