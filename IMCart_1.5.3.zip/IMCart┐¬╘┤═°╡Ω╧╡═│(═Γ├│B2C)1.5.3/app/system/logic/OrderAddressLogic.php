<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderAddressLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OrderAddressLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'OrderAddressTable';
   }
   public function save($data, $primary=0)
   {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
   }
   public function updateByCond($data)
   {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      $cond = 'order_id = '. $data['order_id'] . ' and address_type=' . $data['address_type'];
      return $this->update($map, $cond);
   }
}

?>
