<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of MessageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class MessageLogic extends BaseLogic
{
    public function __construct()
    {
      parent::__construct();
      $this->table = 'MessageTable';
    }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }
    public function getMsgByUserId($user_id, $offset=0, $limit=20)
    {
       $language_id  = $this->load('language')->language_id;
       $cond = '(type=0 or (user_id =' . $user_id . ' and type=1 )) and (language_id=0 or language_id='.$language_id.') and parent_id=0 and status=1 order by create_time desc limit ' . $offset . ',' . $limit;
       return $this->findAll($cond);
    }
    public function getMsgDetail( $message_id, $user_id=0, $language_id=0)
    {
      $cond = 'id=' . $message_id . ' or parent_id=' . $message_id . ' and status=1';
      if($language_id)
      {
        $cond .= ' and language_id='. $language_id;
      }
      $cond .= ' order by create_time';
      return $this->findAll($cond);
    }
	
	public function sendTo($user_id,$title,$detail)
	{
		
		$user_id = Common::queryInt($user_id);
		$cond    = 'u.id ='. $user_id;
		$userJoinInfoLogic = $this->load('userJoinInfo');
		$user    = $userJoinInfoLogic->getOne($cond);
		if(!$user)
			return ;
		$map = Zhtx::createDataMap();
		$map->addEntry('parent_id', 0, DB::INT);
		$map->addEntry('status', 0, DB::INT);
		$map->addEntry('base_name', $title, DB::VARCHAR);
		$map->addEntry('create_time', SYS_TIME, DB::INT);
		$map->addEntry('reply_time', 0, DB::INT);
		$map->addEntry('ip', Common::_ip2long(Common::ip()), DB::INT);
		$map->addEntry('detail', $detail, DB::VARCHAR);
		$map->addEntry('is_user_readed', 0, DB::INT);
		$map->addEntry('is_admin_readed', 1, DB::INT);
		$map->addEntry('user_id', $user_id, DB::INT);
		$map->addEntry('user_name', $user['base_name'], DB::VARCHAR);
		$map->addEntry('language_id', $this->load('language')->language_id, DB::INT);
		$map->addEntry('admin_id', 0, DB::INT);
		$map->addEntry('order_id', 0, DB::INT);
		$map->addEntry('order_no', '', DB::VARCHAR);
		$map->addEntry('type', 1, DB::INT);
		$map->addEntry('contact', '', DB::VARCHAR);
		$result = $this->insert($map);
		return ;
	}
}

?>