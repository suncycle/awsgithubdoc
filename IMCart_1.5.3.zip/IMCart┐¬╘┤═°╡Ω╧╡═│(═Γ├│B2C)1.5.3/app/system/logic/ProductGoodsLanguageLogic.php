<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProductGoodsLanguageLogic
 *
 * @author xrx
 */
class ProductGoodsLanguageLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'ProductGoodsLanguageView';
        $this->cache_type = 'goods_list';
    }
    public function getListByProductIds($product_ids, $language_id, $get_cache = TRUE)
    {
        $cond   = 'p.id in (' . implode(',', $product_ids) . ') and p.status=1 and p.stock > 0 and l.language_id='.$language_id;
        $key    = md5($cond);
        $result = array();
        $chk    = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$chk)
        {
            $result = $this->findAll($cond);
            _setcahce($key, $result, $this->cache_type);
        }
        else
        {
            $result = $chk;
        }
        return $result;
    }
    
}

?>
