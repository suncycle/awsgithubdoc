<?php

/**
 * Description of ShippingLogic
 *
 * @author HHH
 */
class ShippingLanguageLogic extends BaseLogic
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'ShippingLanguageTable';
    }

}

?>
