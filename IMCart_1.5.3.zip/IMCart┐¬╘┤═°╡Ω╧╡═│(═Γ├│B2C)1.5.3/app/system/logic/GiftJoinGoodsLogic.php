<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GiftJoinGoodsLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class GiftJoinGoodsLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'GiftJoinGoodsView';
  }
  public function getListByOfferId($offer_id, $rule_id)
  {
    $cond = 'o.offer_id =' . $offer_id . ' and o.rule_id ='.$rule_id;
    return $this->findAll($cond);
  }
}

?>
