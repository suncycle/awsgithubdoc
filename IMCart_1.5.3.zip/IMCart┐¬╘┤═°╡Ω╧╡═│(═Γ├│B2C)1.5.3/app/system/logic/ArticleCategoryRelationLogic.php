<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ArticleCategoryRelationLogic
 *
 * @author czy
 */
class ArticleCategoryRelationLogic extends BaseLogic {

    public function __construct() {
        parent::__construct();
        $this->table = 'ArticleCategoryRelationTable';
    }

    public function getCategoryList($article_id)
    {
        $where  = 'article_id =' . $article_id;
        $result = $this->getList($where);
        $data   = array(); 
        foreach($result['list'] as $value)
        {
        	$data[]   = $value;
        }
        return $data;
    }

}

?>