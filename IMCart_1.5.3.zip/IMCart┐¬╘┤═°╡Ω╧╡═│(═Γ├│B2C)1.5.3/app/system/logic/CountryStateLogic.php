<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CountryStateLogic
 *
 * @author hjp <huangjp@35zh.com>
 */
class CountryStateLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table      = 'CountryStateTable';
        $this->cache_type = 'CountryState';
    }
    public function getCountryState($orderby='desc',$get_cache = TRUE)
    {
        $key = 'country_state_list_'.$orderby;
        $chk = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$chk)
        {
            $chk = $this->findAll('status=1 order by listorder ' . $orderby);
            _setcahce($key, $chk, $this->cache_type);
        }
        return $chk;
    }
    public function delCache()
    {
      _delcahce('country_state_list_desc', '', $this->cache_type);
      _delcahce('country_state_list_asc', '', $this->cache_type);
    }
}

?>
