<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BannerLogic
 *
 * @author cx
 * 
 */
class BannerLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'BannerTable';
    }  
}
        
?>
