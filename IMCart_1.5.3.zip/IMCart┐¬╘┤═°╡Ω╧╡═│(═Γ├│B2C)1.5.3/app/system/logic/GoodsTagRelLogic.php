<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsTagRelLogic
 *
 * @author xrx
 */
class GoodsTagRelLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'GoodsTagRelTable';
    }
	
	public function getTagList($goods_id)
    {
        $where  = 'goods_id =' . $goods_id;               
        return $this->findAll($where);
    }
}

?>