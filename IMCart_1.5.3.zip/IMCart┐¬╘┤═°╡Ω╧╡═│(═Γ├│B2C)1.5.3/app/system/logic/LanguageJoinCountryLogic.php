<?php

/**
 * Description of LanguageJoinCountry
 *
 * @author HHH
 */
class LanguageJoinCountryLogic extends BaseLogic
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'LanguageJoinCountryView';
    }
    
    /**
     * 获得所有语言信息
     */
    public function getAllLanguage($where=''){
        $languageList = $this->getList($where);
        return $languageList['list'];
    }

}

?>
