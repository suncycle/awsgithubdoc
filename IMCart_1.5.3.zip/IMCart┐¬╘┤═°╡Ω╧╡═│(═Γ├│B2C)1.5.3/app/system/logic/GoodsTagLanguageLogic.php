<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodTagLanguageLogic
 *
 * @author xrx
 */
class GoodsTagLanguageLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'GoodsTagLanguageTable';
    }
    public function save($data, $id = 0)
    {
        $tag_map = Zhtx::createDataMap();
        foreach($data as $key => $value)
        {
            $tag_map->addEntry($key, $value);
        }
        if($id)
        {
           $res = $this->update($tag_map, 'id='.$id); 
        }
        else
        {
            $res = $this->insert($tag_map);
        }
        return $res;
    }
    public function updateByCond($data)
    {
        $cond = 'goods_tag_id=' . $data['goods_tag_id'] . ' and language_id=' . $data['language_id'];
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        return $this->replaceByCond($map, $cond);
    }
}

?>
