<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OfferGiftLogic
 *
 * @author xrx <www.35zh.com>
 */
class OfferGiftLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'OfferGiftTable';
    }
    public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
    public function getListByOfferId($offer_id, $rule_id)
    {
      $cond = 'offer_id='. $offer_id . ' and rule_id='.$rule_id;
      return $this->findAll($cond);
    }
    public function updateByCond($data)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      $cond = 'offer_id=' . $data['offer_id'] . ' and rule_id='. $data['rule_id'] . ' and goods_id=' . $data['goods_id'];
      return $this->replaceByCond($map, $cond);
    }
}

?>
