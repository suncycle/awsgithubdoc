<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OfferRuleLogic
 *
 * @author xrx <www.35zh.com>
 */
class OfferRuleLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'OfferRuleTable';
    }
    public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
    public function getOneByOfferId($offer_id)
    {
       $cond = 'offer_id =' . $offer_id ;
       return $this->getOne($cond);
    }   
}

?>
