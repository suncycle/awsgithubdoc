<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderDeliveryItemJoinSkuProductLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OrderDeliveryItemJoinSkuProductLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'OrderDeliveryItemJoinSkuProductView';
   }
}

?>
