<?php
/*
 * Copyright 2012 Zhtx Systems, Inc.
 */
class AdminLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "AdminTable";
    }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $return = $this->updateById($map, $primary);
        }
        else
        {
            $return = $this->insert($map);
        }
        return $return;
    }
    public function login($user_name)
    {
        $cond = "user_name = '$user_name' and status=1";
        $user = $this->getOne($cond);
        return $user ? $user : FALSE;
    }
    public function checkMenuCache($role_id)
    {
        global $data_cache_dir;
        $cache_type = 'menus';
        $key = md5($role_id."_admin_right_menus"); //缓存key  
        $chk = _chkcahce($key, $cache_type, TRUE);                          
        if(!$chk)
        {
            $rolePrivLogic = $this->load('adminPrivMenu');
            $cond = 'r.role_id ='. $role_id;
            $res  = $rolePrivLogic->getList($cond); 
            $rights = array();
            foreach($res['list'] as $list)
            {
                $right_url = 'm=' . $list['m'] . '&c=' . $list['c'] . '&a=' . $list['a'];
                $rights[$list['id']] = $right_url;
            }
            _setcahce($key, $rights, $cache_type);                     
        }
    }

 

}

?>
