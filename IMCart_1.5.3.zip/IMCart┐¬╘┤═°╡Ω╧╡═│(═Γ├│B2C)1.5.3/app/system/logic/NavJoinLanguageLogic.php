<?php

/**
 * Description of NavJoinLanguageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class NavJoinLanguageLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'NavJoinLanguageView';
     $this->cache_type = 'nav';
   }
   /*
    * 导航
    */
   public function getNavByRootId($nav_id, $language_id, $get_cache=true)
   {
      global $data_cache_dir;
      $key     = $nav_id. '_' .$language_id . '_nav_list';
      $result  = _chkcahce($key, $this->cache_type);
      if(!$get_cache || !$result)
      {
        $cond      = 'n.status=1 and n.path_id like "' . $nav_id . ',%"  and  l.language_id=' . $language_id .' order by listorder asc';
        $result    = $this->findAll($cond, TRUE);
        $parent_id = -1;
        foreach($result as $key=>$list)
        {
          $parent_id = $result[$key]["parent_id"];
          $result[$parent_id]["son"][] = $list;
           _setcahce($key, $result, $this->cache_type);
        }
      }      
      return $result;
   }
   public function getNavByParentId($parent_id, $language_id, $orderfield='listorder', $orderby='desc', $limit=20, $get_cache=true)
   {
      global $data_cache_dir;
      $cond    = 'n.status=1 and n.parent_id =' . $parent_id . ' and  l.language_id=' . $language_id ." ORDER BY n.$orderfield  $orderby "  . " limit " . $limit;
      $key     = md5($cond);
      $result  = _chkcahce($key, $this->cache_type);
      if(!$get_cache || !$result)
      {
        $result    = $this->findAll($cond, TRUE);
        _setcahce($key, $result, $this->cache_type);
      }      
      return $result;
   }
}

?>
