<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GrowthDetailLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class GrowthDetailLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'GrowthDetailTable';
   }
    public function save($data, $id = 0)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($id)
        {
            $res = $this->update($map, 'id='.$id); 
        }
        else
        {
            $res = $this->insert($map);
        }
        return $res;
    }
}

?>
