<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BrandJoinLanguageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class SeoTplJoinLanguageLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'SeoTplJoinLanguageView';
     $this->cache_type = 'seotpl';
   }
   
   public function getItem($id, $language_id=0,$get_cache=true)
	{
		global $data_cache_dir;
       	$key     = $language_id . '_seotpl_detail';
        $result  = _chkcahce($key, $this->cache_type);
        if(!$get_cache || !$result)
        {
        	$cond = 's.id =' . $id . '  AND l.language_id =' . $language_id;
          	$result = $this->getOne($cond);
			return $result;
		}
		else
		{
			return $result	;
		}
	}
   
}

?>
