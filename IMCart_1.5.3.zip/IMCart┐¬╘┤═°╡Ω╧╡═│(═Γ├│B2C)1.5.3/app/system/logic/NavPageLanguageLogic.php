<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NavPageLanguageLogic
 *
 * @author cx
 * 
 */
class NavPageLanguageLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'NavPageLanguageTable';
    }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }        
        return $result;
    }
    public function delCache($navpage_id, $language_id)
    {
       global $data_cache_dir;
        $type = "navpage";        
        if(!$language_id)
        {
          $cond = 'nav_page_id=' . $navpage_id;
          foreach ($this->findAll($cond) as $value)
          {
            $key = $navpage_id . "_". $value['language_id'] . '_navpage_detail';
            _delcahce($key, '', $type);       
          }
        }
        else
        {
          $key = $navpage_id. '_' .$language_id . '_navpage_detail';
          _delcahce($key, '', $type); 
        }
        
    }
}
        
?>
