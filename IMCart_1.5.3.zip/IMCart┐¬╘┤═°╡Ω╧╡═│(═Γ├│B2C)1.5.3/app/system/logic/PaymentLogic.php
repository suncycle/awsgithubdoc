<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Payment
 *
 * @author huangjp@35zh.cn
 */
class PaymentLogic extends BaseLogic
{
    public function __construct() 
    {
        parent::__construct();
        $this->table = 'PaymentTable';
    }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $result = $this->updateById($map, $primary);
        }
        else
        {
            $result = $this->insert($map);
        }
        return $result;
    }

    /*
	$cart_param 购物车参数
	$shipping_param 关联的配置信息 json的文本格式
	$shipping_formula 关联的公式
	return 如果为false,那么上级必须删除这个配送方式
	*/
	public  function getPaymentFee($order_param,$payment_param,$payment_formula)
	{
		$script_file = APP_ROOT."api/paymentformula/".$payment_formula."/script.php";     
		if (file_exists($script_file))
		{          
			require_once($script_file); 
			$payment = new $payment_formula();
			return $payment->getPaymentFee($order_param,$payment_param);
		}
		
		return 0;
	}
   
   
    
}

?>
