<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ArticleJoinLanguageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class ArticleJoinLanguageLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'ArticleJoinLanguageView';
   }
   public function getArticleById($article_id, $language_id)
   {
      $cond = 'a.id =' . $article_id . ' and l.language_id=' . $language_id;
      return $this->getOne($cond);
   }
   
   public function getItem($id, $language_id=0)
	{
		 $cond = 'a.id =' . $id . ' and l.language_id=' . $language_id;
     	 return $this->getOne($cond);
	}
    /**
     * 获取相关分类的文章
     * @param type $path_id
     * @param type $language_id 
     * return array
     */
    public function getListByCategroy($path_id, $language_id, $offset=0, $limit=20)
    {
      $cond = 'a.category_url like "' . $path_id . '%" and l.language_id=' . $language_id . ' and l.status=1 limit ' . $offset . ',' . $limit;
      return $this->findAll($cond);
    }
    
    
    public function getAdjacentById($path_id, $language_id, $id,$pon="next"){
        if($pon == "next")
        $cond = 'a.category_url like "' . $path_id . '%" and l.language_id=' . $language_id . ' and a.id > '.$id.' and l.status=1 limit 1';
        else
        $cond = 'a.category_url like "' . $path_id . '%" and l.language_id=' . $language_id . ' and a.id < '.$id.' and  l.status=1 limit 1';
        $res = $this->findAll($cond);
        if($res){
            $res[0]['base_name'] = $res[0]['default_base_name'];
        }
        return $res;
    }
    
}

?>