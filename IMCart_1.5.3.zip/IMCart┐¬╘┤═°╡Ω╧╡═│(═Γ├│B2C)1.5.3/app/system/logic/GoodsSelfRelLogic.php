<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsSelfRelLogic
 *
 * @author Administrator
 */
class GoodsSelfRelLogic extends BaseLogic
{
    private $goods_table;
    private $goods_dao;
    public function __construct()
    {
        parent::__construct();
        $this->table       = 'GoodsSelfRelTable';
        $this->goods_table = Zhtx::getTable("GoodsTable");
        $this->goods_dao   = Zhtx::getDAO($this->goods_table);
    }
    public function save($data)
    {
        $map = Zhtx::createDataMap();
        $map->addEntry('goods_id', $data['goods_id'], DB::INT);
        $map->addEntry('goods_rel_id', $data['goods_rel_id'], DB::INT);             
        $result =  $this->insert($map); 
        return $result;
    }
    /**
     * 查询关联的商品
     * @param type $goods_id
     * @return int 
     */
    public function getRelGoods($goods_id)
    {
        $where   = 'goods_id=' . $goods_id;
        $rels    = $this->getList($where);
        $rel_ids = array();
        foreach ($rels['list'] as $value)
        {
            $rel_ids[] = $value['goods_rel_id'];
        }
        $result      = array();
        if(!empty($rel_ids))
        {
            $mutual_rel_ids = array();
            $rel_ids_str    = implode(',', $rel_ids);        
            $where2         = 'goods_id in ('. $rel_ids_str . ') AND goods_rel_id =' . $goods_id;
            $res2           = $this->getList($where2);        
            foreach ($res2['list'] as $value)
            {
                $mutual_rel_ids[$value['goods_id']] = $value['goods_rel_id'];
            }
            $goods_where = 'id in ('. $rel_ids_str .')';        
            $list        = $this->load('goods')->findAll($goods_where);
            foreach ($list as $item)
            {
                $item['ismutual']    = 0;
                if(isset($mutual_rel_ids[$item['id']]))
                {
                    $item['ismutual'] = 1;
                }
                $result[$item['id']]  = $item;
            }
        }
        
//        _debug($result);
        return $result;
    }
}

?>
