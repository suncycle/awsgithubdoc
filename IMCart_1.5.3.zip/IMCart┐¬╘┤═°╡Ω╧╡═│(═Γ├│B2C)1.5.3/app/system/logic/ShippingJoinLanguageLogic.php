<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ShippingJoinLanguageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class ShippingJoinLanguageLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'ShippingJoinLanguageView';
  }
  public function getShippingByAreaIds($area_ids, $language_id)
  {
     $cond = '(s.area_id in (' . implode(',', $area_ids) . ') or s.area_id=0) and s.status=1 and l.language_id='.$language_id. ' order by s.listorder desc';
     return $this->findAll($cond);
  }
}

?>
