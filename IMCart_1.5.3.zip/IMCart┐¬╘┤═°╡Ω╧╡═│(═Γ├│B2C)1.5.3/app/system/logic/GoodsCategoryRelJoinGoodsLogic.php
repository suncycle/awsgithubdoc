<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsCategoryRelJoinGoodsLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */

class GoodsCategoryRelJoinGoodsLogic  extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'GoodsCategoryRelJoinGoodsView';
   }
    /**
     * 统计分类商品数
     * @param type $category_id
     * @param type $category_path
     */
    public function getGoodsCount($category_path)
    {
      $cond = 'c.category_path like "' . $category_path . '%" and g.status=1';
      return $this->getCount($cond);
    }
}

?>
