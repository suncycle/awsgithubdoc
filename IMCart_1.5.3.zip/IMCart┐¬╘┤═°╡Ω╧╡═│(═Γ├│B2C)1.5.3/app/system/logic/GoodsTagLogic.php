<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsTagLogic
 *
 * @author xrx
 */
class GoodsTagLogic extends BaseLogic
{
    public function __construct() {
        parent::__construct();
        $this->table = 'GoodsTagTable';               
    }
    
    public function save($data, $id = 0)
    {
        $tag_map = Zhtx::createDataMap();
        foreach($data as $key => $value)
        {
            $tag_map->addEntry($key, $value);
        }
        if($id)
        {
           $res = $this->update($tag_map, 'id='.$id); 
        }
        else
        {
            $res = $this->insert($tag_map);
        }
        return $res;
    }
}

?>
