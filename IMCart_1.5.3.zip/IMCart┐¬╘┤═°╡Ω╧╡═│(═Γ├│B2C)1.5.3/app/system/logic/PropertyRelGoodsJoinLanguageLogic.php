<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PropertyRelGoodsJoinLanguageLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class PropertyRelGoodsJoinLanguageLogic extends BaseLogic {

    public function __construct() {
        parent::__construct();
        $this->table = 'PropertyRelGoodsJoinLanguageView';
    }

    public function getGoods($cond, $page_size, $curr_page, $get_cache = true) {
        global $data_cache_dir;
        $cols = array(
            'p.goods_id  as  id',
            'p.property_id  as  property_id',
            'p.vid  as  vid',
            'g.base_name  as  default_base_name',
            'g.codeno  as  codeno',
            'g.image  as  image',
            'g.price  as  price',
            'g.cost_price  as  cost_price',
            'g.market_price  as  market_price',
            'g.weight  as  weight',
            'g.brand_id  as  brandid',
            'g.goods_type_id  as  type_id',
            'g.listorder  as  listorder',
            'g.status  as  status',
            'g.page_url  as  page_url',
            'g.template_page  as  template_page',
            'g.up_time  as  up_time',
            'g.modify_time  as  modify_time',
            'g.create_time  as  create_time',
            'g.visit_counts  as  visit_counts',
            'g.buy_counts  as  buy_counts',
            'g.old_price  as  old_price',
            'g.wishlist_counts  as  wishlist_counts',
            'g.comment_counts  as  comment_counts',
            'g.comment_value  as  comment_value',
            'g.is_free_shipping  as  is_free_shipping',
            'g.start_time  as  start_time',
            'g.end_time  as  end_time',
            'g.discount  as  discount',
            'g.special_status  as  special_status',
            'g.stock_nums as stock_nums',
            'l.base_name  as  base_name',
            'l.detail  as  detail',
            'l.title  as  title',
            'l.keywords  as  keywords',
            'l.descript  as  descript',
        );
        if ($curr_page > 10) {
            return $this->getCurrentDatas($cond, $page_size, $curr_page, $cols);
        }
        $key = md5($cond . '_' . $page_size . '_' . $curr_page);
        $chk = _chkcahce($key, $this->cache_type);
        if (!$get_cache || !$chk) {
            $chk = $this->getCurrentDatas($cond, $page_size, $curr_page, $cols);
            _setcahce($key, $chk, $this->cache_type);
        }
        return $chk;
    }

}

?>
