<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OfferLogic
 *
 * @author xrx <www.35zh.com>
 */
class OfferLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'OfferTable';
    }
    public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
    /**
     * 删除缓存
     * @global type $data_cache_dir
     * @param type $language_id 
     */
    public function delCache($language_id)
    {
      global $data_cache_dir;
      $type = 'promotions';
      $key  = $language_id . '_promotion_list';
      _delcahce($key, '', $type);
    }
    
}

?>
