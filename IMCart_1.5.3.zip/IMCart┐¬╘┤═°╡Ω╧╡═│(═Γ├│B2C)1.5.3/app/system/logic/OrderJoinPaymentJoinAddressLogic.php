<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderJoinAddressUserLogic
 * order\order_address\user relation query
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OrderJoinPaymentJoinAddressLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'OrderJoinPaymentJoinAddressView';
   }
   
   public function getOrderStatusCount($where)
    {
        $sqlmd5 = md5($where);
        $count  = Common::queryInt(_s($sqlmd5));
        if(!$count)
        {
           $count_array = $this->getOne($where, array('count(DISTINCT p.order_id) as count'));
           $count     = $count_array['count'];
            _setSession($sqlmd5, $count);
        }
        return $count;
    }
   
}

?>
