<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InsuranceJoinLanguageLogic
 *
 * @author rongxiang.xie <QQ:1251679791,359285617 www.35zh.com>
 */
class InsuranceJoinLanguageLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'InsuranceJoinLanguageView';
  }
  /**
   * 获取配置
   * @param type $language_id
   * @return type 
   */
  public function getConfig($language_id)
  {
    $cond = 'i.status=1 and l.language_id=' . $language_id;
    return $this->getOne($cond);
  }
   /**
    * 获取费用
    * @param type $cart_param 购物车参数
    * @param type $param 公式所需数据
    * @param type $formula 公式
    * @return int 
    */
  public  function getCost($cart_param,$param,$formula)
  {
      $script_file = APP_ROOT."api/insurance/".$formula."/script.php";
      if (file_exists($script_file))
      {
          require_once($script_file);
          $insurance = new $formula();
          return $insurance->getCost($cart_param,$param);
      }
      return 0;
  }
}

?>
