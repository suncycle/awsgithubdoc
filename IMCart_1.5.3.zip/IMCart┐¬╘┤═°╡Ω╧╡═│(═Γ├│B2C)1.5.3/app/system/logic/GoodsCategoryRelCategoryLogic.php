<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsCategoryRelCategoryLogic
 *
 * @author xrx
 */
class GoodsCategoryRelCategoryLogic extends BaseLogic
{
    public function __construct()
    {
        parent::__construct();
        $this->table = 'GoodsCategoryRelCategoryView';
    }
    
    public function getCategoriesByGoodsId($goods_id)
    {
        $cond = 'g.goods_id = '. $goods_id;
        $result = $this->getList($cond);
        return $result['list'];
    }
}

?>
