<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderItemJoinOrderJoinGoodsCategoryRelLogic
 * @author hjp <huangjp@35zh.cn>
 */
class OrderItemJoinOrderJoinGoodsCategoryRelLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'OrderItemJoinOrderJoinGoodsCategoryRelView';
   }
}

?>
