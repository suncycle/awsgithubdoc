<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ShippingJoinCorpLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class ShippingJoinCorpLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'ShippingJoinCorpView';
   }
   public function getOneByShippingId($shipping_id)
   {
      $cond = 's.id = ' . $shipping_id;
      return $this->getOne($cond);
   }
}

?>
