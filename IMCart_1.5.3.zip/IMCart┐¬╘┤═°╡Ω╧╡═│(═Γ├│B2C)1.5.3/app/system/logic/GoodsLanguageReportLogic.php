<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsLanguageReportLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class GoodsLanguageReportLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'GoodsLanguageReportTable';
   }
    public function save($data, $primary)
    {
        $map = Zhtx::createDataMap();
        $map->createEntry($data);
        if($primary)
        {
            $return = $this->updateById($map, $primary);
        }
        else
        {
            $return = $this->insert($map);
        }
        return $return;
    }
}

?>
