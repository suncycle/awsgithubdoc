<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderDeliveryItemLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class OrderDeliveryItemLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table   =  'OrderDeliveyItemTable';
   }
   public function save($data, $primary = 0)
    {
      $map = Zhtx::createDataMap();
      $map->createEntry($data);
      if($primary)
      {
        return $this->updateById($map, $primary);
      }
      else
      {
        return $this->insert($map);
      }
    }
   /**
    * 读取订单项 的商品发货信息（shiped_num 已发货数 unshiped_num 未发货数量）
    * @param type $item_id
    * @param type $goos_id
    * @param type $sku_code
    * @param type $buy_num
    * @return type 
    */
   public function getShipInfo($item_id, $goos_id, $sku_code, $buy_num)
   {
     $cond = 'order_item_id =' . $item_id . ' and goods_id=' . $goos_id . ' and sku_code="' . $sku_code . '"';
     $delivey_items = $this->findAll($cond);
     $delivery_ids  = array();
     foreach ($delivey_items as $item)
     {
        $delivery_ids[$item['delivery_id']] = $item['delivery_id'];
     }
     $deliveryLogic = $this->load('orderDelivery');
     $deliverys     = $deliveryLogic->findAll('id in ('. implode(',', !empty($delivery_ids) ? $delivery_ids : array(0)) . ')', TRUE);
     $shiped_num = 0;
     foreach ( $delivey_items as $item)
     {
        if(isset($deliverys[$item['delivery_id']]) && $deliverys[$item['delivery_id']]['delivery_type'] == 1 && $deliverys[$item['delivery_id']]['status'] == 1)
        {
           $shiped_num += $item['buy_num'];
        }
        else if(isset($deliverys[$item['delivery_id']]) && $deliverys[$item['delivery_id']]['delivery_type'] == 2 && $deliverys[$item['delivery_id']]['status'] == 1)
        {
           $shiped_num -= $item['buy_num'];
        }
     }
     return array(
         'shiped_num'    => $shiped_num,
         'unshiped_num' => $buy_num - $shiped_num,
     );
   }
}

?>
