<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CatJoinPropertyJoinGoodsJoinLangLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class CatJoinPropertyJoinGoodsJoinLangLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'CatJoinPropertyJoinGoodsJoinLangView';
   }
   
}

?>
