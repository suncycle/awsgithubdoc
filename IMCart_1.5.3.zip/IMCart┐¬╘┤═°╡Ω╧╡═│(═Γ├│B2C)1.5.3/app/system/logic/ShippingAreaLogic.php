<?php

/**
 * Description of ShippingAreaLogic
 *
 * @author HHH
 */
class ShippingAreaLogic extends BaseLogic
{

    public function __construct()
    {
        parent::__construct();
        $this->table = 'ShippingAreaTable';
    }

}

?>
