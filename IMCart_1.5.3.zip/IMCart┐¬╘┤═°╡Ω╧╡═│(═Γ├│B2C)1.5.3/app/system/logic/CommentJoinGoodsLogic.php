<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CommentJoinGoodsLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class CommentJoinGoodsLogic extends BaseLogic
{
   public function __construct()
   {
     parent::__construct();
     $this->table = 'CommentJoinGoodsView';
   }
   public function getListByUserId($user_id, $offset=0, $limit=20)
   {
      $cond = 'c.user_id=' . $user_id . ' order by c.create_time desc limit '. $offset . ',' . $limit;
      return $this->findAll($cond);
   }
}

?>
