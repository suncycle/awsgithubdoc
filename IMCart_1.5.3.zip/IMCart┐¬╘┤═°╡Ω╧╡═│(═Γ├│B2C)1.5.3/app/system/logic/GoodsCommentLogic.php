<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoodsCommentLogic
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class GoodsCommentLogic extends BaseLogic
{
  public function __construct()
  {
    parent::__construct();
    $this->table = 'GoodsCommentTable';
  }
  public function save($data, $primary = 0)
  {
    $map = Zhtx::createDataMap();
    $map->createEntry($data);
    if($primary)
    {
      return $this->updateById($map, $primary);
    }
    else
    {
      return $this->insert($map);
    }
  }
  public function getComment($goods_id, $language_id, $offset=0, $limit=20)
  {
     $cond = 'goods_id=' . $goods_id . ' and status=1 order by create_time desc limit ' . $offset . ',' . $limit;
     return $this->findAll($cond);
  }
}

?>