<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author NT <QQ:415080528 www.35zh.com>
 */
class UserController extends AppController {

    private $languageLogic;
    private $userLogic;

    public function __construct() {
        parent::__construct();
        $this->languageLogic = $this->load('language');
        $this->userLogic = $this->load('user');
    }

    public function actionList() {
        $cond = '1=1';
        $current_page = Common::queryInt(_g('page'), 1);
        $limit = Common::queryInt(_g('limit'), 20);
        $date_id = Common::queryInt(_g('date_id'));
        if (_g('start_time')) {
            $cond .= ' and create_time>=' . strtotime(_g('start_time'));
        }  else {
        }
        if (_g('end_time')) {
            $cond .= ' and create_time<' . strtotime(_g('end_time'));
        }
        if (_g('language_id')) {
            $cond .= ' and language_id = ' . _g('language_id');
        }
        switch ($date_id) {
            case 1:
                if (!_g('start_time')) {
                    $cond.=" and YEAR(FROM_UNIXTIME(create_time, '%Y-%m-%d'))=YEAR(now())";
                }
                $counttype = 1;
                $cond .= ' group by y order by y desc';
                break;
            case 2:
                if (!_g('start_time')) {
                    $cond.=" and YEAR(FROM_UNIXTIME(create_time, '%Y-%m-%d'))=YEAR(now()) and MONTH(FROM_UNIXTIME(create_time, '%Y-%m-%d'))=MONTH(now())";
                }
                $cond .= ' group by m order by m desc';
                $counttype = 2;
                break;
            default:
                if (!_g('start_time')) {
                    $cond.=" and YEAR(FROM_UNIXTIME(create_time, '%Y-%m-%d'))=YEAR(now()) and MONTH(FROM_UNIXTIME(create_time, '%Y-%m-%d'))=MONTH(now())";
                }
                $cond .= ' group by t order by t desc';
                $counttype = 3;
                break;
        }
        $cols = array(
            'count(*) as num',
            "YEAR(FROM_UNIXTIME(create_time, '%Y-%m-%d')) as y",
            "MONTH(FROM_UNIXTIME(create_time, '%Y-%m-%d')) as m",
            "DAYOFMONTH(FROM_UNIXTIME(create_time, '%Y-%m-%d')) as t",
        );        
        $count = $this->userLogic->findAll($cond,false,"",$cols);
        $count = count($count);
        $pages = Common::getPages($count, $current_page, $limit);
        $list = $this->userLogic->getCurrentDatas($cond, $limit, $current_page, $cols);
        
        $ccount = 0;
        foreach ($list as $value) {
            $ccount+=$value[num];
        }
        foreach ($list as $k=>$v) {
            $list[$k]['persent'] = $v['num']/$ccount*100;
        }
        
        $languageLogic = $this->load('language');
        $languages = $languageLogic->findAll('', true);
        
        Core::$tpl->set('page', $current_page);
        Core::$tpl->set('languages', $languages);
        Core::$tpl->set('sites', $this->load('language')->findAll());
        Core::$tpl->set('res', $list);
        Core::$tpl->set('pages', $pages);
        Core::$tpl->set('selected_s_time', _g('start_time'));
        Core::$tpl->set('selected_e_time', _g('end_time'));
        Core::$tpl->set('date_id', $date_id);
        Core::$tpl->set('counttype', $counttype);
        Core::$tpl->set('month', $month);
    }

}

?>
