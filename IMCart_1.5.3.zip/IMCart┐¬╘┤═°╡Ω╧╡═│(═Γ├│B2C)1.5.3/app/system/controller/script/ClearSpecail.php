<?php

/**
 * 清理限时特价
 *
 * @author ZJH
 */
class ClearSpecailController extends AppController {

    private $specialLogic;
    private $skuLogic;
    private $goodsLogic;

    public function __construct() {
        parent::__construct();
        $this->specialLogic = $this->load('specialOffer');
        $this->skuLogic = $this->load('sku');
        $this->goodsLogic = $this->load('goods');
    }

    public function actionDefault() {
//        //限时特价
        $NowTime = SYS_TIME;
        $SpecialData = $this->specialLogic->findAll("1=1", array("*"));
        foreach ($SpecialData as $Sval) {
            $Special_ids[] = $Sval['id'];
            // Common::log($Sval['base_name'] . "已经开始" . $Sval['start_time'] . "==" . $Sval['end_time'] . " <=" . $NowTime . "<BR>");
            if ($Sval['start_time'] <= $NowTime && $Sval['end_time'] >= $NowTime) {
                if (!$Sval['status']) {
                    $goodsLogic = $this->load('goods');
                    $discount = $Sval['discount'] ? $Sval['discount'] / 10 : 1;
                    $map = Zhtx::createDataMap();
                    $map->addEntry('price', 'price*' . $discount, DB::DECIMAL);
                    $map->addEntry('special_status', 1, DB::INT);
                    $cond = 'special_offer_id=' . $Sval['id'];
                    $rel_goods = $goodsLogic->findAll($cond);
                    $rel_goods_ids = array();
                    foreach ($rel_goods as $value) {
                        $rel_goods_ids[$value['id']] = $value['id'];
                    }
                    $res = $goodsLogic->update($map, $cond);
                    if ($res) {
                        //修改sku价格
                        $sku_map = Zhtx::createDataMap();
                        $sku_map->addEntry('old_price', 'price', DB::DECIMAL);
                        $sku_map->addEntry('price', 'price*' . $discount, DB::DECIMAL);
                        $sku_map->addEntry('special_status', 1, DB::INT);
                        $where = 'goods_id in (' . implode(',', $rel_goods_ids) . ')';
                        $this->skuLogic->update($sku_map, $where);

                        $this->clearGoodsCache();
                        $special_map = Zhtx::createDataMap();
                        $special_map->addEntry('status', 1, DB::INT);
                        if (!$this->specialLogic->updateById($special_map, $Sval['id'])) {
                            return;
                        }
                    }
                }
            }
            if ($Sval['end_time'] <= $NowTime) {
                if ($Sval['status']) {
                    $goodsLogic = $this->load('goods');
                    $cond = 'old_price> 0 and special_offer_id = ' . $Sval['id'];
                    $map = Zhtx::createDataMap();
                    $map->addEntry('price', 'old_price', DB::DECIMAL);
                    $res = $goodsLogic->update($map, $cond);

                    $map = Zhtx::createDataMap();
                    $map->addEntry('old_price', 0, DB::DECIMAL);
                    $map->addEntry('modify_time', SYS_TIME, DB::DECIMAL);
                    $map->addEntry('special_status', 0, DB::INT);
                    $map->addEntry('start_time', 0, DB::INT);
                    $map->addEntry('end_time', 0, DB::INT);
                    $map->addEntry('special_offer_id', 0, DB::INT);
                    $map->addEntry('discount', 10, DB::DECIMAL);
                    $cond = 'special_offer_id = ' . $Sval['id'];
                    $rel_goods = $goodsLogic->findAll($cond);
                    $rel_goods_ids = array();
                    foreach ($rel_goods as $value) {
                        $rel_goods_ids[$value['id']] = $value['id'];
                    }
                    $res = $goodsLogic->update($map, $cond);
                    if ($res) {
                        //修改sku价格
                        $where = 'old_price>0 and goods_id in (' . implode(',', $rel_goods_ids) . ')';
                        $sku_map = Zhtx::createDataMap();
                        $sku_map->addEntry('price', 'old_price', DB::DECIMAL);
                        $this->skuLogic->update($sku_map, $where);
                        $sku_map = Zhtx::createDataMap();
                        $sku_map->addEntry('old_price', 0, DB::DECIMAL);
                        $sku_map->addEntry('special_status', 0, DB::INT);
                        $where = 'goods_id in (' . implode(',', $rel_goods_ids) . ')';
                        $this->skuLogic->update($sku_map, $where);
                        $this->clearGoodsCache();
                        $special_map = Zhtx::createDataMap();
                        $special_map->addEntry('status', 0, DB::INT);
                        if (!$this->specialLogic->updateById($special_map, $Sval['id'])) {
                            return;
                        }
                    }
                }
            }
            //删除到期商品
            $cond = 'end_time<' . SYS_TIME . ' and special_offer_id=' . $Sval['id'];
            $explireGoods = $this->goodsLogic->findAll($cond);
            $rel_goods_ids = array();
            if ($explireGoods) {
                foreach ($explireGoods as $key => $value) {
                    $rel_goods_ids[] = $value['id'];
                    if ($value['old_price'] > 0) {
                        $map = Zhtx::createDataMap();
                        $map->addEntry('price', $value['old_price'], DB::DECIMAL);
                        $cond = 'id = ' . $value['id'];
                        $this->goodsLogic->update($map, $cond);
                    }
                    //修改goods表
                    $map = Zhtx::createDataMap();
                    $map->addEntry('old_price', 0, DB::DECIMAL);
                    $map->addEntry('start_time', 0, DB::INT);
                    $map->addEntry('end_time', 0, DB::INT);
                    $map->addEntry('discount', 10, DB::INT);
                    $map->addEntry('special_status', 0, DB::INT);
                    $map->addEntry('special_offer_id', 0, DB::INT);
                    $cond = 'id = ' . $value['id'];
                    $res = $this->goodsLogic->update($map, $cond);
                }
                if (count($rel_goods_ids) > 0) {
                    //修改sku价格
                    $sku_map = Zhtx::createDataMap();
                    $sku_map->addEntry('price', 'old_price', DB::DECIMAL);
                    $cond = ' old_price>0 and goods_id in (' . implode(',', $rel_goods_ids) . ')';
                    $this->skuLogic->update($sku_map, $cond);
                    $sku_map = Zhtx::createDataMap();
                    $sku_map->addEntry('old_price', 0, DB::DECIMAL);
                    $sku_map->addEntry('special_status', 0, DB::INT);
                    $where = 'goods_id in (' . implode(',', $rel_goods_ids) . ')';
                    $this->skuLogic->update($sku_map, $where);
                }
                $this->clearGoodsCache();
            }
        }
        //清除冗余特价商品
        if (count($Special_ids)) {
            $cond = ' special_offer_id<>0 and special_offer_id not in (' . implode(',', $Special_ids) . ')';
            $notInSpecialGoods = $this->goodsLogic->findAll($cond);
            $rel_goods_ids = array();
            foreach ($notInSpecialGoods as $key => $value) {
                $rel_goods_ids[] = $value['id'];
                if ($value['old_price'] > 0) {
                    $map = Zhtx::createDataMap();
                    $map->addEntry('price', $value['old_price'], DB::DECIMAL);
                    $cond = 'id = ' . $value['id'];
                    $this->goodsLogic->update($map, $cond);
                }
                //修改goods表
                $map = Zhtx::createDataMap();
                $map->addEntry('old_price', 0, DB::DECIMAL);
                $map->addEntry('start_time', 0, DB::INT);
                $map->addEntry('end_time', 0, DB::INT);
                $map->addEntry('discount', 10, DB::INT);
                $map->addEntry('special_status', 0, DB::INT);
                $map->addEntry('special_offer_id', 0, DB::INT);
                $cond = 'id = ' . $value['id'];
                $res = $this->goodsLogic->update($map, $cond);
            }
            if (count($rel_goods_ids) > 0) {
                //修改sku价格
                $sku_map = Zhtx::createDataMap();
                $sku_map->addEntry('price', 'old_price', DB::DECIMAL);
                $cond = ' old_price>0 and goods_id in (' . implode(',', $rel_goods_ids) . ')';
                $this->skuLogic->update($sku_map, $cond);
                $sku_map = Zhtx::createDataMap();
                $sku_map->addEntry('old_price', 0, DB::DECIMAL);
                $sku_map->addEntry('special_status', 0, DB::INT);
                $where = 'goods_id in (' . implode(',', $rel_goods_ids) . ')';
                $this->skuLogic->update($sku_map, $where);
            }
            $this->clearGoodsCache();
        }
        echo '限时特价自动 开启/关闭-OK<br>';
        echo '删除到期商品-OK<br>';
        echo '清除冗余特价商品-OK<br>';
    }

    public function clearGoodsCache() {
        _crearCahce('goods_list');
        _crearCahce('goods_info');
    }

}
