<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product
 *
 * @author xrx
 */
class PicklistController extends AppController {
    private $langLogic;
    private $goodsPackageSaleLogic;
    private $goodsPackageSaleGoodsRelLogic;
    private $goodsPackageSaleLanguageLogic;

    public function __construct() {
        parent::__construct();
        $this->langLogic = $this->load('language');
        $this->goodsPackageSaleLogic = $this->load('goodsPackageSale');
        $this->goodsPackageSaleGoodsRelLogic = $this->load('goodsPackageSaleGoodsRel');
        $this->goodsPackageSaleLanguageLogic = $this->load('goodsPackageSaleLanguage');
    }

    /**
     * 组合列表页
     * 多语言
     */
    public function actionList() {
        $id = _g("id");
        $res = $this->goodsPackageSaleLogic->getOne("id = '{$id}' and status = 1");
        if(!$res){
            return $this->exception();
        }
//        if(time() < $res['start_time'] || time() > $res['end_time'] ){
//            return $this->exception();
//        }
        Core::$tpl->set('big_title', "Specail Packages");
        Core::$tpl->set('packageinfo', $res);
    }
}

?>