<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NavpageController
 *
 * @author hjp <huangjp@35zh.com>
 */
class NavpageController extends AppController
{
    private $lang;
    private $navPageJoinLangLogic;
    private $languageLogic;

    public function __construct()
    {
        parent::__construct();
        $this->navPageJoinLangLogic = $this->load('navPageJoinLanguage');
        $this->languageLogic = $this->load('language');
        $this->lang=Common::lang(Core::$controller, Core::$module, Core::$language);
    }
    
    public function actionHelp()
    {
        Core::$tpl->set('big_title', $this->lang['help']);
    }
    
    public function actionDetail()
    {
        $id = Common::queryInt(_g('navpage_id'));
        $navpage = $this->navPageJoinLangLogic->getItem($id, $this->languageLogic->language_id);
        if (!$navpage)
        {
           return $this->exception();
        }
        Core::$tpl->set('big_title', $navpage['base_name']);
        Core::$tpl->set('article', $navpage);
    }

}

?>
