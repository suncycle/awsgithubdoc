<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product
 *
 * @author NT<www.35zh.com>
 */
class SearchController extends AppController
{

    private $languageLogic;
    private $goodsJoinLangLogic;

    public function __construct()
    {
        parent::__construct();
        $this->languageLogic = $this->load('language');
        $this->goodsJoinLangLogic = $this->load('goodsJoinLanguage');
        $this->lang = Common::lang(Core::$controller, Core::$module, Core::$language);
    }

    
    public function actionDefault()
    {
        $search_history = $this->goodsJoinLangLogic->getSearchHistory();
        Core::$tpl->set('search_history',$search_history);
        Core::$tpl->set('big_title', $this->lang['search']);
    }

     public function actionClearHistory()
    {
        $this->goodsJoinLangLogic->clearSearchHistory();
        return $this->success('clear_success','/m-search-default.html');
    }
}

?>