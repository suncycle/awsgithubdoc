<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IndexController
 *
 * @author NT <nit@35zh.com>
 */
class HistoryController extends AppController {

    private $goodsJoinLangLogic;
    private $languageLogic;

    public function __construct() {
        parent::__construct();
        $this->languageLogic = $this->load('language');
        $this->goodsJoinLangLogic = $this->load('goodsJoinLanguage');
		$this->lang = Common::lang(Core::$controller, Core::$module, Core::$language);
    }

    public function actionList() {
        $language_id = $this->languageLogic->language_id;
        $limit = 10;
        $params = array(
            'language_id' => $language_id,
            'limit' => $limit,
        );
        $history = $this->goodsJoinLangLogic->getGoodsListByHistory($params);
        $history = array_reverse($history);//倒叙
        Core::$tpl->set('history',$history);
		Core::$tpl->set('big_title', $this->lang['history_title']);
    }

     public function actionClear()
    {
        $this->goodsJoinLangLogic->clearHistory();
        return $this->success('clear_success','/m-history-list.html');
    }
}

?>
