<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IndexController
 *
 * @author hjp <huangjp@35zh.com>
 */
class IndexController extends AppController
{
    public function __construct()
    {
        parent::__construct();
    }
    public function actionDefault()
    { 
        if($_GET['page_code']==404)
		{
			$this->exception();	
		}
		Core::$htmlFile = 'index';
        Core::$isdisplay = 0;
        Core::$tpl->render(Core::$htmlFile . ".htm");
    }
}

?>
