<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IndexController
 *
 * @author hjp <huangjp@35zh.com>
 */
class CategoryController extends AppController
{
    private $lang;
    private $languageLogic;
    public function __construct()
    {
        parent::__construct();
        $this->languageLogic         = $this->load('language');
        $this->lang=Common::lang(Core::$controller, Core::$module, Core::$language);
    }
    
    public function actionDefault()
    {        
        Core::$tpl->set('big_title', $this->lang['all_categories']); 
    }
    
    public function actionList()
    {
        $language_id   = $this->languageLogic->language_id;
        $category_id   = Common::queryInt(_g('category_id'));
        $ccond = 'c.id='.$category_id . ' and l.language_id='. $language_id;
        $categoryLogic = $this->load('goodsCategoryJoinLang');
        $category      = $categoryLogic->getOne($ccond);
        if(!$category){
             return $this->exception();	
        }
        Core::$tpl->set('big_title', $category['base_name']); 
        Core::$tpl->set('category', $category); 
        Core::$tpl->set('category_id', $category_id); 
    }
}

?>
