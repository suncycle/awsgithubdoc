<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Topic
 *
 * @author huangjp <huangjp@35zh.cn www.35zh.com>
 */
class TopicController extends AppController
{
  private $language_id;
  public function __construct()
  {
     parent::__construct();
     $this->language_id = $this->load('language')->language_id;
  }
  public function actionDetail()
  {
    $topic_id = Common::queryInt(_g('id'));

    $topic    = $this->load('topicLanguage')->getOne('status=1 and topic_id=' . $topic_id. ' and language_id=' . $this->language_id);
	
    if(!$topic)
    {
      return $this->exception();
    }
    $cond     = 't.topic_id='. $topic_id . ' and l.language_id=' . $this->language_id . ' and l.status = 1 order by t.listorder desc';
    $topicTag = $this->load('topicTagLanguageJoinTag')->findAll($cond);
    $cond2    = 'topic_id=' . $topic_id . ' order by listorder desc';
    $goods_ids = $this->load('topicTagGoodsRel')->findAll($cond2);
    $rel_goods_ids = array();
    $unique_goods_ids = array();
    foreach ($goods_ids as $value)
    {
      $rel_goods_ids[$value['topic_tag_id']][] = $value['goods_id'];
      $unique_goods_ids[$value['goods_id']]    = $value['goods_id'];
    }
    $goodsList = array();
    if(count($unique_goods_ids) > 0)
    {
      $cond3     = 'l.goods_id in (' . implode(',', $unique_goods_ids) . ') and l.status=1 limit 5000';
      $goodses   = $this->load('goodsJoinLanguage')->findAll($cond3);
      foreach ($goodses as $value)
      {
        $goodsList[$value['id']] = $value;
      }
    }
//    _debug($topicTag);
    Core::$tpl->set('big_title', $topic['base_name']);
    Core::$tpl->set('topic', $topic);
    Core::$tpl->set('topicTags', $topicTag);
    Core::$tpl->set('rel_goods_ids', $rel_goods_ids);
    Core::$tpl->set('goodsList', $goodsList);
    Core::$htmlFile  = 'product/topicdetail';
    Core::$isdisplay = 0;
    Core::$tpl->render(Core::$htmlFile . '.htm');
  }
}

?>
