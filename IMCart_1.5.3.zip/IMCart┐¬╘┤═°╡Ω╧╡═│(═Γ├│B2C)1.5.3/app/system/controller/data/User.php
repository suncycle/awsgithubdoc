<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class UserController extends AppController
{
  private $userReportLogic;
  private $languageLogic;
  private $countryLogic;
  private $userKeywordsLogic;
  public function __construct()
  {
    parent::__construct();
    $this->userReportLogic = $this->load('userReport');
    $this->languageLogic   = $this->load('language');
    $this->countryLogic    = $this->load('country');
    $this->userKeywordsLogic = $this->load('userKeywords');
  }
  public function actionDaily()
  {
      return true; //report 表不用了
     $cond = '1=1';
     if(_g('history_time'))
     {
       $cond .= ' and create_month=' . date('Ym', strtotime(_g('history_time')));
     }
     if(_g('language_id'))
     {
       $cond .= ' and language_id=' . _g('language_id');
     }
     if(_g('country_id'))
     {
       $cond .= ' and country_id='. _g('country_id');
     }
     $count = $this->userReportLogic->getCount($cond);
     $cond .= ' order by create_day desc';
     $current_page = Common::queryInt(_g('page'), 1);
     $pages = Common::getPages($count, $current_page, 20);
     $list  = $this->userReportLogic->getCurrentDatas($cond);
     $total = 0;
     foreach ($list as $value)
     {
       $total += $value['num'];
     }
     Core::$tpl->set('sites', $this->languageLogic->findAll('status=1', true));
     Core::$tpl->set('countrys', $this->countryLogic->findAll('', true));
     Core::$tpl->set('res', $list);
     Core::$tpl->set('total', $total);
     Core::$tpl->set('pages', $pages);
     Core::$tpl->set('selected_time', _g('history_time'));
     Core::$tpl->set('selected_site', _g('language_id'));
     Core::$tpl->set('selected_country', _g('country_id'));
  }
  public function  actionMonthly()
  {
      return true; //report 表不用了
    $cond = '1=1';
     if(_g('history_time'))
     {
       $cond .= ' and create_year=' . date('Y', strtotime(_g('history_time')));
     }
     if(_g('language_id'))
     {
       $cond .= ' and language_id=' . _g('language_id');
     }
     if(_g('country_id'))
     {
       $cond .= ' and country_id='. _g('country_id');
     }
     $cond .= ' group by create_month';
     $count = $this->userReportLogic->getCount($cond);    
     $current_page = Common::queryInt(_g('page'), 1);
     $pages = Common::getPages($count, $current_page, 20);
     $cols  = array(
         'create_month','sum(num) as num' , 'language_id', 'country_id', 'domain',
     );
     $list  = $this->userReportLogic->getCurrentDatas($cond, 20, $current_page, $cols);
     $total = 0;
     foreach ($list as $value)
     {
       $total += $value['num'];
     }
     Core::$tpl->set('sites', $this->languageLogic->findAll('status=1', true));
     Core::$tpl->set('countrys', $this->countryLogic->findAll('', true));
     Core::$tpl->set('res', $list);
     Core::$tpl->set('total', $total);
     Core::$tpl->set('pages', $pages);
     Core::$tpl->set('selected_time', _g('history_time'));
     Core::$tpl->set('selected_site', _g('language_id'));
     Core::$tpl->set('selected_country', _g('country_id'));
  }
  public function actionKeywordsRank()
  {
     $cond = '1=1';
     $current_page = Common::queryInt(_g('page'), 1);
     $limit = Common::queryInt(_g('limit'), 20);
     if(_g('start_time'))
     {
       $cond .= ' and create_day >' . date('Ymd', strtotime(_g('start_time')));
     }
     if(_g('end_time'))
     {
       $cond .= ' and create_day <' . date('Ymd', strtotime(_g('end_time')));
     }
     $cond .= ' group by keywords';
     $cols  = array(
        'keywords', 'count(keywords) as search_counts', 'avg(result_num) as average_goods_counts',
     );     
     $count = $this->userKeywordsLogic->getCount($cond);
     $pages = Common::getPages($count, $current_page, $limit);
     $list  = $this->userKeywordsLogic->getCurrentDatas($cond, $limit, $current_page, $cols);
     //排序
     for($i=0; $i< count($list); $i++)
     {
       for($j=count($list)-1; $j > 0; $j--)
      {           
           $temp  = $list[$i];
           $temp2 = $list[$j];
           if($temp['search_counts'] < $temp2['search_counts'])
           {
             $list[$i] = $temp2;
             $list[$j] = $temp;
           }
      }
     }
     Core::$tpl->set('res', $list);
     Core::$tpl->set('pages', $pages);
     Core::$tpl->set('selected_s_time', _g('start_time'));
     Core::$tpl->set('selected_e_time', _g('end_time'));
     Core::$tpl->set('limit', $limit);
  }
}

?>
