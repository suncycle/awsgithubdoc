<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Payment
 *
 * @author huangjp@35zh.cn
 */
class SettingController extends AppController
{
    private $setting_logic;
    private $langJoinCountryLogic;
    public function __construct()
    {
        parent::__construct();
        $this->setting_logic = $this->load("setting");
        $this->langJoinCountryLogic = $this->load('languageJoinCountry');
    }
    
    public function actionSetting()
    {      
        if(_p())
        {
            $language_id_arr=_p('language_id');
            foreach(_p()   as   $key   =>   $value)
            { 
                if( strpos($key , "setting_") !== false )
                {
                    if(strpos($key , "setting_")===0)
                    {       
                        $setting_map = Zhtx::createDataMap();
                        $keyname=substr($key,8);
                        $setting_map->addEntry('`key`', $keyname, DB::VARCHAR);
                        $setting_map->addEntry('value', $value, DB::VARCHAR);
                        $setting_map->addEntry('language_id', 0, DB::INT);
                        $cond = "language_id=0 and `key`='".$keyname."'";
                        $this->setting_logic->replaceByCond($setting_map,$cond);
                    }
                    else if(strpos($key , "setting_")!==0 && strpos($key , "setting_")!==false)
                    {
                        //取得语言id
                        $templangid=substr($key,0,-strlen(substr($key,stripos($key, "setting_"))));
                        if(count($language_id_arr)>0 && in_array($templangid, $language_id_arr))
                        {
                            $setting_lang_map = Zhtx::createDataMap();
                            $keyname=substr($key,stripos($key, "setting_")+8);
                            $setting_lang_map->addEntry('`key`', $keyname, DB::VARCHAR);
                            $setting_lang_map->addEntry('value', $value, DB::VARCHAR);
                            $setting_lang_map->addEntry('language_id', $templangid, DB::INT);
                            $cond = "language_id={$templangid} and `key`='".$keyname."'";
                            $this->setting_logic->replaceByCond($setting_lang_map,$cond); 
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
            } 
            return $this->showMessage('operation_success', Common::adminURL('admin', 'setting', 'setting'));
        }
        else
        {
            $setting = $this->setting_logic->getList();        
            $settingLang_arr = array();
            foreach($setting['list'] as $value)
            {
                $settingLang_arr[$value['language_id']][$value['key']] = $value;
            }
            Core::$tpl->set('setting', $settingLang_arr);
            $languages = $this->langJoinCountryLogic->getList();
            Core::$tpl->set('languages', $languages['list']);
        }
    }
}
?>
