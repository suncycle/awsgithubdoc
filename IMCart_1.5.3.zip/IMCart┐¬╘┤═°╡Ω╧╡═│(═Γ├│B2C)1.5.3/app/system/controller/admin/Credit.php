<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Credit
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class CreditController extends AppController {

    private $creditSettingLogic;
    private $creditCondLogic;

    public function __construct() {
        parent::__construct();
        $this->creditSettingLogic = $this->load('creditSetting');
        $this->creditCondLogic = $this->load('creditCond');
    }

    public function actionSetting() {
        if (_p()) {
            $data = array(
                'exchange_type' => Common::queryInt(_p('exchange_type')),
                'exchange_amount_scale' => Common::queryInt(_p('exchange_amount_scale')),
                'exchange_credit_scale' => Common::queryInt(_p('exchange_credit_scale')),
                'limit_date' => Common::queryInt(_p('limit_date')),
                'create_time' => SYS_TIME,
                'is_spec' => Common::queryInt(_p('is_spec')),
            );
            $res = $this->creditSettingLogic->save($data);
            if ($res) {
                if (_p('type1')) {
                    $cond_data1 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 1, //下单并成功支付
                        'status' => 1,
                        'formula_pre' => Common::queryInt(_p('formula_pre')),
                        'formula_operation' => Common::queryInt(_p('formula_operation')),
                        'formula_value' => Common::queryInt(_p('formula_value')),
                    );
                    $this->creditCondLogic->save($cond_data1);
                }else{
                    $cond_data1 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 1, //下单并成功支付
                        'status' => 0,
                        'formula_pre' => Common::queryInt(_p('formula_pre')),
                        'formula_operation' => Common::queryInt(_p('formula_operation')),
                        'formula_value' => Common::queryInt(_p('formula_value')),
                    );
                    $this->creditCondLogic->save($cond_data1);
                }
                if (_p('type2')) {
                    $cond_data2 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 2, //推荐会员赠送
                        'status' => 1,
                        'credit_value' => Common::queryInt(_p('credit_value2')),
                    );
                    $this->creditCondLogic->save($cond_data2);
                }else{
                    $cond_data2 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 2, //推荐会员赠送
                        'status' => 0,
                        'credit_value' => Common::queryInt(_p('credit_value2')),
                    );
                    $this->creditCondLogic->save($cond_data2);
                }
                if (_p('type3')) {
                    $cond_data3 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 3, //推荐会员首次下单并支付
                        'status' => 1,
                        'credit_value' => Common::queryInt(_p('credit_value3')),
                    );
                    $this->creditCondLogic->save($cond_data3);
                }else{
                    $cond_data3 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 3, //推荐会员首次下单并支付
                        'status' => 0,
                        'credit_value' => Common::queryInt(_p('credit_value3')),
                    );
                    $this->creditCondLogic->save($cond_data3);
                }
                if (_p('type4')) {
                    $cond_data4 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 4, //注册会员
                        'status' => 1,
                        'credit_value' => Common::queryInt(_p('credit_value4')),
                    );
                    $this->creditCondLogic->save($cond_data4);
                }else{
                    $cond_data4 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 4, //注册会员
                        'status' => 0,
                        'credit_value' => Common::queryInt(_p('credit_value4')),
                    );
                    $this->creditCondLogic->save($cond_data4);
                }
                if (_p('type5')) {
                    $cond_data5 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 5, //注册会员
                        'status' => 1,
                        'credit_value' => Common::queryInt(_p('credit_value5')),
                    );
                    $this->creditCondLogic->save($cond_data5);
                }else{
                    $cond_data5 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 5, //注册会员
                        'status' => 0,
                        'credit_value' => Common::queryInt(_p('credit_value5')),
                    );
                    $this->creditCondLogic->save($cond_data5);
                }
                if (_p('type6')) {
                    $cond_data6 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 6, //每日登陆
                        'status' => 1,
                        'credit_value' => Common::queryInt(_p('credit_value6')),
                    );
                    $this->creditCondLogic->save($cond_data6);
                }else{
                    $cond_data6 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 6, //每日登陆
                        'status' => 0,
                        'credit_value' => Common::queryInt(_p('credit_value6')),
                    );
                    $this->creditCondLogic->save($cond_data6);
                }
               if (_p('type7')) {
                    $cond_data7 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 7, //下单并成功支付
                        'status' => 1,
                        'formula_pre' => Common::queryInt(_p('formula_pre_7')),
                        'formula_operation' => Common::queryInt(_p('formula_operation_7')),
                        'formula_value' => Common::queryInt(_p('formula_value_7')),
                    );
                    $this->creditCondLogic->save($cond_data7);
                }else{
                    $cond_data7 = array(
                        'credit_setting_id' => $res,
                        'create_time' => SYS_TIME,
                        'type' => 7, //推荐会员下单并支付成功
                        'status' => 0,
                        'formula_pre' => Common::queryInt(_p('formula_pre_7')),
                        'formula_operation' => Common::queryInt(_p('formula_operation_7')),
                        'formula_value' => Common::queryInt(_p('formula_value_7')),
                    );
                    $this->creditCondLogic->save($cond_data7);
                }
                return $this->success('save_success');
            }
            return $this->showMessage('save_failure');
        } else {
            $setting = $this->creditSettingLogic->getOne();
            $cond_data = array();
            if ($setting) {
                $cond = $this->creditCondLogic->findAll('credit_setting_id=' . $setting['id']);
                foreach ($cond as $value) {
                    $cond_data[$value['type']] = $value;
                }
            }
//       _debug($cond_data);
            Core::$tpl->set('setting', $setting);
            Core::$tpl->set('cond', $cond_data);
            Core::$htmlFile = 'credit/form';
            Core::$isdisplay = 0;
            Core::$tpl->render(Core::$htmlFile . '.htm');
        }
    }

    /**
     * 删除积分
     * @return type
     */
    public function actionDel() {
        $credit_id = Common::queryInt(_g('id'));
        $creditDetailLogic = $this->load('creditDetail');
        $detail = $creditDetailLogic->getOneById($credit_id);
        if (!$detail) {
            return $this->showMessage('illegal_operation');
        }
        if ($creditDetailLogic->delete('id=' . $credit_id)) {
            if ($detail['useful_credit'] > 0) {
                $userLogic = $this->load('user');
                $user = $userLogic->getOneById($detail['user_id']);
                if ($user) {
                    $cur_credit = $user['credit'] - $detail['useful_credit'];
                    $user_data = array(
                        'credit' => $cur_credit > 0 ? $cur_credit : 0,
                        'update_time' => SYS_TIME,
                    );
                    $userLogic->save($user_data, $user['id']);
                }
            }
            return $this->success('delete_success', Common::adminURL('admin', 'user', 'detail', array('id' => $detail['user_id'])));
        }
        return $this->showMessage('delete_failure');
    }

    public function actionHowtoclean() {

    }

    public function actionCleanAll() {
        //清除积分
        $link = mysql_connect(DB_HOST, DB_USER, DB_PSW);
        mysql_select_db(DB_NAME);
        $sql = "update " . TABLE_PREFIX . "_credit_detail set useful_credit=0,used_credit=total_credit";
        if (mysql_query($sql)) {
            echo '清除积分-OK<br>';
        } else {
            echo mysql_error();
            return;
        }
        mysql_close();
    }

}

?>
