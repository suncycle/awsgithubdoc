<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class ScriptListController extends AppController
{

  

    public function __construct()
    {
        parent::__construct();
    }

    public function actionDefault()
    {
       
    }


}

?>
