<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BannerController
 *
 * @author cx
 */
class GetPageUrlController extends AppController {

    public function __construct() {
        parent::__construct();
    }

    public function actionDefault() {
        global $cfg;
        $type = _g("data_type");
        $id = _g("data_id");
        $languages = $this->load('languageJoinCountry')->getList('l.status=1');
        $urlMaker = $this->load('UrlMaker');
        $res = $languages['list'];

        switch ($type) {
            case "deals":
                foreach ($res as $key => $value) {
                    $res[$key]['href'] = '/Deals/c' . $id . '/list-r1.html';
                }
                break;
            case "topic":
                $element = $this->load('Topic')->getOne('id=' . $id);
                foreach ($res as $key => $value) {
                    if ($element['page_url'])
                        $res[$key]['href'] = '/' . $element['page_url'];
                    else
                        $res[$key]['href'] = '/topic-' . $id . '.html';
                }
                break;
            case "brand":
                foreach ($res as $key => $value) {
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getBrandUrl($id, $value['id'], $rewrite);
                }
                break;
            case "category":
                foreach ($res as $key => $value) {
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getCategoryUrl($id, $value['id'], $rewrite);
                }
                break;
            case "goods":
                foreach ($res as $key => $value) {
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getProductUrl($id, 0, $value['id'], $rewrite);
                }
                break;
            case "navpage":
                foreach ($res as $key => $value) {
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getNavPageUrl($id, $value['id'], $rewrite);
                }
                break;
            case "article":
                foreach ($res as $key => $value) {
                    $rewrite = array();
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getArticleUrl($id, $value['id'], $rewrite);
                }
                break;
            case "articlelist":
                foreach ($res as $key => $value) {
                    $rewrite = array();
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getArticleCategoryUrl($id, $value['id'], $rewrite);
                }
                break;
            case "tag":
                foreach ($res as $key => $value) {
                    $rewrite = array();
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getTagUrl($id, $value['id'], $rewrite);
                }
                break;
            case "nav":
                foreach ($res as $key => $value) {
                    $element = $this->load('navJoinLanguage')->getOne('nav_id=' . $id . ' and language_id=' . $value['id']);
                    $res[$key]['href'] = $element['url'];
                }
                break;
            case "picklist":
                foreach ($res as $key => $value) {
                    $res[$key]['href'] = "/picklist-{$id}.html";
                }
                break;
            case "comment":
                foreach ($res as $key => $value) {
                    $rewrite = array();
                    $rewrite["type"] = $cfg['sites'][$value['id']]['rewrite_type'];
                    $rewrite["name_type"] = $cfg['sites'][$value['id']]['rewrite_prename'];
                    $res[$key]['href'] = $urlMaker->getCommentUrl($id, $value['id'], $rewrite);
                }
                break;
            case "channel":
                $element = $this->load('ChannelTag')->getOne('id=' . $id);
                foreach ($res as $key => $value) {
                    if ($element['page_url'])
                        $res[$key]['href'] = '/' . $element['page_url'];
                    else
                        $res[$key]['href'] = '/channel-' . $id . '.html';
                }
                break;
        }
        Core::$tpl->set('res', $res);
    }

    public function actionQRCode() {
        require_once(APP_ROOT . "libary/phpqrcode.php");
        $url = _g('url');
//		$url = 'http://wap.fastrend.com/';
        ob_clean();
        QRcode::png($url, false, 'L', 8);
        exit;
    }

}

?>
