<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TrackController
 *
 * @author cx
 */
class TrackController extends AppController
{
    private $trackLogic;
    public function __construct()
    {
        parent::__construct();
        $this->trackLogic = $this->load('OrderTrackingno');
    }
    public function actionList()
    {
        $page_size = 20;
        $curr_page = isset($_GET['page'])? intval($_GET['page']) : 1 ;
        $cond = "ORDER BY update_time DESC";
        $cols = array('id', 'orderid', 'tracking_no', 'status', 'shipping_company', 'update_time');
        //获取数据
        $res = $this->trackLogic->getCurrentDatas($cond, $page_size, $curr_page);
        //分页
        $count = $this->trackLogic->getCount();
        $page_list = Common::pages($count, $curr_page, $page_size);
        Core::$tpl->set('res', $res);
        Core::$tpl->set('pages', $page_list);
    }
    public function actionAdd()
    {
        
    }
    public function actionEdit()
    {
        
    }
    public function actionDel()
    {
        
    }
    public function actionDetail()
    {
        $id = _g('id');
        $cond = 'id='.$id;
        $track = $this->trackLogic->getOne($cond);
        $obj = json_decode($track["tracking_detail"]);
       //print_r($obj->lastResult->data->$index->time);
        for($index=0;$index<count($obj->lastResult->data);$index++)
        {
            $track["track_detail"][] = array("time"=>$obj->lastResult->data[$index]->time,"content"=>$obj->lastResult->data[$index]->context);
        }
        //print_r($track["track_detail"]);
        Core::$tpl->set('track', $track);
    }
}
?>
