<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Auth
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class AuthController extends AppController
{
  public function __construct()
  	{
    	parent::__construct();
  	}  
  	public function actionDefault()
  	{
    	if(_p())
        {
          $auth_id   = _p('auth_id');
          $auth_code = _p('auth_code');
          if(!$auth_id || !$auth_code)
          {
            return $this->showMessage('illegal_operation');
          }
         
            $auth_file = APP_ROOT . 'conf/auth.conf.php';           
            $version   = array(
                  'auth_id'   => $auth_id,   
                  'auth_code' => $auth_code   
            );
             $auth_conf = "<?php".PHP_EOL ."/**".PHP_EOL ."* auth_id 授权ID，不能为空".PHP_EOL ."* auth_code 授权编号，不能随意修改 否则可能不能访问".PHP_EOL ."* auth_verfiy  随机验证码，只能系统自动生成不可修改，否则会导致验证失败，网站无法访问。如不慎修改则清空后让系统重新验证".PHP_EOL ."*/".PHP_EOL ."\$sys_auth = array(".PHP_EOL ."  'auth_id' => '".$version['auth_id']."',".PHP_EOL . "  'auth_code' => '".$version['auth_code']."',".PHP_EOL."  'auth_verfiy' => ''".PHP_EOL .");".PHP_EOL."?>";
             $auth_conf = @file_put_contents($auth_file, $auth_conf);
             @chmod($auth_file, 0755);
            _crearCahce('goods_list');
            _crearCahce('goods_info');
            _crearCahce('category');
            _crearCahce('brand');
            _crearCahce('promotions');
            _crearCahce('navpage');
            Zhtx::unSetSession();
            Zhtx::unSetCookie();
            return $auth_conf ? $this->success('edit_success') : $this->showMessage('edit_failure');
         
        }
        else
        {
          global $sys_auth, $version;
          if($sys_auth && !empty($sys_auth))
          {
              $result      = json_decode(ZhCurl::checkAuth($sys_auth['auth_id'], $sys_auth['auth_code']), TRUE);
              $auth_domain = array();
              foreach ($result as $item)
              {
                $auth_domain[$item['domain']] = $item;
              } 
              Core::$tpl->set('auth_domain', $auth_domain);          
          }
          $languages = $this->load('language')->findAll();
          Core::$tpl->set('languages', $languages);
          Core::$tpl->set('version', $version);
          Core::$tpl->set('system_auth', $sys_auth);
        }
  	}
    public function actionSystemVersions()
    {
       global $version;
       $page   = Common::queryInt(_g('page'), 1);
       $psize  = Common::queryInt(_g('psize'), 20);
       $params = array('page' => $page, 'psize' => $psize);
	   
	   $data = ZhCurl::getAllVersion($params) ;
		if(!$data)
		{
			 return $this->error('api_network_error', Common::adminURL('admin', 'Auth', 'SystemVersions'));
		}
	   
       $result = json_decode($data, TRUE);
	   if($result["auth"]=="no")
		{
			return $this->error('api_auth_error', Common::adminURL('admin', 'auth', 'default'));	
		}
		
		$data = ZhCurl::getNextVersion($version['sys_version']) ;
		if(!$data)
		{
			 return $this->error('api_network_error', Common::adminURL('admin', 'Auth', 'SystemVersions'));
		}
       $next_version = json_decode($data, TRUE);
       $next_version_id = isset($next_version['id']) ? $next_version['id'] : 0;       
       $pages  = Common::getPages($result['count'], $page, $psize);
       Core::$tpl->set('res', $result['versions']);
       Core::$tpl->set('next_version_id', $next_version_id);
       Core::$tpl->set('cur_version', $version['sys_version']);
       Core::$tpl->set('is_diy_system', IS_DIY_SYS);
       Core::$tpl->set('pages', $pages);
    }
    public function actionTools()
    {
      $result = json_decode(ZhCurl::getAllVersion(2), TRUE);
      Core::$tpl->set('res', $result);
    }
    public function actionVersionDetail()
    {
      $version_id = Common::queryInt(_g('id'));
      $result = json_decode(ZhCurl::getVersion($version_id), TRUE);
      Core::$tpl->set('version', $result);
    }
    public function actionToolsDetail()
    {
       $version_id = Common::queryInt(_g('id'));
       $result = json_decode(ZhCurl::getVersion($version_id), TRUE);
       Core::$tpl->set('version', $result);
    }
    public function actionPublicAd()
    {
      $place = Common::queryInt(_g('place'), 1001);
      $result = json_decode(ZhCurl::getAd($place), true);
      echo json_encode(array('url' => $result[0]['url'], 'image' => $result[0]['adimg']));
    }
    /**
     * 在线升级 
     */
   public function actionOnlineUpgrade()
   {
     if(_p())
     {
       if(IS_DIY_SYS)
       {
         return $this->showMessage('is_diy_system_tip', Common::adminURL('admin', 'admin', 'default'));
       }
       $target_dir  = APP_ROOT . 'upgrade/';
       @mkdir($target_dir);
       $upgrade_url     = _p('upgrade_url');
       $publish_version = _p('publish_version');
       $is_backup       = Common::queryInt(_p('backup'));
       $is_delete       = Common::queryInt(_p('delete_upgrade'));
       $content = Common::getRemoteData($upgrade_url);
       $upgrade_zip = $target_dir . $publish_version .'.zip';
       $upgrade_dir = $target_dir . $publish_version . '/';
       @file_put_contents($upgrade_zip, $content);
       Common::unzip_file($upgrade_zip, $upgrade_dir);
       $cover_file_list = Dir::getAllFiles($upgrade_dir);
       //如果备份文件
       if($is_backup == 1)
       {         
         $backup_files    = array();
         foreach($cover_file_list as $key => $val)
         {
           $backup_files[$key] = str_replace($upgrade_dir, APP_ROOT, $val);
         }
         $destination = $target_dir . $publish_version . '_pre_backup.zip';
         Common::create_zip($backup_files, $destination);
       }
       //开始覆盖文件
       $success = array();
       $failure = array();
       foreach($cover_file_list as $key => $value)
       {
           $target_file = str_replace($upgrade_dir, APP_ROOT, $value);
           Common::rmkdir(dirname($target_file));
           if(copy($value, $target_file))
           {
             $success[] = $target_file;
             echo $target_file . ' ......upgrade Successful!';
             echo '<br />';
           }
           else
           {
             $failure[] = $target_file;
             echo $target_file . ' ......<font color=red>upgrade Failure!</font>';
             echo '<br />';
           }
       }
       $del_sql_res = 1;
       if(_p('deal_sql'))
       {
        //执行升级的sql
        $sql_file = $upgrade_dir . $publish_version.'_upgrade.sql';
        if(file_exists($sql_file))
        {
            echo '<br />';
            echo '<font color=green>==========开始执行升级sql文件==========</font><br />';
            echo '<br />';
            $del_sql_res = $this->dealSql($sql_file);
        }
       }
       $upgrade_fail_count = count($failure);
       if($upgrade_fail_count)
       {
         $tip = '有' . $upgrade_fail_count . '个文件更新失败，请检查所在目录是否有读写的权限！ 如更新sql有冲突或者错误，请手动操作执行';
         echo '<script type="text/javascript">alert("' . $tip . '")</script>';         
       }
       else if($del_sql_res != 1)
       {
         $del_sql_res .= ' 请根据所提示的错误手工执行网站根目录下相应的sql文件';
         echo '<script type="text/javascript">alert("' . $del_sql_res . '")</script>';
       }
       else
       {
          $tip =  '恭喜，升级完成！ 如更新sql有冲突或者错误，请手动操作执行';
          echo '<script type="text/javascript">alert("' . $tip . '")</script>';          
       }
       if(!$upgrade_fail_count)
       {
          $auth_conf = "<?php".PHP_EOL ."/**".PHP_EOL ."* sys_version 版本号".PHP_EOL ."* sys_release 更新时间".PHP_EOL ."* sys_codeno  紧急补丁包key".PHP_EOL ."*/".PHP_EOL ."\$version = array(".PHP_EOL ."  'sys_version' => '". strtoupper($publish_version)."',".PHP_EOL . "  'sys_release' => '".  date('Ymd', SYS_TIME)."',".PHP_EOL."  'sys_codeno' => '"._p('system_codeno')."'".PHP_EOL .");".PHP_EOL."?>";
          $auth_conf = @file_put_contents(APP_ROOT ."conf/version.conf.php", $auth_conf);
          @chmod(APP_ROOT ."conf/version.conf.php", 0755);
       }      
       //删除升级包的残留文件
       if($is_delete && !count($failure))
       {
         Dir::delDirAndFile($upgrade_dir);
         unlink($upgrade_zip);
       }      
       exit;
     }
     else
     {
        global $version;
        $target_version   = strtolower(_g('publish_version'));
        $pre_version      = strtolower(_g('pre_version'));       
        $upgrade_file_url = _g('upgrade_url');
        $cur_version      = strtolower($version['sys_version']);
        $type             = _g('type');
        $key              = _g('key');
        $ps = '';
        if($type != 'urgent')
        {          
          if($cur_version < 'v1.0.5')
          {
            $ps = 'online_upgrade_require';
          }
          else if($cur_version == $target_version)
          {
            $ps = 'system_is_already_the_newest_version';
          }
          else if($cur_version > $target_version)
          {
            $ps = 'system_version_higher_not_grade';
          }
          else if($cur_version != $pre_version)
          {
            $ps = 'system_version_upgrade_not_cross-grade';
          }
        }
        else if($key && $key == $version['sys_codeno'])
        {
          $ps = 'system_is_already_the_newest_version';
        }
        Core::$tpl->set('ps', $ps);
        Core::$tpl->set('type', $type);
        Core::$tpl->set('upgrade_url', $upgrade_file_url);
        Core::$tpl->set('publish_version', $target_version);
        Core::$tpl->set('system_codeno', $key);
        Core::$htmlFile  = 'auth/upgrade';
        Core::$isdisplay = 0;
        Core::$tpl->render(Core::$htmlFile . '.htm');
     }
   }
   public function actionRestoration()
   {
     global $version;
     $true_ver    = strtolower($version['sys_version']);
     $target_dir  = APP_ROOT . 'upgrade/';
     $cur_version = strtolower(_g('cv'));
     $restoration = $target_dir . $cur_version . '_pre_backup.zip';
     if($true_ver != $cur_version)
     {
       return $this->showMessage('version_mismatch');
     }
     if(!file_exists($restoration))
     {
       return $this->showMessage('not_restoration');
     }
     if (Common::unzip_file($restoration, APP_ROOT))
     {
       $auth_conf = "<?php".PHP_EOL ."/**".PHP_EOL ."* sys_version 版本号".PHP_EOL ."* sys_release 更新时间".PHP_EOL ."* sys_codeno  紧急补丁包key".PHP_EOL ."*/".PHP_EOL ."\$version = array(".PHP_EOL ."  'sys_version' => '". strtoupper($version['sys_version'])."',".PHP_EOL . "  'sys_release' => '".  date('Ymd', SYS_TIME)."',".PHP_EOL."  'sys_codeno' => ' '".PHP_EOL .");".PHP_EOL."?>";
	   $auth_conf = @file_put_contents(APP_ROOT ."conf/version.conf.php", $auth_conf);
	   @chmod(APP_ROOT ."conf/version.conf.php", 0755);
       return $this->success('restoration_to_pre_version_success');
     }
   }
   public function actionTest()
   {
      $sql_file = APP_ROOT . 'upgrade/test.sql';
      echo $this->dealSql($sql_file);
   }
   public function actionGetUrgentBag()
    {
       global $version;
       $page   = Common::queryInt(_g('page'), 1);
       $psize  = Common::queryInt(_g('psize'), 20);
       $params = array('page' => $page, 'psize' => $psize);
	   $data = ZhCurl::getAllUrgent($params) ;
	   if(!$data)
		{
			 return $this->error('api_network_error', Common::adminURL('admin', 'Auth', 'GetUrgentBag'));
		}
       $result       = json_decode($data, TRUE);
	   if($result["auth"]=="no")
		{
			return $this->error('api_auth_error', Common::adminURL('admin', 'auth', 'default'));	
		}
	   
	   $data = ZhCurl::getNextVersion(strtoupper($version['sys_version']));
	    if(!$data)
		{
			 return $this->error('api_network_error', Common::adminURL('admin', 'Auth', 'GetUrgentBag'));
		}
       $next_version = json_decode($data, TRUE);
	   
       $next_version_id = isset($next_version['id']) ? $next_version['id'] : 0;
       $pages  = Common::getPages($result['count'], $page, $psize);
       Core::$tpl->set('res', $result['versions']);
       Core::$tpl->set('next_version_id', $next_version_id);
       Core::$tpl->set('cur_version', $version);
       Core::$tpl->set('is_diy_system', IS_DIY_SYS);
       Core::$tpl->set('pages', $pages);
       Core::$htmlFile  = 'auth/urgentbags';
       Core::$isdisplay = 0;
       Core::$tpl->render(Core::$htmlFile . '.htm');
    }
   /**
    * 执行sql
    * @param type $sql_file
    * @return type 
    */
    function dealSql( $sql_file )
    {
        $mysql = mysql_connect(DB_HOST,DB_USER,DB_PSW);
        if($mysql === FALSE)
        {
          return "mysql connect fail, wrong password. Please Manual processing this upgrade\'s sql";
        }
        if(mysql_select_db(DB_NAME) === FALSE){
           return "select DB fail. Please Manual processing this upgrade\'s sql";
        }               
        mysql_query("set names utf8");
        $n    = 0;
		$sql  = file_get_contents($sql_file);  
		$sqls = $this->fnParseSql($sql); 
		unset($sql);  
		foreach($sqls as $sql){  
		    mysql_query($sql); // 执行sql语句 
           if( mysql_error())
            {
			  //echo '<font color=red>' .mysql_error() . '</font>';
              //$del_msg .= mysql_error()." Please Manual processing this upgrade's sql .";   
            }
			else
			{
                $n ++;
            }			
		}        
        //echo "<br />mysql queries:" . $n;
        return $del_msg ? $del_msg : 1;
    }    
    /**
     * 格式化sql文件
     * @param type $sql
     * @return type
     */
    function fnParseSql($sql=''){  
        $sql = str_replace("\r","\n",$sql);  
        $ret = array();  
        $aSql = explode(";\n",trim($sql));  
        unset($sql);  
        $num = 0;
        $queries = array();
        foreach($aSql as $sql){  
            $ret[$num]='';  
            $queries = explode("\n",$sql);  
            $queries = array_filter($queries);  
            foreach($queries as $query){  
                $str1 = substr($query,0,1);  
                if($str1!=='#' && $str1!=='-') $ret[$num].=$query;  
            }  
            $num++;  
        }  
        return $ret;  
    }
    
    public function actionDownloadUpgradeZip()
    {
        $this->lang=Common::lang(Core::$controller, Core::$module, Core::$language);
        if(IS_DIY_SYS)
        {
            $return=array('status'=>0,'msg'=>$this->lang['is_diy_system_tip']);
            echo json_encode($return);
            return;
        }
        $target_dir  = APP_ROOT . 'upgrade/';
        @mkdir($target_dir);
        $upgrade_url     = _p('upgrade_url');
        $publish_version = _p('publish_version');
        $upgrade_url = urldecode($upgrade_url);
        $content = Common::getRemoteData($upgrade_url);
        $upgrade_zip = $target_dir . $publish_version .'.zip';
        $upgrade_dir = $target_dir . $publish_version . '/';
        @file_put_contents($upgrade_zip, $content);
        if(Common::unzip_file($upgrade_zip, $upgrade_dir, TRUE))
        {
            $sql_file = $upgrade_dir . $publish_version.'_upgrade.sql';
            $sql_url = '';
            if(file_exists($sql_file))
            {
                $sql_url = FOLDER_ROOT.'upgrade/'.$publish_version.'/'.$publish_version.'_upgrade.sql';
            }
            else
            {
                $sql_url = '';
            }
            $return=array('status'=>1,'sql_url'=>$sql_url);
            echo json_encode($return);
        }
        else
        {
            $return=array('status'=>0,'msg'=>'下载失败');
            echo json_encode($return);
            return;
        }
    }
    
    public function actionUpgradeSystemFile()
    {
        $this->lang=Common::lang(Core::$controller, Core::$module, Core::$language);
        if(IS_DIY_SYS)
        {
            $return=array('status'=>0,'msg'=>$this->lang['is_diy_system_tip']);
            echo json_encode($return);
            return;
        }
        $publish_version = _p('publish_version');
        $target_dir  = APP_ROOT . 'upgrade/';
        $upgrade_dir = $target_dir . $publish_version . '/';
        $is_backup = 1;
        $is_delete = 1;
        if(file_exists($upgrade_dir))
        {
            $cover_file_list = Dir::getAllFiles($upgrade_dir);
            //如果备份文件
            if($is_backup == 1)
            {         
              $backup_files    = array();
              foreach($cover_file_list as $key => $val)
              {
                $backup_files[$key] = str_replace($upgrade_dir, APP_ROOT, $val);
              }
              $destination = $target_dir . $publish_version . '_pre_backup.zip';
              Common::create_zip($backup_files, $destination);
            }
            //开始覆盖文件
            $success = array();
            $failure = array();
            foreach($cover_file_list as $key => $value)
            {
                $target_file = str_replace($upgrade_dir, APP_ROOT, $value);
                Common::rmkdir(dirname($target_file));
                if(copy($value, $target_file))
                {
                  $success[] = $target_file;
                }
                else
                {
                  $failure[] = $target_file;
                }
            }
            $upgrade_fail_count = count($failure);
            if(!$upgrade_fail_count)
            {
               $auth_conf = "<?php".PHP_EOL ."/**".PHP_EOL ."* sys_version 版本号".PHP_EOL ."* sys_release 更新时间".PHP_EOL ."* sys_codeno  紧急补丁包key".PHP_EOL ."*/".PHP_EOL ."\$version = array(".PHP_EOL ."  'sys_version' => '". strtoupper($publish_version)."',".PHP_EOL . "  'sys_release' => '".  date('Ymd', SYS_TIME)."',".PHP_EOL."  'sys_codeno' => '"._p('system_codeno')."'".PHP_EOL .");".PHP_EOL."?>";
               $auth_conf = @file_put_contents(APP_ROOT ."conf/version.conf.php", $auth_conf);
               @chmod(APP_ROOT ."conf/version.conf.php", 0755);
            } 
            //删除升级包的残留文件
            if($is_delete && !count($failure))
            {
              Dir::delDirAndFile($upgrade_dir);
            }
            $return=array('status'=>1,'msg'=>$this->lang['success'],'success_file'=>$success,'failure_file'=>$failure);
            echo json_encode($return);
            return;
        }
        else
        {
            $return=array('status'=>0,'msg'=>$this->lang['failure']);
            echo json_encode($return);
            return;
        }
    }
    /**
     * 在线升级 
     */
   public function actionUpgradeSqlFile()
   {
     if(_p())
     {
       if(IS_DIY_SYS)
       {
         return $this->showMessage('is_diy_system_tip', Common::adminURL('admin', 'admin', 'default'));
       }
       $target_dir  = APP_ROOT . 'upgrade/';
       @mkdir($target_dir);
       $publish_version = _p('publish_version');
       $upgrade_dir = $target_dir . $publish_version . '/';
       $del_sql_res = 1;
        //执行升级的sql
        $sql_file = $upgrade_dir . $publish_version.'_upgrade.sql';
        if(file_exists($sql_file))
        {
//            echo '<br />';
//            echo '<font color=green>==========开始执行升级sql文件==========</font><br />';
//            echo '<br />';
            $del_sql_res = $this->dealSql($sql_file);
        }
       if($del_sql_res != 1)
       {
         $del_sql_res .= ' 请根据所提示的错误手工执行网站根目录下相应的sql文件';
//         echo '<script type="text/javascript">alert("' . $del_sql_res . '")</script>';
         $return=array('status'=>0,'msg'=>$del_sql_res);
            echo json_encode($return);
       }
       else
       {
          $tip =  '恭喜，升级完成！ 如更新sql有冲突或者错误，请手动操作执行';
//          echo '<script type="text/javascript">alert("' . $tip . '")</script>';   
          $return=array('status'=>1,'msg'=>$tip);
            echo json_encode($return);
       }
       exit;
     }
   }
}

?>