<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Payment
 *
 * @author hjp
 */
class TwitterController extends baseApiSns
{
    private $languageLogic;
    public function __construct()
    {
        $this->languageLogic = $this->load('language');
        $this->apisnslogic = $this->load("apisns");
        $this->loadConfig();
    }
    /**
     * 加载配置
     */
    public function loadConfig()
    {
        $language_id = $this->languageLogic->language_id;
        $apisns = $this->apisnslogic->getOne("api_type='twitter' and status=1 and language_id=".$language_id);
        if(!$apisns)
        {
            return $this->showMessage('illegal_parameters');
        }
        $this->param=json_decode($apisns['api_param'],TRUE);
        require_once(APP_ROOT . 'api/login/twitter/package/twitteroauth/twitteroauth.php');
    }
  
    /**
     * 接口跳转
     */
    public function actionRedirect()
    {
        //测试直接跳到登录页
/*        $data=array();
        $data['api_id'] = '7';
        $data['api_key'] = 'zLL212121';
        $data['type'] = 'twitter';
        $data['api_email'] = '';
        $ref = Common::frontURL('home', 'apilogin', 'login',$data);
        return $this->_redirect($ref,TRUE);*/
        
        /* Start session and load library. */
        @session_start();
        
        /* Build TwitterOAuth object with client credentials. */
        $connection = new TwitterOAuth($this->param['exp_twitter_key'], $this->param['exp_twitter_secret']);

        /* Get temporary credentials. */
        $request_token = $connection->getRequestToken($this->param['exp_twitter_callback']);
        //var_dump($request_token);
        //var_dump($connection->http_info);
        /* Save temporary credentials to session. */
        $_SESSION['oauth_token'] = $token = $request_token['oauth_token'];
        $_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret'];

        /* If last connection failed don't display authorization link. */
        switch ($connection->http_code) {
          case 200:
            /* Build authorize URL and redirect user to Twitter. */
            $url = $connection->getAuthorizeURL($token);
            @header('Location: ' . $url); 
            break;
          default:
            /* Show notification if something went wrong. */
            echo 'Could not connect to Twitter. Refresh the page or try again later.';
        }
    }
    
    /**
     * 回调
     */
    public function actionCallback()
    {
        $apisns = $this->apisnslogic->getOne("api_type='twitter' and status=1");
        /* Start session and load lib */
        @session_start();


        /* If the oauth_token is old redirect to the connect page. */
        if (isset($_REQUEST['oauth_token']) && $_SESSION['oauth_token'] !== $_REQUEST['oauth_token']) {
          $_SESSION['oauth_status'] = 'oldtoken';
          //header('Location: ./clearsessions.php');
        }

        /* Create TwitteroAuth object with app key/secret and token key/secret from default phase */
        $connection = new TwitterOAuth($this->param['exp_twitter_key'], $this->param['exp_twitter_secret'], $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);

        /* Request access tokens from twitter */
        $access_token = $connection->getAccessToken($_REQUEST['oauth_verifier']);

        /* Save the access tokens. Normally these would be saved in a database for future use. */

        /* Remove no longer needed request tokens */
        unset($_SESSION['oauth_token']);
        unset($_SESSION['oauth_token_secret']);

        /* If HTTP response is 200 continue otherwise send to connect page to retry */
        if (200 == $connection->http_code) {
          /* The user has been verified and the access tokens can be saved for future use */
          $_SESSION['status'] = 'verified';
          $connection = new TwitterOAuth($this->param['exp_twitter_key'], $this->param['exp_twitter_secret'], $access_token['oauth_token'], $access_token['oauth_token_secret']);

        /* If method is set change API call made. Test is called by default. */
                $content = $connection->get('account/verify_credentials');
                $data=array();
                if($content->id)
                {
/*			$data['api_id'] = $apisns['id'];			
                        $data['api_key'] = $content->id;			
                        $data['type'] = 'twitter';			
                        $data['api_email'] = '';*/

                        $_SESSION['api_login_apiID']=$apisns['id'];
                        $_SESSION['api_login_apikey']=$content->id;
                        if($content->email)
                        $_SESSION['api_login_apiemail']=$content->email;
                }
                
                $ref = Common::frontURL('home', 'apilogin', 'login');
		return $this->_redirect($ref,TRUE);
                //var_dump($content);
                //header("Location: ../../register.php?sns=twitter&id=".$content->id);
                //var_dump($content);

          //header('Location: ./callbackforredirect.php?twitter='.$content->name);
        } else {
          /* Save HTTP status for error dialog on connnect page.*/
          //header('Location: ./clearsessions.php');
		$data=array();
                $ref = Common::frontURL('home', 'user', 'login',$data);
		return $this->_redirect($ref,TRUE);
        }
    }
}
?>

