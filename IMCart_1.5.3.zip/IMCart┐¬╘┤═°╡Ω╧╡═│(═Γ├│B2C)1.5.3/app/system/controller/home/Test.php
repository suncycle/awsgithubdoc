<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Test
 * @author NT <www.35zh.com>
 */

class TestController extends AppController
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function actionTest()
    {
        //phpinfo();
        echo 'magic_quotes_gpc:'.get_magic_quotes_gpc().'<br><br>';
        $test1 = _p("test1");
        $test1 = $_POST["test1"];
        $data1 = $test1;
        $test2 = _p("test2");
	$data2 = json_decode($test2,true);
        echo $data1.'<br><br>';
        echo $test2;
        _debug($data2);
    }

}

?>
