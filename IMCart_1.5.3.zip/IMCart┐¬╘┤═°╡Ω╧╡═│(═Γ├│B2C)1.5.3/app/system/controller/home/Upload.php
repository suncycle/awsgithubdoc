<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Upload
 *
 * @author xrx <QQ:1251679791 www.35zh.com>
 */
class UploadController extends AppController
{
    /**
     * 上传 
     */
    public function actionUpload()
    {   
        global $ip_limit;
        if(count($ip_limit) > 0 && !in_array(Common::ip(), $ip_limit))
        {
          echo 'CGI ERROR', die();
        }
		if(_p())
        {               
//             Common::log($debug);
			if (is_array($_FILES)) 
			{
				foreach($_FILES AS $name => $value)
				{
					${$name} = $value['tmp_name'];
					$fp = @fopen(${$name},'r');
					$fstr = @fread($fp,filesize(${$name}));
					@fclose($fp);
					if($fstr!='' && (ereg("<\?",$fstr) || ereg("<\%",$fstr) ) )
					{
						 echo 0;
						 die();
					}
				}
			}
            $keep_name   = Common::queryInt(_p('keep_name'));
            $force_cover = Common::queryInt(_p('force_cover')) ;  
            $file        =   $_FILES['file1'];
            $folder      = _g('folder');//explode('./', _g('folder'));    
            if(substr($folder, 0, strlen(UPLOAD_DIR))!=UPLOAD_DIR)
            {
                $folder = UPLOAD_DIR.$folder;
            }
            if(substr($folder,strlen($folder)-1,1)!='/')
            {
                $folder = $folder . '/';
            }
            $path_parts      = pathinfo($file['name']);
            //$path_name_array = preg_split("/\./" , $path_parts["basename"] ) ;                
            //$filename        = $path_name_array[0];
            $filename = basename($file['name'],'.' . $path_parts["extension"]);
            $file_src_name   = $folder . $filename . '.' . $path_parts["extension"];//$folder[1] . $filename . '.' . $path_parts["extension"];
            if(!$keep_name)
            {
                $filename = date('Ymdhs', SYS_TIME).Common::random(6);
            }
            if($force_cover && file_exists($file_src_name))
            {
                unlink($file_src_name);
                $image_base_path = APP_ROOT . UPLOAD_DIR;
                $file_name = str_replace($image_base_path, '', $file_src_name);
                $file_name = str_replace('upload/', '', $file_name);
                $thumb_dir = $image_base_path . 'thumb/';
                if ($fp = @opendir($thumb_dir))
                {
                    while ($hander = readdir($fp))
                    {
                        if ($hander != '.' && $hander != '..' && substr($hander, 0, 1) != '.')
                        {
                            $thubm_file = $thumb_dir . $hander . '/' . $file_name;
                            if (is_file($thubm_file))
                            {
                                @unlink($thubm_file);
                            }
                        }
                    }
                    closedir($fp);
                }
            }
            
            $handle = new Upload($folder, $filename);//$folder[1]
            $result = $handle->processed($file);  
//          Common::log($result);
            echo $result ? 1 . '|' . $result : 0;
        }
        else
        {
            echo 1;
        }
        
    } 
}

?>
