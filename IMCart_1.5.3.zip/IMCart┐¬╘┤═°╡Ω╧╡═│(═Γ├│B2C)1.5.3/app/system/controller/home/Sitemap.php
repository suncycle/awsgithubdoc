<?php



/**

 * Description of Sitemap

 *

 * @author hjp <huangjp@35zh.com>

 */

class SitemapController extends AppController

{

    public function __construct()

    {

        parent::__construct();

    }

    public function actionDefault()

    { 
		ob_clean();
        @header('Content-Type: text/xml; charset=utf-8');

        Core::$htmlFile = 'common/sitemap';

        Core::$isdisplay = 0;

        Core::$tpl->render(Core::$htmlFile . ".xml");

    }

    public function actionCategorys()

    { 
		ob_clean();
        @header('Content-Type: text/xml; charset=utf-8');

        Core::$htmlFile = 'common/categoryssitemap';

        Core::$isdisplay = 0;

        Core::$tpl->render(Core::$htmlFile . ".xml");

    }

    public function actionProducts()

    { 
		ob_clean();
        @header('Content-Type: text/xml; charset=utf-8');

        Core::$htmlFile = 'common/productssitemap';

        Core::$isdisplay = 0;

        Core::$tpl->render(Core::$htmlFile . ".xml");

    }

    public function actionNewProducts()

    { 
		ob_clean();
        @header('Content-Type: text/xml; charset=utf-8');

        Core::$htmlFile = 'common/newProductssitemap';

        Core::$isdisplay = 0;

        Core::$tpl->render(Core::$htmlFile . ".xml");

    }

    public function actionPc()

    { 

        Core::$htmlFile = 'common/pc';

        Core::$isdisplay = 0;

        Core::$tpl->render(Core::$htmlFile . ".htm");

    }

}

?>