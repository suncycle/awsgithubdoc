<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Apilogin
 *
 * @author hjp
 */
class ApiloginController extends AppController {

    private $userLogic;
    private $userapiLogic;
    private $apisnslogic;

    public function __construct() {
        parent::__construct();
        $this->userLogic = $this->load('user');
        $this->userapiLogic = $this->load('userapi');
        $this->apisnslogic = $this->load("apisns");
    }

    public function actionRegister() {
        if (_p()) {
            $this->register();
        }
        else 
        {

            //$api_id = $_SESSION['api_login_apiID'];
          //  $api_key = $_SESSION['api_login_apikey'];
          //  $user_email = $_SESSION['api_login_apiemail'];
			if($this->checkLogin())
				{
					 return $this->_redirect(Common::frontURL('home', 'account', 'index'));	
				}
              $api_id=Common::queryInt(_g("api_id"));//接口ID
              $api_key=_g("api_key");//第三方key ID
              $api_type=_g("type");//第三方类型
              $user_email=_g("api_email");
           if (strtolower($api_id) == "undefined") {
                $api_id = "";
            }
            if (strtolower($api_key) == "undefined") {
                $api_key = "";
            }
            if (strtolower($api_type) == "undefined") {
                $api_type = "";
            }
            if (strtolower($user_email) == "undefined") {
                $user_email = "";
            }
			
            $sns = $this->apisnslogic->getOne("id=" . $api_id . " and status=1");
            if(!$sns)
            {
                return $this->showMessage('illegal_parameters', Common::frontURL('home', 'account', 'index'));
            }
            $cond = "api_id =" . $api_id . " and api_key='" . $api_key . "'";
            $userapi = $this->userapiLogic->getOne($cond);

            if ($userapi['user_id']) {
                $this->login($userapi['user_id']);
                exit();
            }
            $api_type = $sns['api_type'] ;
            Core::$tpl->set('sns', $sns);
            Core::$tpl->set('api_id', $api_id);
            Core::$tpl->set('api_key', $api_key);
            Core::$tpl->set('type', $api_type);
            Core::$tpl->set('api_email', $user_email);
            Core::$htmlFile = 'user/register_api';
            Core::$isdisplay = 0;
            Core::$tpl->render(Core::$htmlFile . '.htm');
        }
    }

    public function actionLogin() {
        if (_g("type") == 'facebook') {
            $api_id = _g("api_id");
            $apisns = $this->apisnslogic->getOne("id=" . ((int) $api_id) . " and api_type='facebook' and status=1 ");
            if ($apisns) {
                @session_start();
                $_SESSION['api_login_apiID'] = (int) $api_id;
                $_SESSION['api_login_apikey'] = _g("api_key");
                $_SESSION['api_login_apiemail'] = _g("api_email");
            }
        }
        $api_id = $_SESSION['api_login_apiID'];

        $api_key = $_SESSION['api_login_apikey'];

        $user_email = $_SESSION['api_login_apiemail'];

        /*        $api_id=_g("api_id");//接口ID
          $api_key=_g("api_key");//第三方key ID
          $api_type=_g("type");//facebook or twitter ...
          $user_email=_g("api_email"); */
        $cond = "api_id =" . $api_id . " and api_key='" . $api_key . "'";
        $userapi = $this->userapiLogic->getOne($cond);
        if (!$userapi) {
            //用户第一次使用第三方登录，跳转至API注册页面     
            $data = array();
            $data['api_id'] = $api_id;
            $data['api_key'] = $api_key;
            $data['type'] = $api_type;
            $data['api_email'] = $user_email;
            if ($user_email != "") {
                $data['api_login_fast'] = 1;
            }
            $ref = Common::frontURL('home', 'apilogin', 'register', $data);
            return $this->_redirect($ref);
        } else {
            $this->login($userapi['user_id']);
        }
    }

    private function login($user_id) {
        $cond = 'id =' . $user_id;
        $userinfo = $this->userLogic->getOne($cond);
        $name = $userinfo['base_name'];
        $password = $userinfo['password'];
        if (!$name) {
            return $this->showMessage('login_name_is_empty');
        }
        if (!$password) {
            return $this->showMessage('login_password_is_empty');
        }
        $user = $this->userLogic->login($name, $password, TRUE);
        if ($user) {
            _setSession('user_id', $user['id']);
            _setSession('user_base_name', $user['base_name']);
            $this->_checkCookieCart($user['id']);
            $langLogic = $this->load('language');
            $now = time();
            $log_data = array(
                'language_id' => $langLogic->language_id,
                'user_id' => $user['id'],
                'create_year' => date('Y', $now),
                'create_month' => date('Ym', $now),
                'create_day' => date('Ymd', $now),
                'last_ip' => Common::_ip2long(Common::ip()),
            );
            $logLogic = $this->load('userLoginLog');
            $logLogic->save($log_data);
            GrowthFactory::dailyLoginAfter($user);
            CreditFactory::dailyLoginAfter($user);
            $ref = Common::frontURL('home', 'account', 'index');

            $_SESSION['api_login_apiID'] = '';
            $_SESSION['api_login_apikey'] = '';
            $_SESSION['api_login_apiemail'] = '';
            return $this->_redirect($ref);
        }
        return $this->showMessage('login_failure');
    }

    private function register() {

//        $api_id = $_SESSION['api_login_apiID'];
//        $api_key = $_SESSION['api_login_apikey'];
//        $user_email = $_SESSION['api_login_apiemail'];

              $api_id=Common::queryInt(_p("api_id"));//接口ID
              $api_key=_p("api_key");//第三方key ID
              $api_type=_p("type");//第三方类型
              
        $cond = "api_id =" . $api_id . " and api_key='" . $api_key . "'";
        $userapi = $this->userapiLogic->getOne($cond);
        
        if ($userapi['user_id']) {
            $this->login($userapi['user_id']);
        }

        $bind_type = _p('bind_type');
        $security_email = _p('email');
        $password = _p('password');
        $confirm_password = _p('confirm_password');

        $domain = SITE_URL;
        $langLogic = $this->load('language');
        $ipJoinCountryLogic = $this->load('ipJoinCountry');
        $ip = Common::_ip2long(Common::ip());

        $groupLogic = $this->load('userGroup');
        $default_group_id = 0;
        foreach ($groupLogic->getAll() as $key => $value)
        {
          if($value['is_default'] == 1)
          {
            $default_group_id = $key;
          }
        }
        
        $user_data = array(
            'base_name' => $security_email,
            'password' => md5(md5($password)),
            'status' => 1,
            'ip' => $ip,
            'domain' => Common::strEscape($domain),
            //            'question'    => _p('question'),
            //            'answer'      => _p('answer'),
            'source' => $this->getSource(),
            'language_id' => $langLogic->language_id,
            'country_id' => $ipJoinCountryLogic->getCountryId($ip),
            'user_group_id' => $default_group_id,
            'create_time' => SYS_TIME,
            'update_time' => SYS_TIME,
            'parent_user_id' => (int)$this->getUserSource(),
        );

        //判断绑定类型 1注册新用户，2老用户
        if ($bind_type == 1) {
            if (!Common::isEmail($security_email)) {
                return $this->showMessage('please_enter_email');
            }
            if ($this->userLogic->isExistName($security_email)) {
                return $this->showMessage('user_email_exist');
            }
            /*
              if(!_p('question') || _p('answer'))
              {
              return $this->showMessage('question_answer_not_empty');
              }
             * 
             */
            if (!_p('validateCode') || strtolower(_p('validateCode')) != strtolower(_s('validate_code'))) {
                return $this->showMessage('code_error_tips');
            }

            $register = $this->userLogic->save($user_data);
            if ($register) {
                if ($api_id != "" && $api_key != "") {
                    $userapi_data = array(
                        'user_id' => $register,
                        'api_id' => (int) $api_id,
                        'api_key' => $api_key,
                    );
                    $apisns = $this->apisnslogic->getOne("id=" . ((int) $api_id));
                    if ($apisns)
                        $this->userapiLogic->save($userapi_data);
                    //$this->userapiLogic->save($userapi_data);
                }
                _setSession('user_id', $register);
                _setSession('user_base_name', $security_email);
                _setSession('user_sign', md5(md5($security_email.$register)));
                _setSession('user_group', $default_group_id);
                setcookie('user_id', $register, 0, '/');
                setcookie('user_base_name', $security_email, 0, '/');
                setcookie('user_sign', md5(md5($security_email.$register)), 0, '/');
                setcookie('user_group', $default_group_id, 0, '/');
                $this->_checkCookieCart($register);
                $now = time();
                $log_data = array(
                    'language_id' => $langLogic->language_id,
                    'user_id' => $register,
                    'create_year' => date('Y', $now),
                    'create_month' => date('Ym', $now),
                    'create_day' => date('Ymd', $now),
                    'last_ip' => $ip,
                );
                $logLogic = $this->load('userLoginLog');
                $logLogic->save($log_data);
                $user = array(
                    'id' => $register,
                    'base_name'   => $security_email,
                    'language_id' => $langLogic->language_id ,
                );
                GrowthFactory::dailyLoginAfter($user);
                CreditFactory::dailyLoginAfter($user);
                $ref = Common::frontURL('home', 'account', 'index');
				
				$user = array(
                    'id' => $register,
                    'base_name'   => $security_email,
                    'language_id' => $langLogic->language_id ,
                );
				$user['realpwd'] = _p('password');
                GrowthFactory::userRegisterAfter($user);
                GrowthFactory::recommendUserAfter($user);
                EventFactory::userRegisterAfter($user);
                CreditFactory::userRegisterAfter($user);
                ReportFactory::userReport($user_data);
				$this->cleanUserSource();
                return $this->_redirect($ref);
            }
        }else {
            $security_email = _p('my_email');
            if (!Common::isEmail($security_email)) {
                return $this->showMessage('please_enter_email');
            }
            if (!$password) {
                return $this->showMessage('please_enter_password');
            }
            if (!Common::isPassword($password)) {
                return $this->showMessage('password_tip');
            }
            $user = $this->userLogic->login($security_email, $password);
            if ($user['id']) {
                if ($api_id != "" && $api_key != "") {
                    $userapi_data = array(
                        'user_id' => $user['id'],
                        'api_id' => (int) $api_id,
                        'api_key' => $api_key,
                    );
                    $cond = "api_id =" . $api_id . " and user_id='" . $user['id'] . "'";
                    $userapi = $this->userapiLogic->getOne($cond);
                    if( $userapi)
                    {
                        $this->userapiLogic->delete($cond);
                    }
                    $apisns = $this->apisnslogic->getOne("id=" . ((int) $api_id));
                    if ($apisns)
                        $this->userapiLogic->save($userapi_data);
                }
                _setSession('user_id', $user['id']);
                _setSession('user_base_name', $security_email);
                $this->_checkCookieCart($user['id']);
                $now = time();
                $log_data = array(
                    'language_id' => $langLogic->language_id,
                    'user_id' => $user['id'],
                    'create_year' => date('Y', $now),
                    'create_month' => date('Ym', $now),
                    'create_day' => date('Ymd', $now),
                    'last_ip' => $ip,
                );
                $logLogic = $this->load('userLoginLog');
                $logLogic->save($log_data);
                GrowthFactory::dailyLoginAfter($user);
                CreditFactory::dailyLoginAfter($user);
                $ref = Common::frontURL('home', 'account', 'index');
				
                return $this->_redirect($ref);
            }else{
                return $this->showMessage('login_failure');
            }
        }

        return $this->showMessage('register_failure');
    }

    /**
     * 绑定现有的账户
     * @return type
     */
    private function acount() {

        $api_id = $_SESSION['api_login_apiID'];
        $api_key = $_SESSION['api_login_apikey'];
        $user_email = $_SESSION['api_login_apiemail'];

        /*        $api_id=_p("api_id");//接口ID
          $api_key=_p("api_key");//第三方key ID
          $api_type=_p("type");//facebook or twitter ...
          $user_email=_p("api_email"); */
        if (strtolower($api_id) == "undefined") {
            $api_id = "";
        }
        if (strtolower($api_key) == "undefined") {
            $api_key = "";
        }
        if (strtolower($api_type) == "undefined") {
            $api_type = "";
        }
        if (strtolower($user_email) == "undefined") {
            $user_email = "";
        }
        $cond = "api_id =" . $api_id . " and api_key='" . $api_key . "'";
        $userapi = $this->userapiLogic->getOne($cond);
        if ($userapi) {
            $this->login($userapi['user_id']);
        }
        $security_email = _p('email');
        $password = _p('password');
        $confirm_password = _p('confirm_password');


        if (!Common::isEmail($security_email)) {
            return $this->showMessage('please_enter_email');
        }
        if ($this->userLogic->isExistName($security_email)) {
            return $this->showMessage('user_email_exist');
        }
        /*
          if(!_p('question') || _p('answer'))
          {
          return $this->showMessage('question_answer_not_empty');
          }
         * 
         */
        if (!_p('validateCode') || strtolower(_p('validateCode')) != strtolower(_s('validate_code'))) {
            return $this->showMessage('code_error_tips');
        }
        $domain = SITE_PROTOCOL . SITE_URL;
        $langLogic = $this->load('language');
        $ipJoinCountryLogic = $this->load('ipJoinCountry');
        $ip = Common::_ip2long(Common::ip());
        $user_data = array(
            'base_name' => $security_email,
            'password' => md5(md5($password)),
            'status' => 1,
            'ip' => $ip,
            'domain' => Common::strEscape($domain),
//            'question'    => _p('question'),
//            'answer'      => _p('answer'),
            'source' => $this->getSource(),
            'language_id' => $langLogic->language_id,
            'country_id' => $ipJoinCountryLogic->getCountryId($ip),
            'create_time' => SYS_TIME,
        );
        $register = $this->userLogic->save($user_data);
        if ($register) {
            if ($api_id != "" && $api_key != "") {
                $userapi_data = array(
                    'user_id' => $register,
                    'api_id' => (int) $api_id,
                    'api_key' => $api_key,
                );
                $apisns = $this->apisnslogic->getOne("id=" . ((int) $api_id));
                if ($apisns)
                    $this->userapiLogic->save($userapi_data);
                $this->userapiLogic->save($userapi_data);
            }
            _setSession('user_id', $register);
            _setSession('user_base_name', $security_email);
            $this->_checkCookieCart($register);
            $now = time();
            $log_data = array(
                'language_id' => $langLogic->language_id,
                'user_id' => $register,
                'create_year' => date('Y', $now),
                'create_month' => date('Ym', $now),
                'create_day' => date('Ymd', $now),
                'last_ip' => $ip,
            );
            $logLogic = $this->load('userLoginLog');
            $logLogic->save($log_data);
            $user = array(
                'id' => $register,
                'base_name'   => $security_email,
                'language_id' => $langLogic->language_id ,
            );
            GrowthFactory::dailyLoginAfter($user);
            CreditFactory::dailyLoginAfter($user);
            $ref = Common::frontURL('home', 'account', 'index');
            ReportFactory::userReport($user_data);

            $_SESSION['api_login_apiID'] = '';
            $_SESSION['api_login_apikey'] = '';
            $_SESSION['api_login_apiemail'] = '';
            return $this->_redirect($ref);
        }
        return $this->showMessage('register_failure');
    }

    /**
     * 检查cookie是有购物车产品 
     */
    public function _checkCookieCart($user_id) {
        $cartSku = _c('cartsku') ? json_decode(_c('cartsku')) : array();
        $cartLogic = $this->load('userCart');
        $exist_cart = $cartLogic->getListByUserId($user_id);
        $offset = 0;
        foreach ($cartSku as $value) {
            $is_exist = FALSE;
            foreach ($exist_cart as $cart) {
                if ($value->goods_id == $cart['goods_id'] && $value->sku_code == $cart['sku_code']) {
                    if (intval($value->product_num) > intval($cart['product_num'])) {
                        $result = $cartLogic->save(array('product_num' => $value->product_num), $cart['id']);
                        if ($result) {
                            $offset += (intval($value->product_num) - intval($cart['product_num']));
                        }
                    }
                    $is_exist = TRUE;
                    break;
                }
            }
            if (!$is_exist) {
                $cart_data = array(
                    'goods_id' => $value->goods_id,
                    'sku_code' => $value->sku_code,
                    'product_num' => $value->product_num,
                    'user_id' => $user_id,
                    'create_time' => $value->create_time,
                );
                $res = $cartLogic->save($cart_data);
                if ($res) {
                    $offset += $value->product_num;
                }
            }
        }
        setcookie('cartsku', '', time() + 30, '/');
        if ($offset > 0) {
            ReportFactory::userSalesReport($user_id, array('cart_counts' => $offset));
        }
    }

}
?>

