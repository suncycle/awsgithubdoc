<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Index
 *
 * @author xrx
 */
class IndexController extends AppController {

    private $cacheConfig;

    public function __construct() {
        parent::__construct();
        $this->cacheConfig = APP_ROOT . 'conf/cache.conf.php';
    }

    public function actionDefault() {
        global $current_currency, $site_info;
        if ($_GET['page_code'] == 404) {
            $this->exception();
        }
		//if (file_exists($this->cacheConfig))
        	//require_once $this->cacheConfig;
        if ($cache_cfg['sites'][1]['status'] == 1 && false) {
            $language_id = $site_info['language_id'];
            $currency_id = $current_currency['id'];
            $cache_id = "index-" . $language_id . "-" . $currency_id;
            $CacheTime = $cache_cfg['sites'][1]['domain_name'];
            Core::$htmlFile = 'common/index';
            Core::$isdisplay = 0;
            Core::$tpl->setCaching(true);
            Core::$tpl->setCacheTime($CacheTime * 3600);
            Core::$tpl->render(Core::$htmlFile . ".htm", $cache_id);
        } else {
            Core::$htmlFile = 'common/index';
            Core::$isdisplay = 0;
            Core::$tpl->setCaching(false);
            Core::$tpl->render(Core::$htmlFile . ".htm");
        }
    }

    public function actionTest() {
//      $emailLogic = $this->load('mailSender');
//      global $cfg;
//      $language_id = $this->load('language')->language_id;
//		$Logic = $this->load('message');
//		echo $Logic->sendTo(33,'Happy New Year','This Email was automatically sent by system to remind you what happened to you . Please do not reply to this email as we are unable to respond to messages sent to this address. For any questions');
//		$this->triggerEvent();
//      $array = array();
//      echo count($array);
//      $groupLogic = $this->load('userGroup');
//      发邮件
//      $emailLogic->init($language_id);
//      $result = $emailLogic->sendTo('tech@35zh.com','test', 'why why why');
//	    echo $result === true ? 'success' : 0;
//      $diy_config = $this->load('DiyConfig');
//      $diy_config->getAll(1);
//      phpinfo();
//        Core::$htmlFile  = 'common/test';
//        Core::$isdisplay = 0;
//        Core::$tpl->render(Core::$htmlFile . '.htm');
//        $res = $this->load('SpecialOfferShippingJoinGoods')->getShippingInfo(array(7,8,9,10,11,12,13,14));
//          _debug($res);
//        $devLogic = $this->load('Dev', 'user');
//        $devLogic->setTable('user');
//        _debug($devLogic->findAll());
//        $cache_dir = APP_ROOT . 'cache/tpl/';
//         Dir::delDirAndFile($cache_dir);
//      $sql = 'select count(goods_id) as num from z_goods_category_rel group by goods_category_id';
//      $goodsLogic = $this->load('goods');
//      $res = $goodsLogic->query($sql);
//      _debug($res);
//        $devLogic = $this->load('Dev', 'admin');
//        _debug($devLogic->findAll());
        print_r(phpinfo());
    }

    /*
      public function actionUpdateSQL()
      {
      $cond = 'image like "%upload/%"';
      $imageLogic = $this->load('productOtherImage');
      $images = $imageLogic->findAll($cond);
      //更新图片库
      $i = 0;
      $j = 0;
      foreach($images as $value)
      {
      $map = Zhtx::createDataMap();
      $map->addEntry('image', Common::strEscape(substr($value['image'], 7)), DB::VARCHAR);
      if($imageLogic->updateById($map, $value['id']))
      {
      $i++;
      }
      else
      {
      $j++;
      }
      }
      //更新单品图库
      $productLogic = $this->load('product');
      $pimages =  $productLogic->findAll($cond);
      foreach($pimages as $value)
      {
      $map = Zhtx::createDataMap();
      $map->addEntry('image', Common::strEscape(substr($value['image'], 7)), DB::VARCHAR);
      if($productLogic->updateById($map, $value['id']))
      {
      $i++;
      }
      else
      {
      $j++;
      }
      }
      //更新商品图库
      $goodsLogic = $this->load('goods');
      $gimages =  $goodsLogic->findAll($cond);
      foreach($gimages as $value)
      {
      $map = Zhtx::createDataMap();
      $map->addEntry('image', Common::strEscape(substr($value['image'], 7)), DB::VARCHAR);
      if($goodsLogic->updateById($map, $value['id']))
      {
      $i++;
      }
      else
      {
      $j++;
      }
      }
      echo 'update success ' . $i . ' 条 sql ， ' . ' failure ' . $j . ' 条 sql ';
      }

     *
     */

    public function actionDownload() {
//    $download = 'http://upgrade.theme.zhcart.com/hjp/20131202-1014-1.zip';
//    $content = ZhCurl::getZip($download);
//    $upgrade_zip = APP_ROOT. 'test.zip';
//    @file_put_contents($upgrade_zip, $content);
//$rh = fopen($zip, 'rb');
//if($rh)
//{
//  while (!feof($rh)) {
//     if (fwrite($dir, fread($rh, 1024)) === FALSE) {
//          // 'Download error: Cannot write to file ('.$file_target.')';
//          return true;
//      }
//   }
//
//}
//       Common::unzip($zip, $dir);
//     echo file_get_contents($zip);
    }

    /*
      public function actionRemoveImg()
      {
      $file = 'E:\workspace\zhtx\src/upload/goods/nike03.jpg';
      if(strpos($file, '/thumb/') === FALSE)
      {
      $image_base_path = APP_ROOT.UPLOAD_DIR;
      $file_name = str_replace($image_base_path, '', $file);
      $thumb_dir = $image_base_path. 'thumb/';
      if ($fp = @opendir($thumb_dir))
      {
      while ($hander = readdir($fp))
      {
      if ($hander != '.' && $hander != '..' && substr($hander, 0, 1) != '.')
      {
      $thubm_file = $thumb_dir . $hander.'/'.$file_name;
      print_r($thubm_file);
      echo '<br />';
      if(is_file($thubm_file))
      {
      @unlink($thubm_file);
      }
      }
      }
      closedir($fp);
      }
      }

      }
     *
     */
}

?>
