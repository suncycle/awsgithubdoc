<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of product
 *
 * @author hjp<huangjp@35zh.com>
 */
class BrandsController extends AppController
{

    private $languageLogic;
    private $brandjoinlanglogic;

    public function __construct()
    {
        parent::__construct();
        $this->languageLogic = $this->load('language');
        $this->brandjoinlanglogic = AppController::load('brandJoinLanguage');
    }

    public function actionList()
    {
        $language_id = $this->languageLogic->language_id;
        $where = "1=1";
        $where .= " and l.language_id=" . $language_id;
        $where .= " and b.status=1";

        $logic = AppController::load('brandJoinLanguage');
        $res = $logic->getList($where);
        $brands = array();
        $others = array();
        foreach ($res["list"] as $data)
        {
            $firstchr = substr(ucfirst($data['base_name']), 0, 1);
            $firstord = ord($firstchr);
            if (($firstord >= 97 && $firstord <= 122) || ($firstord >= 65 && $firstord <= 90) || ($firstord >= 48 && $firstord <= 57))
            {
                $brands[$firstchr][] = $data;
            }
            else
            {
                $others[] = $data;
            }
        }
        ksort($brands);
        if($others)
        {
            $brands['Others'] = $others;
        }
        Core::$tpl->set("brands", $brands);
        Core::$htmlFile = 'brands/default';
        Core::$isdisplay = 0;
        Core::$tpl->render(Core::$htmlFile . '.htm');
    }

}

?>