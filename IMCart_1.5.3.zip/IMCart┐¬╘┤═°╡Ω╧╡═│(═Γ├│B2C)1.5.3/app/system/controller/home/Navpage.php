<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NavpageController
 *
 * @author cx
 */
class NavpageController extends AppController {

    private $navPageJoinLangLogic;
    private $languageLogic;

    public function __construct() {
        parent::__construct();
        $this->navPageJoinLangLogic = $this->load('navPageJoinLanguage');
        $this->languageLogic = $this->load('language');
    }
    
    public function actionHelp()
    {
        
    }

    public function actionDetail() {
        global $cfg;
        $urlMaker = $this->load('UrlMaker');
        $language_id = $this->languageLogic->language_id;
        $rewrite = array();
        $rewrite["type"] = $cfg['sites'][$language_id]['rewrite_type'];
        $rewrite["name_type"] = $cfg['sites'][$language_id]['rewrite_prename'];
        $uri = $_SERVER['REQUEST_URI'];
        if (strpos($uri, '?'))
            $query_string = substr($uri, strpos($uri, '?'), strlen($uri));
        $id = Common::queryInt(_g('navpage_id'));
        $navpage = $this->navPageJoinLangLogic->getItem($id, $language_id);
        if (!$navpage) {
            $this->exception();
        }

        $href = $urlMaker->getNavPageUrl($id, $language_id, $rewrite);
        if(!strstr(str_replace(array('page-','-html'),array('page/','.html'),'/'.Common::makeUrlName($uri)), $href)&&!$navpage['page_url']){
            //Header("HTTP/1.0 301 Moved Permanently");
            //Header("Location: " . $href . $query_string);
        }
        Core::$tpl->set('article', $navpage);
    }

}

?>
