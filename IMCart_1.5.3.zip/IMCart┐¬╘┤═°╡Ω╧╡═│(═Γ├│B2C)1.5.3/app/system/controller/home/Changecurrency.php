<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 货币转换
 *
 * @author hjp
 */
class ChangecurrencyController extends AppController
{
    private $currencyLogic;
    public function __construct()
    {
        parent::__construct();
        $this->currencyLogic = $this->load('currency');
    }
    public function actionDefault()
    { 
        $currency=Common::queryStr(_g('currency'),"");
        if($currency!="")
        {
             $cond = "status=1 and standard_code = '" . $currency ."'";
             $currency_res = $this->currencyLogic->getOne($cond);
             if(!$currency_res)
             {                 
                  return $this->showMessage('illegal_parameters');
             }
             //$_SESSION["currency_id"]=$currency_res["id"];
             _setSession("exchange_rate", "");
             _setSession("symbol_left", "");
             _setSession("change_currency_id", $currency_res["id"]);
        }
        $this->_redirect($_SERVER['HTTP_REFERER']);
    }
    
}
?>
