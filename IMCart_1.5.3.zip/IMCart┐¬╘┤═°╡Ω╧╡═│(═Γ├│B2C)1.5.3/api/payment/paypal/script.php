<?php



class paypal extends BasePaymentInterface

{	

	public function getInterfaceForm($orderpaymnet_id)

	{

//		$paymentLogic=$this->load("payment");

		$orderLogic=$this->load("order");

//		$orderAddressLogic=$this->load("orderAddress");

		$orderPaymentLogic=$this->load("orderPayment");

		

		$orderPayment = $orderPaymentLogic->getOne('id='.$orderpaymnet_id); 

		$order = $orderLogic->getOne('id='.$orderPayment['order_id']);

//		$payment = $paymentLogic->getOne('id='.$orderPayment['payment_id']);

		$this->loadConfig($orderPayment['payment_id']);

		//-------------

//        $html = "<form action='https://www.sandbox.paypal.com/row/cgi-bin/webscr' name='payment_form' id='payment_form' method='post' target='_blank'>\n";

        

        if($this->post_pay_domain)

        {

          $html = "<form action='http://".$this->post_pay_domain."/h-order-redirectPay.html' name='payment_form' id='payment_form' method='post' target='_blank'>\n";

          $html .= "<input type=\"hidden\" name=\"pay_url\" value=\"https://www.paypal.com/row/cgi-bin/webscr\">\n";

          $html .= "<input type=\"hidden\" name=\"notify_url\" value=\"http://".$this->post_pay_domain."/pay_result_paypal_server.html\">\n";

        }

        else

        {

          $html = "<form action='https://www.paypal.com/row/cgi-bin/webscr' name='payment_form' id='payment_form' method='post' target='_blank'>\n";         

          $html .= "<input type=\"hidden\" name=\"notify_url\" value=\"http://".$_SERVER['SERVER_NAME'].FOLDER_ROOT."pay_result_paypal_server.html\">\n";

        }

      

        $html .= "<input type=\"hidden\" name=\"cmd\" value=\"_xclick\">\n";

		$html .= "<input type=\"hidden\" name=\"business\" value=\"".$this->cfg["exp_paypal"]."\">\n";

       $html .= "<input type=\"hidden\" name=\"image_url\" value=\"".$this->cfg["exp_image_url"]."\">\n";

	   $html .= "<input type=\"hidden\" name=\"cancel_return\" value=\"".$this->cfg["exp_cancel_return"]."\">\n";

//        $html .= "<input type=\"hidden\" name=\"business\" value=\"359285617-facilitator@qq.com\">\n";

//        $html .= "<input type=\"hidden\" name=\"notify_url\" value=\"http://".$_SERVER['SERVER_NAME'].FOLDER_ROOT."pay_result_paypal_server.html\">\n";

//        

		$html .= "<input type=\"hidden\" name=\"item_name\" value=\"" . $order['itemno'] . "\">\n";

        $html .= "<input type=\"hidden\" name=\"item_number\" value=\"" . $order['itemno'] . "\">\n";		

		$html .= "<input type=\"hidden\" name=\"return\" value=\"http://".$_SERVER['SERVER_NAME'].FOLDER_ROOT."pay_result_paypal_client.html?item_number=". $order['itemno']."\">\n";

		$html .= "<input type=\"hidden\" name=\"currency_code\" value=\"" . $order['currency_code'] . "\">\n";
		$html .= "<input type=\"hidden\" name=\"bn\" value=\"35zh_Ecom\">\n";
		$html .= "<input type=\"hidden\" name=\"amount\" value=\"" . Common::price_format($orderPayment['real_currency_amount']) . "\">\n";

		$html .= "</form>";

		return $html;

	}

	/**

 	* 初始化POST ORDER, ORDER_PAYMENT

 	*/

	public function initPost()

	{     

        //从 PayPal 出读取 POST 信息同时添加变量„cmd‟

        $req = 'cmd=_notify-validate';

        foreach ($_POST as $key => $value)

        {

          $value = urlencode(stripslashes($value));

          $req .= "&$key=$value";

        }

        $header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";

//        $header .= "Host: www.sandbox.paypal.com\r\n"; 

        $header .= "Host: www.paypal.com\r\n"; 

        $header .= "Content-Type:application/x-www-form-urlencoded\r\n";

        $header .= "Content-Length:" . strlen($req) . "\r\n\r\n";

//        $fp=fsockopen('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);

        $fp=fsockopen('tls://www.paypal.com', 80, $errno, $errstr, 30);



        $item_name        = $_POST['item_name'];

        $item_number      = $_POST['item_number'];

        $payment_status   = $_POST['payment_status'];

        $payment_amount   = $_POST['mc_gross'];

//        $payment_currency = $_POST['mc_currency'];

        $txn_id           = $_POST['txn_id'];

        $receiver_email   = $_POST['receiver_email'];

        $payer_email      = $_POST['payer_email'];

        if($_GET['item_number']!='')
		{
			$item_number = $_GET['item_number'] ;
			$payment_status = 'Completed' ;
		}

//        foreach($_POST as $key => $value)

//        {

//          Common::log($key . ' = ' . $value);

//        }

//        Common::log('item_number =>' . $item_number . ' : payment_status =>' . $payment_status . ' : receiver_email =>' . $receiver_email); 

        $this->orderNo =   $item_number;   

        $orderPaymentLogic=$this->load("orderPayment");

		//Common::log("数据：[completed=1]".json_encode($_POST));

		$orderLogic = $this->load("order");

        $order = $orderLogic->getOne("itemno='" . $item_number . "'");

		if (!$order) 

		{

            //订单号 错误

            Common::log('order number error'.$item_number."||".json_encode($_GET).json_encode($_POST));

            return;

        }


		if($_GET['type']=='auto' && $_GET['st']=='Completed')
		{
			$payment_status = 'Completed'	;
		}


			  if($payment_status == 'Completed')

			  {

					$orderpayment = $orderPaymentLogic->getOne("order_id='".$order['id']. "'");

					if($orderpayment)

					{                      

						$this->orderpayment_id = $orderpayment['id'];

						$this->order_id        = $orderpayment['order_id'];
						
						if($orderpayment['status'] == 1)
						{
							$orderpayment['completed'] = 1;
							return $orderpayment;
						}
						//检查付款金额和货币单位是否正确

						if($_GET['type']=='client')

						{



							$orderpayment['completed'] = 1;							

							//Common::log("客户端数据：[completed=1]".json_encode($_POST));

							return $orderpayment ;



						}

						else

						{

							$orderpayment['completed'] = 0;

							//Common::log("服务端数据：[completed=0]".json_encode($_POST));

						}

						

						  $payment_data = array(

							  'pay_method_no' => $txn_id,                           

							  'status'        => 1,

							  'end_time' => SYS_TIME,

							  'payer'    => $payer_email,

						  );

						  $res = $orderPaymentLogic->save($payment_data, $orderpayment['id']);

						  if($res)

						  {

							$orderpayment['pay_method_no'] = $txn_id;

							$orderpayment['end_time']      = SYS_TIME;

							$orderpayment['status']        = 1;

							$orderpayment['payer']         = $payer_email;

							$orderpayment['payment_type']         = 1;

							//支付成功后更新库存

							$this->load('orderItem')->updateStock($orderpayment['order_id']);

							return $orderpayment;

						  }

						  Common::log('order_payment update error');

					}

					else

					{

					  Common::log('no_order_payment');

					}

			  }

	}

	

	public function responseResult()

	{

		return "";

	}

	/**

     * 获取订单号

     * @return type 

     */

	public function getOrderPaymentTradeNo()

	{

		return $_POST["item_name"];

	}	

	public function getOrderPaymentMap()

	{

        $orderLogic=$this->load("order");

		$paymentLogic=$this->load("payment");		

		$orderAddressLogic=$this->load("orderAddress");

		$orderPaymentLogic=$this->load("orderPayment");

		

		$orderPayment = $orderPaymentLogic->getOne('id='.$this->orderpayment_id);

		$order = $orderLogic->getOne('id='.$this->order_id);

		$payment = $paymentLogic->getOne('id='.$orderPayment['payment_id']);

		$orderAddress = $orderAddressLogic->getOne('order_id='.$order['id']);

		$payment_status = $_POST['payment_status'];

		if($payment_status=="Completed")

		{

			$map = array();

			$map["pay_method_no"] = $_POST['txn_id'];

			$map["amount"] = $_POST['mc_gross'];

			$map["status"] = 1;

			return $map;

		}

		else

			return false;

	}

	

	

	public function getOrderLogMap()

	{

		$map = array();

		$map["admin_id"] = 0;

		$map["admin_name"] = "system";

		$map["order_id"] = $this->order_id;

		$map["result"] = 1;

		$map["remark"] = $_POST['payment_status'].":".$_POST['pending_reason'].$_POST['reason_code'];

		$map["behavior"] = "支付接口服务器端回调";

		return $map;

	}

	

	public function getResultType()

	{

		if(_g("p1")=="server")

			return 1;

		else

			return 0;

	}

}



?>