<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF" width="80">支付账号:</td>
        <td  bgcolor="#FFFFFF" ><input type="text" class="text" name="exp_paypal" size="50" value="<?php echo $param["exp_paypal"];?>" /></td>
    </tr>
     <tr>
        <td bgcolor="#FFFFFF" width="80">取消返回:</td>
        <td  bgcolor="#FFFFFF" ><input type="text" class="text" name="exp_cancel_return" size="50" value="<?php echo $param["exp_cancel_return"];?>" /></td>
    </tr>
     <tr>
        <td bgcolor="#FFFFFF" width="80">商家LOGO:</td>
        <td  bgcolor="#FFFFFF" ><input type="text" class="text" name="exp_image_url" size="50" value="<?php echo $param["exp_image_url"];?>" /></td>
    </tr>
    <tr>
      <td bgcolor="#FFFFFF" width="80">启用快捷支付:</td>
      <td bgcolor="#FFFFFF"><input type="checkbox" value="1" name="exp_express_checkout" id="express_checkout" <?php if($param["exp_express_checkout"] == 1){echo 'checked="checked"';};?>/></td>
    </tr>
</table>
        <div <?php if($param["exp_express_checkout"] == 1){echo "style=\"display:'';\"";}else{echo "style=\"display:none;\"";};?> id="express_checkout_form">
          <table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
          <tr>
            <td bgcolor="#FFFFFF" width="80">API用户名:</td>
            <td bgcolor="#FFFFFF"><input type="text" value="<?php echo $param["exp_api_username"];?>" name="exp_api_username" size="50"/></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF" width="80">API密码:</td>
            <td bgcolor="#FFFFFF"><input type="text" value="<?php echo $param["exp_api_password"];?>" name="exp_api_password" size="50"/></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF" width="80">API签名:</td>
            <td bgcolor="#FFFFFF"><input type="text" value="<?php echo $param["exp_api_sign"];?>" name="exp_api_sign" size="50"/></td>
          </tr>
        </table>
        </div>
    
<script>
  $(function(){
    $('#express_checkout').click(function(){
       var _this = $(this);
       if(_this.attr('checked') == 'checked')
         {
           $('#express_checkout_form').show();
         }
         else{
           $('#express_checkout_form').hide();
         }
    })
   
  });
</script>