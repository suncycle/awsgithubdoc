<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once(APP_ROOT . 'api/login/tumblr/package/tumblr/tumblroauth.php');
class tumblr
{

    private $param;

    public function SetConfig($param)
    {
        $this->param = $param;
    }

    public function redirectURL()
    {
        /* Start session and load library. */
        @session_start();
        
        /* Build TumblrOAuth object with client credentials. */
        $connection = new TumblrOAuth($this->param['exp_tumblr_key'], $this->param['exp_tumblr_secret']);

        /* Get temporary credentials. */
        $request_token = $connection->getRequestToken($this->param['exp_tumblr_callback']);
        //var_dump($request_token);
        //var_dump($connection->http_info);
        /* Save temporary credentials to session. */
        $_SESSION['oauth_token'] = $token = $request_token['oauth_token'];
        $_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret'];

        /* If last connection failed don't display authorization link. */
        switch ($connection->http_code) {
          case 200:
            /* Build authorize URL and redirect user to Twitter. */
            return $url = $connection->getAuthorizeURL($token);
            break;
          default:
            /* Show notification if something went wrong. */
            die('Could not connect to Tumblr. Refresh the page or try again later.');
        }
    }

    public function callBack()
    {
        /* Start session and load lib */
        @session_start();
        
        /* If the oauth_token is old redirect to the connect page. */
        if (isset($_REQUEST['oauth_token']) && $_SESSION['oauth_token'] !== $_REQUEST['oauth_token']) {
          $_SESSION['oauth_status'] = 'oldtoken';
          //header('Location: ./clearsessions.php');
        }

        /* Create TumblrOAuth object with app key/secret and token key/secret from default phase */
        $connection = new TumblrOAuth($this->param['exp_tumblr_key'], $this->param['exp_tumblr_secret'], $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);

        /* Request access tokens from tumblr */
        $access_token = $connection->getAccessToken($_REQUEST['oauth_verifier']);
        
        /* Save the access tokens. Normally these would be saved in a database for future use. */

        /* Remove no longer needed request tokens */
        unset($_SESSION['oauth_token']);
        unset($_SESSION['oauth_token_secret']);

        /* If HTTP response is 200 continue otherwise send to connect page to retry */
        if (200 == $connection->http_code) {
          /* The user has been verified and the access tokens can be saved for future use */
          $_SESSION['status'] = 'verified';
          $connection = new TumblrOAuth($this->param['exp_tumblr_key'], $this->param['exp_tumblr_secret'], $access_token['oauth_token'], $access_token['oauth_token_secret']);

        /* If method is set change API call made. Test is called by default. */
                $content = $connection->oauth_post('/user/info');
                if($content->response->user->name)
                {
                        $return = array(
                            'api_id' => $content->response->user->name,
                            'api_type' => 'tumblr',
                        );
                        return $return;
                }
                //var_dump($content);
                die('Error');
        } else {
          /* Save HTTP status for error dialog on connnect page.*/
          //header('Location: ./clearsessions.php');
	  die('Http Error');
        }
    }

}

?>
