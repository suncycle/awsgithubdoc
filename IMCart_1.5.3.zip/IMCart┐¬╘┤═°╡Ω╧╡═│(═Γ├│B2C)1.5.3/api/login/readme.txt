联合登录开发标准1
1 每种联合登录一个文件夹 类似 "facebook"  "twitter"  "googleplus"

2 每种联合登录文件夹下存放规则
/readme.txt 这个文档已UTF-8编码保存，里面内容为联合登录的名称。例如：FACEBOOK登录,G+登录
/form.php 用来存放需要配置的参数表单
/使用说明.txt

3 form.php PHP文件标准
所有的INPUT文本框的NAME值统一 exp_ 开头
例如：
<input name="exp_facebook_app" value="<?php echo $param["exp_facebook_app"]; ?>" style="width:300px" type="text" />

VALUE属性的值 统一用 $obj 数组调用，数组的键为该INPUT元素的NAME名称。