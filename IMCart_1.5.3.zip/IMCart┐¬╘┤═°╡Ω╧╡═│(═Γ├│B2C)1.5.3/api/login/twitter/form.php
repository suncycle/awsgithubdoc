<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
 
  <tr>
    <td bgcolor="#FFFFFF">CONSUMER_KEY</td>
    <td bgcolor="#FFFFFF"><input name="exp_twitter_key" value="<?php echo $param["exp_twitter_key"]; ?>" style="width:300px" type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">CONSUMER_SECRET</td>
    <td bgcolor="#FFFFFF"><input name="exp_twitter_secret" value="<?php echo $param["exp_twitter_secret"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">OAUTH_CALLBACK</td>
    <td bgcolor="#FFFFFF"><input name="exp_twitter_callback" value="<?php echo $param["exp_twitter_callback"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
</table>