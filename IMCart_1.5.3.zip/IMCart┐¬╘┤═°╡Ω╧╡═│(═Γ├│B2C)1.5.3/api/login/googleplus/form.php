<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">application_name</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_application_name" value="<?php echo $param["exp_googleplus_application_name"]; ?>" style="width:300px" type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">oauth2_client_id</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_client_id" value="<?php echo $param["exp_googleplus_client_id"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">oauth2_client_secret</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_client_secret" value="<?php echo $param["exp_googleplus_client_secret"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">oauth2_redirect_uri</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_redirect_uri" value="<?php echo $param["exp_googleplus_redirect_uri"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">oauth_consumer_key</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_consumer_key" value="<?php echo $param["exp_googleplus_consumer_key"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">oauth_consumer_secret</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_consumer_secret" value="<?php echo $param["exp_googleplus_consumer_secret"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">site_name</td>
    <td bgcolor="#FFFFFF"><input name="exp_googleplus_site_name" value="<?php echo $param["exp_googleplus_site_name"]; ?>" style="width:300px"  type="text" /></td>
  </tr>

</table>