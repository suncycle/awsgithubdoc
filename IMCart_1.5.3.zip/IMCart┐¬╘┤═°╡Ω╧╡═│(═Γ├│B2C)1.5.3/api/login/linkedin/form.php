<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
 
  <tr>
    <td bgcolor="#FFFFFF">APP_ID</td>
    <td bgcolor="#FFFFFF"><input name="exp_linkedin_app" value="<?php echo $param["exp_linkedin_app"]; ?>" style="width:300px" type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">API_SECRET</td>
    <td bgcolor="#FFFFFF"><input name="exp_linkedin_secret" value="<?php echo $param["exp_linkedin_secret"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">REDIRECT_URI</td>
    <td bgcolor="#FFFFFF"><input name="exp_linkedin_callback" value="<?php echo $param["exp_linkedin_callback"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
</table>