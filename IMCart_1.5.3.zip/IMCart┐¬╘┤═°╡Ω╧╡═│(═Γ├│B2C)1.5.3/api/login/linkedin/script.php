<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

//require_once(APP_ROOT . 'api/login/twitter/package/twitteroauth/twitteroauth.php');
class linkedin {

    private $param;

    public function SetConfig($param) {
        $this->param = $param;
    }

    public function redirectURL() {
        @session_start();
        $params = array(
            'response_type' => 'code',
            'client_id' => $this->param['exp_linkedin_app'],
            'scope' => 'r_basicprofile r_emailaddress',
            'state' => uniqid('', true), // unique long string
            'redirect_uri' => $this->param['exp_linkedin_callback'],
        );
        $_SESSION['state'] = $params['state'];
        return $url = 'https://www.linkedin.com/uas/oauth2/authorization?' . http_build_query($params);
    }

    public function callBack() {
        @session_start();
        if (isset($_GET['code'])) {
            // User authorized your application
            if ($_SESSION['state'] == $_GET['state']) {
                // Get token so you can make API calls
                $params = array(
                    'grant_type' => 'authorization_code',
                    'client_id' => $this->param['exp_linkedin_app'],
                    'client_secret' => $this->param['exp_linkedin_secret'],
                    'code' => $_GET['code'],
                    'redirect_uri' => $this->param['exp_linkedin_callback'],
                );
                // Access Token request
                $url = 'https://www.linkedin.com/uas/oauth2/accessToken?' . http_build_query($params);
                // Tell streams to make a POST request
                $context = stream_context_create(
                        array('http' =>
                            array('method' => 'POST',
                            )
                        )
                );
                // Retrieve access token information
                $response = file_get_contents($url, false, $context);
                // Native PHP object, please
                $token = json_decode($response);

                // Store access token and expiration time
                $_SESSION['access_token'] = $token->access_token; // guard this! 
                $_SESSION['expires_in'] = $token->expires_in; // relative time (in seconds)
                $_SESSION['expires_at'] = time() + $_SESSION['expires_in']; // absolute time
                $opts = array(
                    'http' => array(
                        'method' => 'GET',
                        'header' => "Authorization: Bearer " . $_SESSION['access_token'] . "\r\n" . "x-li-format: json\r\n"
                    )
                );

                $url = 'https://api.linkedin.com/v1/people/~:(id,email-address,first-name,last-name,industry)';
                $context = stream_context_create($opts);
                $response = file_get_contents($url, false, $context);
                $info = json_decode($response);
                $user_id = $info->id;
                $email = $info->emailAddress;
                $return = array(
                    'api_id' =>$user_id,
                    'api_type' => 'linkedin',
                    'user_email' => $email,
                );
                return $return;
            } else {
                // CSRF attack? Or did you mix up your states?
                exit;
            }
        }
    }

}

?>
