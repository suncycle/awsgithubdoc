<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
 
  <tr>
    <td bgcolor="#FFFFFF">APP ID</td>
    <td bgcolor="#FFFFFF"><input name="exp_facebook_app" value="<?php echo $param["exp_facebook_app"]; ?>" style="width:300px" type="text" /></td>
  </tr>
     <tr>
    <td bgcolor="#FFFFFF">APP KEY</td>
    <td bgcolor="#FFFFFF"><input name="exp_facebook_key" value="<?php echo $param["exp_facebook_key"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
     <tr>
    <td bgcolor="#FFFFFF">APP Callback</td>
    <td bgcolor="#FFFFFF"><input name="exp_facebook_callback" value="<?php echo $param["exp_facebook_callback"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
</table>