<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once(APP_ROOT . 'api/login/facebook/package/facebook.php');
class facebook
{

    private $param;

    public function SetConfig($param)
    {
        $this->param = $param;
    }

    public function redirectURL()
    {
        $helper = new FacebookHelper(array(
          'appId'  => $this->param['exp_facebook_app'],
          'secret' => $this->param['exp_facebook_key'],
          'redirectUrl'  => $this->param['exp_facebook_callback'],          
        ));
        return $loginUrl = $helper->getLoginUrl(array('scope' =>'email'));
    }

    public function callBack()
    {
        $helper = new FacebookHelper(array(
          'appId'  => $this->param['exp_facebook_app'],
          'secret' => $this->param['exp_facebook_key'],
          'redirectUrl'  => $this->param['exp_facebook_callback'],
        ));
        $user = $helper->getUser();
        if ($user) {
          try {
            // Proceed knowing you have a logged in user who's authenticated.
            $user_profile = $helper->api('/me');
            
            $return = array(
                'api_id' => $user_profile['id'],
                'api_type' => 'facebook',
                'user_email' => $user_profile['email'],
            );
            return $return;
            //var_dump($user_profile);
          } catch (FacebookApiException $e) {
            error_log($e);
            $user = null;
            echo "Exception occured, code: " . $e->getCode();
            echo " with message: " . $e->getMessage();
          }
        }
        else
        {
            die('Error');
        }
    }

}

?>
