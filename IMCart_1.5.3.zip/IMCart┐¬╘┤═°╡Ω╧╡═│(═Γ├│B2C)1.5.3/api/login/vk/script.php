<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

//require_once(APP_ROOT . 'api/login/twitter/package/twitteroauth/twitteroauth.php');
class Vk {

    private $param;

    public function SetConfig($param) {
        $this->param = $param;
    }

    public function redirectURL() {
        $api_id = $this->param['exp_vk_apiid'];
        $api_url = $this->param['exp_vk_apiurl'];
        return $api_url . "?client_id=" . $api_id . "&display=&redirect_uri=" . urlencode("http://" . $_SERVER['SERVER_NAME'] . "/sns-callback-vk.html?js=1") . "&response_type=token&scope=email";
    }

    public function callBack() {
        $urlJs = _g(js);
        if ($urlJs) {
            echo '<script language="javascript">var url = location.href.split("#");var urls = location.href.split("?"); location.href=urls[0]+"?"+url[1];</script>';
            exit;
        } else {
            $get = _g();
            $access_token = $get['access_token'];
            $expires_in = $get['expires_in'];
            $user_id = $get['user_id'];
            $url = "https://api.vk.com/method/getProfiles";
            $ch = curl_init();
            $post_data = array(
                'user_ids' => $user_id,
                'access_token' => $access_token,
            );
            $Curls = Common::getRemoteData($url, '', '', 5, $post_data);
            $Curls = json_decode($Curls, true);
            $return = array(
                'api_id' => $Curls['response'][0]['uid'],
                'api_type' => 'vk',
                'api_key' => $user_id,
                'user_email' => '',
            );
            return $return;
        }
    }

}

?>
