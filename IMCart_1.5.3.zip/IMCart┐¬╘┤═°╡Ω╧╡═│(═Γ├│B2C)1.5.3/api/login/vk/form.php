<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF">API_ID</td>
        <td bgcolor="#FFFFFF"><input name="exp_vk_apiid" value="<?php echo $param["exp_vk_apiid"]; ?>" style="width:300px" type="text" /></td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF">API_URL</td>
        <td bgcolor="#FFFFFF"><input name="exp_vk_apiurl" value="<?php echo $param["exp_vk_apiurl"]; ?>" style="width:300px"  type="text" /></td>
    </tr>
</table>