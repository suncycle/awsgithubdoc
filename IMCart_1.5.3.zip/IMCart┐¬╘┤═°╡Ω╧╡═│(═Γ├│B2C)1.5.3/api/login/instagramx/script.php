<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class instagramx {

    private $param;

    public function SetConfig($param) {
        $this->param = $param;
    }

    public function redirectURL() {
        /* Start session and load library. */
        @session_start();

        require 'api/login/instagramx/package/instagram.class.php';
        require 'api/login/instagramx/package/instagram.config.php';
        $instagram = new Instagram(array(
            'apiKey' => $this->param['exp_client_id'],
            'apiSecret' => $this->param['exp_client_secret'],
            'apiCallback' => $this->param['exp_redirect_uri'] // Callback URL
        ));


        // Login URL
        $loginUrl = $instagram->getLoginUrl();
        echo "<script>window.location.href='{$loginUrl}'</script>";
    }

    public function callBack() {
        /* Start session and load lib */
        @session_start();
        require 'api/login/instagramx/package/instagram.class.php';
        require 'api/login/instagramx/package/instagram.config.php';
        $instagram = new Instagram(array(
            'apiKey' => $this->param['exp_client_id'],
            'apiSecret' => $this->param['exp_client_secret'],
            'apiCallback' => $this->param['exp_redirect_uri'] // Callback URL
        ));
        // Receive OAuth code parameter
        $code = $_GET['code'];

        // Check whether the user has granted access
        if (true === isset($code)) {
            
            // Receive OAuth token object
            $data = $instagram->getOAuthToken($code);
            if (empty($data->user->username)) {
                Common::alertRedirect("network error!",Common::frontURL('home', 'user', 'loginOrRegister'));
            } else {
                $user = $data->user->username;
                $fullname = $data->user->full_name;
                $bio = $data->user->bio;
                $website = $data->user->website;
                $id = $data->user->id;
                $token = $data->access_token;
                if ($id) {
                    $return = array(
                        'api_id' => $id,
                        'api_type' => 'instagramlogin',
                    );
                    if ($content->email)
                        $return['user_email'] = $content->email;
                    return $return;
                }
            }
        } else {
            // Check whether an error occurred
            if (true === isset($_GET['error'])) {
                echo 'An error occurred: ' . $_GET['error_description'];
            }
        }
    }

}

?>
