<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
 
  <tr>
    <td bgcolor="#FFFFFF">CLIENT ID</td>
    <td bgcolor="#FFFFFF"><input name="exp_client_id" value="<?php echo $param["exp_client_id"]; ?>" style="width:300px" type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">CLIENT SECRET</td>
    <td bgcolor="#FFFFFF"><input name="exp_client_secret" value="<?php echo $param["exp_client_secret"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">WEBSITE URL</td>
    <td bgcolor="#FFFFFF"><input name="exp_website_url" value="<?php echo $param["exp_website_url"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">REDIRECT URI</td>
    <td bgcolor="#FFFFFF"><input name="exp_redirect_uri" value="<?php echo $param["exp_redirect_uri"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
</table>