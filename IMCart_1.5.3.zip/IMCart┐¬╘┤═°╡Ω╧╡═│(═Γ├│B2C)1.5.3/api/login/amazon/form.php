<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF">Client ID</td>
        <td bgcolor="#FFFFFF"><input name="exp_amazon_id" value="<?php echo $param["exp_amazon_id"]; ?>" style="width:300px" type="text" /></td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF">Client Secret</td>
        <td bgcolor="#FFFFFF"><input name="exp_amazon_secret" value="<?php echo $param["exp_amazon_secret"]; ?>" style="width:300px"  type="text" /></td>
    </tr>	
</table>