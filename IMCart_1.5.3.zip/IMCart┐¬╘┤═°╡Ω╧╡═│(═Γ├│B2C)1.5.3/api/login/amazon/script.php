<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class Amazon {

    private $param;	
    public function SetConfig($param) {
        $this->param = $param;
    }

    public function redirectURL() {
		$amazon_id = $this->param['exp_amazon_id'];
		$exp_amazon_secret = $this->param['exp_amazon_secret'];
		$url = "https://www.amazon.com/ap/oa?client_id=".$amazon_id."&response_type=token&scope=profile&state=208257577110975193121591895857091249424&redirect_uri=".urlencode("http://" . $_SERVER['SERVER_NAME'] . "/sns-callback-amazon.html");
		//$url = "https://www.amazon.com/ap/oa?client_id=".$amazon_id."&scope=profile&response_type=code&state=208257577110975193121591895857093449424&redirect_uri=".urlencode("http://" . $_SERVER['SERVER_NAME'] . "/sns-callback-amazon.html");
		return $url;
    }

    public function callBack() {	
		var_dump(_g());
		exit;
    }	
}

?>
