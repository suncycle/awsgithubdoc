<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class paypal
{
    private $param;
            
    public function SetConfig($param)
    {	
        $this->param = $param;
        
    }

    public function redirectURL()
    {	//@session_start();
        require_once APP_ROOT . 'api/login/paypal/package/PPConfigManager.php';
        require_once APP_ROOT . 'api/login/paypal/package/PPConstants.php';
        require_once APP_ROOT . 'api/login/paypal/package/common/PPApiContext.php';
        require_once APP_ROOT . 'api/login/paypal/package/auth/openid/PPOpenIdSession.php';
        
        $clientId = $this->param['exp_paypal_client_id'];
        $clientSecret = $this->param['exp_paypal_client_secret']; 
        $redirectUri =$this->param['exp_paypal_redirect_uri'];

        $apicontext = new PPApiContext(array('mode' => 'live'));
        
        $scope = array('openid', 'email'); 
        
        $openidurl = PPOpenIdSession::getAuthorizationUrl($redirectUri, $scope , $clientId,  $apicontext); 
        
        return $openidurl;
    }

    public function callBack()
    {	
        require_once APP_ROOT . 'api/login/paypal/package/PPConfigManager.php';
        require_once APP_ROOT . 'api/login/paypal/package/PPConstants.php';
        require_once APP_ROOT . 'api/login/paypal/package/PPHttpConfig.php';
        require_once APP_ROOT . 'api/login/paypal/package/PPHttpConnection.php';
        require_once APP_ROOT . 'api/login/paypal/package/exceptions/PPConnectionException.php';
        require_once APP_ROOT . 'api/login/paypal/package/handlers/IPPHandler.php';
        require_once APP_ROOT . 'api/login/paypal/package/handlers/PPOpenIdHandler.php';
        require_once APP_ROOT . 'api/login/paypal/package/PPLoggingManager.php';
        require_once APP_ROOT . 'api/login/paypal/package/transport/PPRestCall.php';
        require_once APP_ROOT . 'api/login/paypal/package/common/PPUserAgent.php';
        require_once APP_ROOT . 'api/login/paypal/package/common/PPApiContext.php';
        require_once APP_ROOT . 'api/login/paypal/package/common/PPModel.php';
        require_once APP_ROOT . 'api/login/paypal/package/auth/openid/PPOpenIdTokeninfo.php';
        require_once APP_ROOT . 'api/login/paypal/package/auth/openid/PPOpenIdUserinfo.php';

        if (isset($_GET['code']))
        {
            $apicontext = new PPApiContext(array('mode' => 'live'));
            $params = array(
                    'client_id' =>$this->param['exp_paypal_client_id'],
                    'client_secret' =>$this->param['exp_paypal_client_secret'],
                    'code' =>$_GET['code']
            );
            
            $_SESSION['token'] =PPOpenIdTokeninfo::createFromAuthorizationCode($params,$apicontext);
            
            if(!empty($_SESSION['token'])){
                $apicontext = new PPApiContext(array('mode' => 'live'));
                $access_token = $_SESSION['token']->access_token;
                $params = array('access_token' => $access_token);
                
                $user = PPOpenIdUserinfo::getUserinfo($params,$apicontext);
                $email = $user->email;
                $user_ids = explode('/',$user->user_id);
                $con = count($user_ids);
                $user_id =$user_ids[$con-1];                
                $return = array(
                    'api_id' => $user_id,
                    'api_type' => 'paypal',
                    'user_email' => $email
                );
                unset($_SESSION['token']);
                return $return;
            }
        }else{
            
            die('Error');
        }
        
        

        
	
    }
	

}

?>
