<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">clientId</td>
    <td bgcolor="#FFFFFF"><input name="exp_paypal_client_id" value="<?php echo $param["exp_paypal_client_id"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">clientSecret</td>
    <td bgcolor="#FFFFFF"><input name="exp_paypal_client_secret" value="<?php echo $param["exp_paypal_client_secret"]; ?>" style="width:300px"  type="text" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">redirectUri</td>
    <td bgcolor="#FFFFFF"><input name="exp_paypal_redirect_uri" value="<?php echo $param["exp_paypal_redirect_uri"]; ?>" style="width:300px"  type="text" /></td>
  </tr>

</table>