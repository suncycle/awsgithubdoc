<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class live {
    
    private $param;

    public function SetConfig($param) {
        $this->param = $param;
    }

    public function redirectURL() {
        /* Start session and load library. */
        @session_start();
        echo "<script>window.location.href='https://login.live.com/wlogin.srf?appid={$this->param['exp_client_id']}&alg=wsignin1.0'</script>";
    }

    public function callBack() {
        /* Start session and load lib */
        @session_start();
        include 'api/login/live/package/sample/settings.php';
        include 'api/login/live/package/lib/windowslivelogin.php';
        
        $settings[appid]=$this->param['exp_client_id'];
        $settings[secret]=$this->param['exp_client_secret'];
        $settings[securityalgorithm]="wsignin1.0";
        
        $wll = WindowsLiveLogin::initFromXml($settings);
        $wll->setDebug($DEBUG);
        $users = $wll->processLogin($_REQUEST);
        //$users = (array)$users;
        //var_dump($users);exit;
        if($users->getId()){
            $return = array(
                'api_id' => $users->getId(),
                'api_type' => 'live',
            );

            return $return;
        }else {
            Common::alertRedirect("network error!",Common::frontURL('home', 'user', 'loginOrRegister'));
        }
    }
}
?>
