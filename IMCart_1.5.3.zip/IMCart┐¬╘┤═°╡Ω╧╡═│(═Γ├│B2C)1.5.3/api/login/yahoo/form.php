<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF">OAUTH_CONSUMER_KEY</td>
        <td bgcolor="#FFFFFF"><input name="exp_yahoo_key" value="<?php echo $param["exp_yahoo_key"]; ?>" style="width:300px" type="text" /></td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF">OAUTH_CONSUMER_SECRET</td>
        <td bgcolor="#FFFFFF"><input name="exp_yahoo_secret" value="<?php echo $param["exp_yahoo_secret"]; ?>" style="width:300px"  type="text" /></td>
    </tr>
	<tr>
        <td bgcolor="#FFFFFF">APP_ID</td>
        <td bgcolor="#FFFFFF"><input name="exp_yahoo_appid" value="<?php echo $param["exp_yahoo_appid"]; ?>" style="width:300px"  type="text" /></td>
    </tr>
</table>