<?php

/**
 * Description of ShippingLogic
 *
 * @author CYM
 */
require_once(APP_ROOT . "libary/BaseShipping.php");

class totalpriceshipping extends BaseShipping {

    function getShippingCost($cart_param, $str_json, $discount) {
        $totalweight = $cart_param["totalweight"];
        $totalprice = $cart_param["totalprice"];
        //$totalvweight = $cart_param["totalvweight"];
        $totalnumber = $cart_param["totalnumber"];
        $param = json_decode($str_json, true);
        //总价格，总重量，总件数超过设定值进行屏蔽
        if($param['exp_hidden_price'] && $totalprice>$param['exp_hidden_price']){
            return false;
        }
        if($param['exp_hidden_weight'] && $totalweight>$param['exp_hidden_weight']){
            return false;
        }
        if($param['exp_hidden_number'] && $totalnumber>$param['exp_hidden_number']){
            return false;
        }
        //总价格，总重量，总件数超过设定值进行屏蔽 end
        
        
        $discount = $discount ? $discount / 100 : 1;
        $shipping_cost = 0;
        
        
        //------------
//        if ($totalprice == 0) {
//            return $shipping_cost;
//        }
        //$totalprice = ceil($cart_param["totalprice"]);
        for ($index = 1; $index <= 10; $index++) {
            //$exp_weight = ceil($param["exp_price" . $index] * 2) / 2;
            if($param["exp_price" . $index] !="" && ( $param["exp_base" . $index] !="" || $param["exp_persent" . $index] !=""  )){
                
                if ($totalprice > $param["exp_price" . $index]) {
                    
                    if($param["exp_base" . $index] !=""){
                       
                        $shipping_cost =$param["exp_base" . $index];
                        
                    }elseif($param["exp_persent" . $index] !=""){
                        
                        $shipping_cost = ($totalprice * ($param["exp_persent" . $index] / 100));
                        
                    }
                    
                }
            }
        }
        if($param["exp_freeship_price"] && $totalprice>=$param["exp_freeship_price"])
        {
                $shipping_cost = 0;	
        }
        if($param["exp_freeship_number"] && $totalnumber>=$param["exp_freeship_number"])
        {
                $shipping_cost = 0;	
        }
        if($param["exp_freeship_weight"] && $totalweight>=$param["exp_freeship_weight"])
        {
                $shipping_cost = 0;	
        }
        
        //------------- 
        return $shipping_cost * $discount;
    }

}

?>