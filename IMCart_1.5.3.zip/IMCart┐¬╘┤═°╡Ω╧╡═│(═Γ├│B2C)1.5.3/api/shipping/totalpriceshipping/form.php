<strong>价格区间设置</strong>&nbsp;<span>(重量单位:KG , 货币单位:<?=$_SESSION['base_standard_code']?>)</span>
<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF" align="center"> </td>
    <td bgcolor="#FFFFFF" align="center">价格<?=$_SESSION['base_standard_code']?></td>
    <td bgcolor="#FFFFFF" align="center">固定费</td>
    <td width="35" bgcolor="#FFFFFF" align="center">或</td>
    <td bgcolor="#FFFFFF" align="center">总价(x%)</td>
  </tr>

  <tr>
<?php
 for($index=1;$index<=10;$index++):
?>
   <tr>
       <td width="80" align="center" bgcolor="#FFFFFF">总价高于</td>
       <td width="40" align="center" bgcolor="#FFFFFF"><input name="exp_price<?php echo $index;?>" size="5" value="<?php echo $param["exp_price".$index]; ?>" type="text"/></td>
    <td width="65" bgcolor="#FFFFFF"><input name="exp_base<?php echo $index;?>" value="<?php echo $param["exp_base".$index]; ?>" size="6" type="text" /></td>
    <td  align="center" bgcolor="#FFFFFF">或</td>
    <td width="65" bgcolor="#FFFFFF"><input name="exp_persent<?php echo $index;?>" value="<?php echo $param["exp_persent".$index]; ?>" size="6" type="text" /></td>
  </tr>
<?php
 endfor;// for($index=1;$index<=41;$index++)
?>
</table><strong>免运费设置</strong><table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">价格>=</td>
    <td bgcolor="#FFFFFF"><input name="exp_freeship_price" value="<?php echo $param["exp_freeship_price"]; ?>" size="6" type="text" /></td>
    <td bgcolor="#FFFFFF">免运费</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">重量>=</td>
    <td bgcolor="#FFFFFF"><input name="exp_freeship_weight" value="<?php echo $param["exp_freeship_weight"]; ?>" size="6" type="text" /></td>
    <td bgcolor="#FFFFFF">免运费</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">件数>=</td>
    <td bgcolor="#FFFFFF"><input name="exp_freeship_number" value="<?php echo $param["exp_freeship_number"]; ?>" size="6" type="text" /></td>
    <td bgcolor="#FFFFFF">免运费</td>
  </tr>
</table>
<strong>屏蔽设置</strong>
<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF">价格></td>
        <td bgcolor="#FFFFFF"><input name="exp_hidden_price" value="<?php echo $param["exp_hidden_price"]; ?>" size="6" type="text" /></td>
        <td bgcolor="#FFFFFF">屏蔽不显示</td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF">重量></td>
        <td bgcolor="#FFFFFF"><input name="exp_hidden_weight" value="<?php echo $param["exp_hidden_weight"]; ?>" size="6" type="text" /></td>
        <td bgcolor="#FFFFFF">屏蔽不显示</td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF">件数></td>
        <td bgcolor="#FFFFFF"><input name="exp_hidden_number" value="<?php echo $param["exp_hidden_number"]; ?>" size="6" type="text" /></td>
        <td bgcolor="#FFFFFF">屏蔽不显示</td>
    </tr>
</table>