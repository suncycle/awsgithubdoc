<strong>小包裹</strong>KG , 货币单位(<?=$_SESSION['_base_standard_code']?>)
<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">重量</td>
    <td bgcolor="#FFFFFF">价格</td>
    <td bgcolor="#FFFFFF">重量</td>
    <td bgcolor="#FFFFFF">价格</td>
    <td bgcolor="#FFFFFF">重量</td>
    <td bgcolor="#FFFFFF">价格</td>
    <td bgcolor="#FFFFFF">重量</td>
    <td bgcolor="#FFFFFF">价格</td>
    <td bgcolor="#FFFFFF">重量</td>
    <td bgcolor="#FFFFFF">价格</td>
    <td bgcolor="#FFFFFF">重量</td>
    <td bgcolor="#FFFFFF">价格</td>
  </tr>

  <tr>
<?php
 for($index=1;$index<=60;$index++):
?>
    <td width="40" align="center" bgcolor="#FFFFFF"><input name="exp_weight<?php echo $index;?>" size="5" value="<?php echo $index*0.5; ?>" type="hidden" /><?php echo $index*0.5; ?></td>
    <td width="65" bgcolor="#FFFFFF"><input name="exp_price<?php echo $index;?>" value="<?php echo $param["exp_price".$index]; ?>" size="6" type="text" /></td>
<?php 
 if($index%6==0):
?>
  </tr>
  <tr>
<?php
 endif; //if($index%6==0):
 endfor;// for($index=1;$index<=41;$index++)
?>
  </tr>
</table>
<strong>免运费设置</strong>
<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">价格超过</td>
    <td bgcolor="#FFFFFF"><input name="exp_freeship_price" value="<?php echo $param["exp_freeship_price"]; ?>" size="6" type="text" /></td>
    <td bgcolor="#FFFFFF">免运费</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">重量超过</td>
    <td bgcolor="#FFFFFF"><input name="exp_freeship_weight" value="<?php echo $param["exp_freeship_weight"]; ?>" size="6" type="text" /></td>
    <td bgcolor="#FFFFFF">免运费</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">件数超过</td>
    <td bgcolor="#FFFFFF"><input name="exp_freeship_number" value="<?php echo $param["exp_freeship_number"]; ?>" size="6" type="text" /></td>
    <td bgcolor="#FFFFFF">免运费</td>
  </tr>
</table>
