<?php
/**
 * Description of ShippingLogic
 *
 * @author CYM
 */
require_once(APP_ROOT."libary/BaseShipping.php"); 
class tableshipping extends BaseShipping
{
	function getShippingCost($cart_param,$str_json, $discount)
	{
		$totalweight = $cart_param["totalweight"];
		$totalprice = $cart_param["totalprice"];
		$totalvweight = $cart_param["totalvweight"];
		$totalnumber = $cart_param["totalnumber"];
		$param = json_decode($str_json,true);
        $discount = $discount ? $discount/100 : 1;
		$shipping_cost = 0 ;
		//------------
        if($totalweight == 0)
        {
          return $shipping_cost;
        }
		$totalweight = ceil($cart_param["totalweight"]*2)/2;
		for($index=1;$index<=60;$index++)
		{
            $exp_weight = ceil($param["exp_weight".$index]*2)/2;
			if($exp_weight == $totalweight)
            {
				$shipping_cost = $param["exp_price".$index];
            }
		}
		if($param["exp_freeship_price"] && $totalprice>=$param["exp_freeship_price"])
		{
			$shipping_cost = 0;	
		}
		if($param["exp_freeship_number"] && $totalnumber>=$param["exp_freeship_number"])
		{
			$shipping_cost = 0;	
		}
		if($param["exp_freeship_weight"] && $totalweight>=$param["exp_freeship_weight"])
		{
			$shipping_cost = 0;	
		}
		//------------- 
		return $shipping_cost * $discount;
	}
}

?>