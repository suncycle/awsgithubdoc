配送公式开发标准 理论支持各种各样的公式类型
1 每种配送公式放一个文件夹 类似 "firstnext"  "fedextable"  "dhltable"

2 每种联合登录文件夹下存放规则
/readme.txt 这个文档已UTF-8编码保存，里面内容为联合登录的名称。例如：首重+续重 , FEDEX价格表 , DHL价格表
/form.php 用来存放需要配置的参数表单
/script.php 用来存放计算公式

3 form.php PHP文件标准
所有的INPUT文本框的NAME值统一 exp_ 开头
例如：
<input name="exp_firstweight" value="<?php echo $param["exp_firstweight"]; ?>" style="width:300px" type="text" />

VALUE属性的值 统一用 $obj 数组调用，数组的键为该INPUT元素的NAME名称。

4 script.php
申明一个类，类名为 文件夹的名称 类似 "firstnext"  "fedextable"  "dhltable"
在 function getShippingCost() 函数里面写算法逻辑

5 如果 比如不想30KG以后显示这条信息，可以直接 return false