<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">百分比 %</td>
    <td bgcolor="#FFFFFF"><input type="text" class="text" name="exp_value" style="width:120px" value="<?php echo $param["exp_value"];?>" /></td>
  </tr>
</table>
