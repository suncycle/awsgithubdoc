<?php
/**
 * Description of ShippingLogic
 *
 * @author CYM
 */
require_once(APP_ROOT."libary/BasePayment.php"); 
class number_percentage extends BasePayment
{
	function getPaymentFee($order_param,$str_json)
	{   
		$totalprice = $order_param["totalprice"];
		$param = json_decode($str_json,true);
		$payment_fee = 0 ;
		//------------ 下面开始 运费的逻辑算法
		
		$payment_fee = $totalprice*$param['exp_value']/100 + $param['exp_number'];
		//------------- 计算结束
		return $payment_fee;
	}
}


?>