固定值+百分比
<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
  <tr>
    <td bgcolor="#FFFFFF">固定值</td>
    <td bgcolor="#FFFFFF"><input type="text" class="text" name="exp_number" style="width:120px" value="<?php echo $param["exp_number"];?>" /></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">百分比(%)</td>
    <td bgcolor="#FFFFFF"><input type="text" class="text" name="exp_value"  style="width:120px" value="<?php echo $param["exp_value"];?>" /></td>
  </tr>
  </table>
