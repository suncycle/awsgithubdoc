<?php
/**
 * Description of ShippingLogic
 *
 * @author CYM
 */
require_once(APP_ROOT."libary/BasePaymentInterface.php"); 
class number extends BasePaymentInterface
{
	function getPaymentFee($cart_param,$str_json)
	{   
		$totalprice = $cart_param["totalprice"];
		$param = json_decode($str_json,true);
		$payment_fee = 0 ;
		//------------ 下面开始 运费的逻辑算法
		
		$payment_fee = $param['exp_number'];
		//------------- 计算结束
		return $payment_fee;
	}
}


?>