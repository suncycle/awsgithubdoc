<?php

class insurance_percentage
{	
    public function getCost($cart_param, $str_json)
	{
        $params = json_decode($str_json,true);
        $amount = 0;
        if($params['exp_amount_type'] == 1)
        {
          $amount = $cart_param['order_totalprice'];
        }
        else if($params['exp_amount_type'] == 2)
        {
          $amount = $cart_param['goods_totalprice'];
        }
        else
        {
          $amount = $cart_param['shipping_fee'];
        }
        $cost = $amount * $params['exp_percentage']/100;
        if($params['exp_max'] && $cost > $params['exp_max'])
        {
          $cost = $params['exp_max'];
        }
        return $cost;
	}
}

?>