<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF" width="80">按照:</td>
        <td  bgcolor="#FFFFFF" >
          <select name="exp_amount_type">
             <option value="1" <?php if($param["exp_amount_type"] == 1){echo 'selected="selected"';};?> >订单总额</option>
             <option value="2" <?php if($param["exp_amount_type"] == 2){echo 'selected="selected"';};?> >商品总额</option>
             <option value="3" <?php if($param["exp_amount_type"] == 3){echo 'selected="selected"';};?> >运费总额</option>
          </select>          
        </td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF" width="80">百分比:</td>
        <td  bgcolor="#FFFFFF" ><input type="text" class="text" name="exp_percentage"  style="width:100px"  value="<?php echo $param["exp_percentage"];?>" /> 
        %</td>
    </tr>
    <tr>
        <td bgcolor="#FFFFFF" width="80">封顶:</td>
        <td  bgcolor="#FFFFFF" ><input type="text" class="text" name="exp_max"  style="width:100px"  value="<?php echo $param["exp_max"];?>" /> <?php echo $param["standard_code"];?></td>
    </tr>
</table>