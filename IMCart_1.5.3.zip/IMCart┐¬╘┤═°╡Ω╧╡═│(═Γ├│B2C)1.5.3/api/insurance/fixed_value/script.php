<?php

class fixed_value
{	
    public function getCost($cart_param, $str_json)
	{
        $params = json_decode($str_json,true);
        return $params['exp_amount'];
	}
}

?>