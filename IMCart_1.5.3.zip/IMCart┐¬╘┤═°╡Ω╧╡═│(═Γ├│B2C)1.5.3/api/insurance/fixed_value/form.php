<table  border="0" cellspacing="1" cellpadding="1" style="font-size:12px; background:#eee;">
    <tr>
        <td bgcolor="#FFFFFF" width="80">金额:</td>
        <td  bgcolor="#FFFFFF" ><input type="text" class="text" name="exp_amount"  style="width:100px" value="<?php echo $param["exp_amount"];?>" /><?php echo $param["standard_code"];?></td>
    </tr>
</table>